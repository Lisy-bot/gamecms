package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.Intercept;
import com.cms.model.auth.SysUser;
import com.cms.service.InterceptService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 拦截控制层
 * @author gengyl
 * @date 2017年8月7日
 */
public class InterceptController  extends Controller{

	InterceptService interceptService = enhance(InterceptService.class);
	// 首页
		public void index() {//String intyName, Integer inteParam
			String page = getPara("page"); // 当前页
			String pageSize = getPara("rows"); // 每页大小
			// 搜索
			String intyName = getPara("intyName");
			String inteParam = getPara("inteParam");

			if (page != null && pageSize != null) {
				Map<String, Object> map = new HashMap<>();
				Page<Intercept> interceptPage = interceptService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize), intyName, inteParam);// 当前页的记录数
				map.put("total", interceptPage.getTotalRow());
				map.put("rows", interceptPage.getList());
				render(new JsonRender(map).forIE());
			} else {
				// 加载权限
				SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
				setAttrs(AuthService.buttonAuthMap(user, "/intercept"));
				setAttr("pageSize", Constant.backend_pagesize);
				render("index.html");
			}
		}
		
		// 添加
		public void add() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				Intercept intercept = getModel(Intercept.class);
				String mess = interceptService.add(intercept);
				renderJson(new JsonRender(mess).forIE());
			} else {
				render("add.html");
			}
		}
		
		// 编辑
		public void edit() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				Intercept Intercept = getModel(Intercept.class);
				String mess = interceptService.edit(Intercept);
				renderJson(new JsonRender(mess).forIE());
			} else {
				int id = getParaToInt("intercept_id");
				Intercept intercept = interceptService.findById(id);
				setAttr("intercept", intercept);
				render("edit.html");
			}
		}

		// 删除
		public void del() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				int id = getParaToInt("id");
				String mess = interceptService.del(id);
				render(new JsonRender(mess).forIE());
			}
		}
}
