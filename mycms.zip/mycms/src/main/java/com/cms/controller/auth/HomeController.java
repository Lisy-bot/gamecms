package com.cms.controller.auth;

import java.util.List;

import com.alibaba.fastjson.JSON;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.RsaUtil;
import com.cms.model.auth.SysResource;
import com.cms.model.auth.SysUser;
import com.cms.model.auth.Token;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysUserService;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.render.JsonRender;

/**
 * 控制器：后台登录、登出
 * @author tanzhuo
 * @date 2017年3月25日
 */
public class HomeController extends Controller {

	// 系统用户服务类
	SysUserService sysUserService = enhance(SysUserService.class);
	// 权限服务类
	AuthService authService = enhance(AuthService.class);

	// 后台首页
	public void index() {
		String type = getPara("type");
		SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
		List<SysResource> list = authService.initMenusResource(user, 2);
		setAttr("userName", user.get("sysu_name"));
		setAttr("resList", list);
		if (type != null && type.equals("home")) {
			render("home.html");
		} else {
			render("index.html");
		}
	}

	// 树形菜单
	public void tree() {
		SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
		List<SysResource> list = authService.initMenusResource(user, 0);
		renderJson(list);
	}

	// 登录，不拦截
	@Clear
	public void login() {
		String ssoOpen = PropKit.use("config.properties").get("ssoOpen");
		// 强制开关，用于特殊情况下使用
		String open = getPara("open");
		if ("true".equals(ssoOpen) && !"true".equals(open)) {
			// 跳转到统一登录
			String returnUrl = getRequest().getScheme() + "://" + getRequest().getServerName() + ":" + getRequest().getServerPort()
			        + getRequest().getContextPath() + "/home/replayLogin";
			redirect(PropKit.use("config.properties").get("ssoLoginUrl") + "?SsoReturnUrl=" + returnUrl);
			return;
		} else {
			render("login.html");
		}
	}

	/**
	 * 二次登录
	 */
	@Clear
	public void replayLogin() {
		Token token = new Token();
		token.setId(BaseUtil.get32UUID());
		token.setIp(BaseUtil.getIpAddr(getRequest()));
		String loginNoticeUrl = getRequest().getScheme() + "://" + getRequest().getServerName() + ":" + getRequest().getServerPort()
		        + getRequest().getContextPath() + "/home/auth";
		token.setLoginNoticeUrl(loginNoticeUrl);
		try {

			String data = RsaUtil.buf_to_string(
			        RsaUtil.encryptByPrivateKey(JSON.toJSONString(token).getBytes(), PropKit.use("config.properties").get("authPrivateKey")));

			redirect(PropKit.use("config.properties").get("ssoReplayLoginUrl") + "?askData=" + data);
			return;
		} catch (Exception e) {
			e.printStackTrace();
		}
		renderHtml("<h1>统一登录失败，请联系管理员！</h1>");
	}

	/**
	 * sso响应
	 */
	@Clear
	public void auth() {
		String replayLoginData = getPara(0);
		if (!BaseUtil.isNull(replayLoginData)) {
			try {
				replayLoginData = new String(
				        RsaUtil.decryptByPrivateKey(RsaUtil.string_to_buf(replayLoginData), PropKit.use("config.properties").get("authPrivateKey")),
				        "utf-8");
				if (!BaseUtil.isNull(replayLoginData)) {
					Token token = JSON.parseObject(replayLoginData, Token.class);
					SysUser user = AuthService.getUserByAccount(token.getId());
					if (user == null) {
						renderHtml("<h1>账号信息异常，请同步用户后重试！</h1>");
					} else {
						// 更新到session
						getSession().setAttribute(Constant.CONST_SESSION_SYS_USER, user);
						// 自己加密后更新到cookie
						Token mytoken = new Token();
						mytoken.setId(user.getSysuAccount());
						mytoken.setIp(BaseUtil.getIpAddr(getRequest()));
						String mytokenData = JSON.toJSONString(mytoken);
						mytokenData = RsaUtil.buf_to_string(
						        RsaUtil.encryptByPrivateKey(mytokenData.getBytes(), PropKit.use("config.properties").get("authPrivateKey")));
						setCookie(PropKit.use("config.properties").get("ssoCookieName"), mytokenData, -1, getRequest().getContextPath());

						redirect("/home/index");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			// 重新去登录
			redirect("/home/login");
		}
	}

	// 验证码，不拦截
	@Clear
	public void captcha() {
		renderCaptcha();
	}

	// 用户验证，不拦截
	@Clear
	public void loginValidate() {
		String account = getPara("account").trim();
		String password = getPara("password").trim();
		String captcha = getPara("captcha").trim();

		String validate = sysUserService.loginValidate(account, password, captcha, this);
		renderJson(new JsonRender(validate).forIE());
	}

	// 登出
	@Clear
	public void logout() {
		removeCookie(PropKit.use("config.properties").get("ssoCookieName"), getRequest().getContextPath());
		removeSessionAttr(Constant.CONST_SESSION_SYS_USER);

		String ssoOpen = PropKit.use("config.properties").get("ssoOpen");
		if ("true".equals(ssoOpen)) {
			// 跳转到统一登录
			redirect(PropKit.use("config.properties").get("ssoLoginUrl"));
			return;
		} else {
			render("login.html");
		}
	}
}
