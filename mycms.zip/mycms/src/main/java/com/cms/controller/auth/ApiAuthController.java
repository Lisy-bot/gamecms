package com.cms.controller.auth;

import com.cms.common.util.BaseUtil;
import com.cms.service.auth.ApiService;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;

/**
 * 控制器：中央管理后台对接API
 * @author tanzhuo
 * @date 2017年8月23日
 */
@Clear
public class ApiAuthController extends Controller {
	// api服务类
	ApiService apiService = enhance(ApiService.class);

	/**
	 * 用户鉴权
	 */
	public void auth() {
		String params = getPara("params");
		if (getPara("callback") != null) {
			renderText("[{\"status\": \"success\"}]");
		} else {
			if (BaseUtil.isNull(params)) {
				renderHtml("<h1 style=\"text-align:center\">参数校验失败，请联系管理员！</h1>");
			} else {
				int status = apiService.auth(params, this);
				if (status == 1) {
					redirect("/home/index?type=home");
				} else if (status == 1) {
					renderHtml("<h1 style=\"text-align:center\">账号已被锁定，请联系管理员！</h1>");
				} else {
					renderHtml("<h1 style=\"text-align:center\">认证失败，请点击同步用户！</h1>");
				}
			}
		}
	}

	/**
	 * 用户同步、新增、修改
	 */
	public void ds() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String params = getPara("params");
			if (BaseUtil.isNull(params)) {
				renderText("error");
			} else {
				boolean status = apiService.dsUser(params);
				if (status) {
					renderText("success");
				} else {
					renderText("fail");
				}
			}
		} else {
			renderText("error");
		}
	}

	/**
	 * 用户修改密码
	 */
	public void ep() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String params = getPara("params");
			if (BaseUtil.isNull(params)) {
				renderText("error");
			} else {
				boolean status = apiService.editPass(params);
				if (status) {
					renderText("success");
				} else {
					renderText("fail");
				}
			}
		} else {
			renderText("error");
		}
	}

	/**
	 * 删除用户
	 */
	public void dl() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String params = getPara("params");
			if (BaseUtil.isNull(params)) {
				renderText("error");
			} else {
				boolean status = apiService.delUser(params);
				if (status) {
					renderText("success");
				} else {
					renderText("fail");
				}
			}
		} else {
			renderText("error");
		}
	}

}
