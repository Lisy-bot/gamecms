package com.cms.controller.auth;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.auth.SysLog;
import com.cms.model.auth.SysUser;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysLogService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 控制层：系统日志
 * @author tanzhuo
 * @date 2017年7月1日
 */
public class SysLogController extends Controller {
	// 系统日志服务类
	SysLogService logService = enhance(SysLogService.class);

	// 首页
	public void index() {
		String page = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 搜索
		String name = getPara("name");
		String startTime = getPara("startTime");
		String endTime = getPara("endTime");

		if (page != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<SysLog> logPage = logService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize), name, startTime, endTime);// 当前页的记录数
			map.put("total", logPage.getTotalRow());
			map.put("rows", logPage.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/sysLog"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}

	// 详细信息
	public void info() {
		String id = getPara("sysl_id");
		SysLog log = logService.findById(id);
		setAttr("sysLog", log);
		render("info.html");
	}
}
