package com.cms.controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.MemberType;
import com.cms.model.auth.SysUser;
import com.cms.service.MemberTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 会员类型管理控制器
 * 
 * @author Lisy
 * @date 2020-05-18
 */
public class MemberTypeController extends Controller {
	MemberTypeService memberTypeService = enhance(MemberTypeService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String member_type_id = getPara("member_type_id");
		String member_type_name = getPara("member_type_name");
		String member_type_online = getPara("member_type_online");
		String member_type_integral = getPara("member_type_integral");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<MemberType> member_type = memberTypeService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),
					 member_type_id, member_type_name, member_type_online, member_type_integral);
			map.put("total", member_type.getTotalRow());
			map.put("rows", member_type.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/memberType"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberTypeService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberTypeService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberTypeService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			MemberType memberType = memberTypeService.findById(getParaToInt("member_type_id"));
			setAttr("memberType", memberType);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
	public void getMemberTypeList() {
		if (getRequest().getMethod().equalsIgnoreCase("get")) {
			List<MemberType> mess = memberTypeService.querrAll();
			renderJson(new JsonRender(mess).forIE());
		} 
	}
}
