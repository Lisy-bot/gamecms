package com.cms.controller;
import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.PlayerKillingUser;
import com.cms.model.auth.SysUser;
import com.cms.service.PlayerKillingUserService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 
 * @author Lisy
 * @date 2020-05-20
 * 用户PK管理控制器
 */
public class PlayerKillingUserController extends Controller{
	PlayerKillingUserService playerKillingUserService = enhance(PlayerKillingUserService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String player_killing_id = getPara("player_killing_id");
		String player_killing_user_account = getPara("player_killing_user_account");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<PlayerKillingUser> playerKillingUser = playerKillingUserService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),
					player_killing_id, player_killing_user_account);
			map.put("total", playerKillingUser.getTotalRow());
			map.put("rows", playerKillingUser.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/playerKillingUser"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = playerKillingUserService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = playerKillingUserService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = playerKillingUserService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			PlayerKillingUser playerKillingUser = playerKillingUserService.findById(getParaToInt("player_killing_user_id"));
			setAttr("playerKillingUser", playerKillingUser);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
