package com.cms.controller.auth;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.auth.SysSetting;
import com.cms.model.auth.SysUser;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysSettingService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 控制器：系统设置
 * @author tanzhuo
 * @date 2017年8月22日
 */
public class SysSettingController extends Controller {
	// 系统设置服务类
	SysSettingService settingService = enhance(SysSettingService.class);

	// 首页
	public void index() {
		String page = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 页大小

		if (page != null && pageSize != null) {
			Map<String, Object> map = new HashMap<String, Object>();
			Page<SysSetting> userPage = settingService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize));// 当前页的记录数
			map.put("total", userPage.getTotalRow());
			map.put("rows", userPage.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/sysSetting"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysSetting sysSetting = getModel(SysSetting.class);
			int initRSA = getParaToInt("initRSA");
			String mess = settingService.editSysSetting(sysSetting, initRSA);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("set_id");
			SysSetting sysSetting = settingService.findById(id);
			setAttr("sysSetting", sysSetting);
			render("edit.html");
		}
	}

}
