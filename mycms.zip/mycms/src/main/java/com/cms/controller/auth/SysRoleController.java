package com.cms.controller.auth;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.auth.SysRole;
import com.cms.model.auth.SysUser;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysRoleService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 控制器：系统角色
 * @author tanzhuo
 * @date 2017年3月25日
 */
public class SysRoleController extends Controller {

	// 角色服务类
	SysRoleService roleService = enhance(SysRoleService.class);

	// 首页
	public void index() {
		String page = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小

		if (page != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<SysRole> rolePage = roleService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize));// 当前页的记录数
			map.put("total", rolePage.getTotalRow());
			map.put("rows", rolePage.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/sysRole"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysRole sysRole = getModel(SysRole.class);
			String mess = roleService.add(sysRole);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysRole sysRole = getModel(SysRole.class);
			String mess = roleService.edit(sysRole);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("sysr_id");
			SysRole sysRole = roleService.findById(id);
			setAttr("sysRole", sysRole);
			render("edit.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = roleService.del(id);
			render(new JsonRender(mess).forIE());
		}
	}

	// 授权
	public void auth() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("sysr_id");
			String auth = getPara("auth");
			String mess = roleService.editAuth(id, auth);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("sysr_id");
			setAttr("roleId", id);
			render("auth.html");
		}
	}

	// 获取角色资源列表
	public void getRoleAuth() {
		int id = getParaToInt(0);
		renderJson(roleService.findAuth(id));
	}

	// 获取角色列表
	public void getRoleList() {
		List<SysRole> sysRoleList = roleService.getSysRoleList();
		render(new JsonRender(sysRoleList).forIE());
	}
}
