package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.PointsSysType;
import com.cms.model.auth.SysUser;
import com.cms.service.PointsSysTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 积分首页管理控制器
 * 
 * @author Lisy
 * @date 2020-05-22
 */
public class PointsSysTypeController extends Controller {
	PointsSysTypeService pointsSysTypeService = enhance(PointsSysTypeService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称
		String points_sys_type_name = getPara("points_sys_type_name");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<PointsSysType> pointsSysType = pointsSysTypeService.queryAll(Integer.parseInt(pageNumber),
					Integer.parseInt(pageSize), points_sys_type_name);
			map.put("total", pointsSysType.getTotalRow());
			map.put("rows", pointsSysType.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/pointsSysType"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysTypeService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysTypeService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysTypeService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			PointsSysType pointsSysType = pointsSysTypeService.findById(getParaToInt("points_sys_type_id"));
			setAttr("pointsSysType", pointsSysType);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}

	public void getPointsSysTypeList() {
		if (getRequest().getMethod().equalsIgnoreCase("get")) {
			List<PointsSysType> mess = pointsSysTypeService.getPointsSysTypeList();
			renderJson(new JsonRender(mess).forIE());
		}
	}
}
