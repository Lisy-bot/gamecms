package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.ProductOrder;
import com.cms.model.auth.SysUser;
import com.cms.service.ProductOrderService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 产品订购管理
 * 
 * @author Lisy
 * @date 2020-09-02
 */
public class ProductOrderController extends Controller {
	ProductOrderService  pService= enhance(ProductOrderService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String p_online = getPara("p_online");
		String p_name = getPara("p_name");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<ProductOrder> productOrder = pService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), p_name, p_online);
			map.put("total", productOrder.getTotalRow());
			map.put("rows", productOrder.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/product"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			ProductOrder product_order = pService.findById(getParaToInt("p_id"));
			setAttr("productOrder", product_order);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
