package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.InterceptType;
import com.cms.model.auth.SysUser;
import com.cms.service.InterceptTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 拦截类型控制层
 * @author gengyl
 * @date 2017年8月7日
 */
public class InterceptTypeController  extends Controller{

	InterceptTypeService interceptTypeService = enhance(InterceptTypeService.class);
	// 首页
		public void index() {//String compName, String compUserName
			String page = getPara("page"); // 当前页
			String pageSize = getPara("rows"); // 每页大小
			// 搜索
			String intyName = getPara("intyName");

			if (page != null && pageSize != null) {
				Map<String, Object> map = new HashMap<>();
				Page<InterceptType> interceptType = interceptTypeService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize), intyName);// 当前页的记录数
				map.put("total", interceptType.getTotalRow());
				map.put("rows", interceptType.getList());
				render(new JsonRender(map).forIE());
			} else {
				// 加载权限
				SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
				setAttrs(AuthService.buttonAuthMap(user, "/interceptType"));
				setAttr("pageSize", Constant.backend_pagesize);
				render("index.html");
			}
		}
		
		// 添加
		public void add() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				InterceptType interceptType = getModel(InterceptType.class);
				String mess = interceptTypeService.add(interceptType);
				renderJson(new JsonRender(mess).forIE());
			} else {
				render("add.html");
			}
		}
		
		// 编辑
		public void edit() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				InterceptType interceptType = getModel(InterceptType.class);
				String mess = interceptTypeService.edit(interceptType);
				renderJson(new JsonRender(mess).forIE());
			} else {
				int id = getParaToInt("intercept_type_id");
				InterceptType interceptType = interceptTypeService.findById(id);
				setAttr("interceptType", interceptType);
				render("edit.html");
			}
		}

		// 删除
		public void del() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				int id = getParaToInt("id");
				String mess = interceptTypeService.del(id);
				render(new JsonRender(mess).forIE());
			}
		}
		//获取拦截类型集合
		public void getInterceptTypeList(){
			List<InterceptType> interceptTypeList = interceptTypeService.getInterceptTypeList();
			render(new JsonRender(interceptTypeList).forIE());
		}
}
