package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.model.GameType;
import com.cms.model.auth.SysUser;
import com.cms.service.GameTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 游戏类型管理控制器
 * @author Lisy
 *
 */
public class GameTypeController extends Controller{

	// 游戏类型管理服务类
	GameTypeService gameTypeService = enhance(GameTypeService.class);

	// 首页
	public void index() {
		String page = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 页大小

		if (page != null && pageSize != null) {
			Map<String, Object> map = new HashMap<String, Object>();
			Page<GameType> gameTypePage = gameTypeService.queryGameTypeByPage(Integer.parseInt(page), Integer.parseInt(pageSize));
			map.put("total", gameTypePage.getTotalRow());
			map.put("rows", gameTypePage.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/gameType"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}
	
	// 新增
	public void add(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			GameType gameType = getModel(GameType.class);
			String info = "";
			if(gameTypeService.addGameType(gameType)==true){
				info = BaseUtil.returnMess(1, "新增游戏类型成功！", "");
			}else{
				info = BaseUtil.returnMess(0, "新增游戏类型失败，请稍后重试！", "");
			}
			renderJson(new JsonRender(info).forIE());
		}else{
			render("add.html");
		}
	}
	
	// 修改
	public void edit(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			GameType gameType = getModel(GameType.class);
			String info = "";
			if(gameTypeService.updateGameType(gameType) == true){
				info = BaseUtil.returnMess(1, "修改游戏类型成功！", "");
			}else{
				info = BaseUtil.returnMess(0, "修改游戏类型失败，请稍后重试！", "");
			}
			renderJson(new JsonRender(info).forIE());
		}else{
			int gameTypeId = getParaToInt("game_type_id");
			GameType gameType = gameTypeService.queryGameTypeById(gameTypeId);
			setAttr("gameType", gameType);
			render("edit.html");
		}
	}
	
	// 删除
	public void del(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int gameTypeId = getParaToInt("id");
			String info = "";
			if(gameTypeService.delGameType(gameTypeId) == true){
				info = BaseUtil.returnMess(1, "删除游戏类型成功！", "");
			}else{
				info = BaseUtil.returnMess(0, "删除游戏类型失败，请稍后重试！", "");
			}
			renderJson(new JsonRender(info).forIE());
		}
	}

	// 获取所有游戏类型
	public void getAllGameTypes(){
		List<GameType> gameTypes = gameTypeService.queryAllGameType();
		render(new JsonRender(gameTypes).forIE());
	}
}
