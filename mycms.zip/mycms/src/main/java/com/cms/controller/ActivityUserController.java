package com.cms.controller;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.ExcelUtils;
import com.cms.model.ActivityUser;
import com.cms.model.ActivityUserExport;
import com.cms.model.auth.SysUser;
import com.cms.service.ActivityUserService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 控制器：活动用户
 * @author lisiyun
 *
 */
public class ActivityUserController extends Controller {
	/*活动用户服务类*/
	ActivityUserService activityUser = enhance(ActivityUserService.class);
	/**
	 * 查询活动用户
	 */
	public void index(){
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		String act_name = getPara("act_name"); //活动名称
		String acty_id = getPara("acty_id");//活动类型id
		String flag = getPara("flag"); //查询中奖，非中奖用户
		String getprize_time = getPara("getprize_time");//中奖时间
		String getprize_endTime = getPara("getprize_endTime");//最后中奖时间
		if (!BaseUtil.isNull(pageNumber) && !BaseUtil.isNull(pageSize)) {
			Map<String, Object> map = new HashMap<>();
			Page<ActivityUser> activity = activityUser.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), act_name, acty_id, flag, getprize_time, getprize_endTime);
			map.put("total", activity.getTotalRow());
			map.put("rows", activity.getList());
			render(new JsonRender(map).forIE());
		}else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/activityUser"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}
	
	
	/**
	 * 添加用户
	 */
	public void add(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = activityUser.addActivityUser(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}
	
	/*删除用户*/
	public void del(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = activityUser.delActivityUser(id);
			render(new JsonRender(mess).forIE());
		}
	}
	/*编辑用户*/
	public void edit(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			
			ActivityUser uset = getModel(ActivityUser.class);
			String mess = activityUser.eidtActivityPrize(uset);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("actu_id");
			ActivityUser user = activityUser.findById(id);
			setAttr("activityUser", user);
			setAttr("acty_id",user.getActyId());
			render("edit.html");
		}
	}
	
	

	
	/**
	 * 活动用户导出exec表
	 * @throws Exception 
	 */
	@SuppressWarnings("unused")
	public void Export(){
		String sheetName = "活动用户列表";
		String titleName = "活动用户列表";
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		String act_name = getPara("actu_name"); //活动名称
		String acty_id = getPara("acty_id");//活动类型id
		String flag = getPara("flag"); //查询中奖，非中奖用户
		String getprize_time = getPara("getprize_time");//中奖时间
		String getprize_endTime = getPara("getprize_endTime");//最后中奖时间
		if (!BaseUtil.isNull(pageNumber) && !BaseUtil.isNull(pageSize)) {
			Page<ActivityUser> list = activityUser.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), act_name, acty_id, flag, getprize_time, getprize_endTime);
			//标题
	        String[] headers  = { "id", "用户名", "联系方式","活动类型", "中奖奖品", "剩余抽奖次数", "登录排名 ", "访问时间", "获取奖日期" };
			List<ActivityUserExport> dataSet = new ArrayList<>();
			for (ActivityUser user : list.getList()) {
				ActivityUserExport us = new ActivityUserExport();
				us.setId(user.getActuId().toString());
				us.setActivityType((String)user.get("acty_title"));
				us.setPrizeType((String)user.get("actp_title"));
				us.setActivityUser(user.getActuName());
				us.setActivityUserPhone(user.getActuPhone());
				us.setLotteryCount(user.getActuGetprizeCount().toString());
				us.setLoginRanking(user.getActuLoginRank().toString());
				us.setLoginTime(user.getActuLoginTime());
				us.setWinningTime(user.getActuGetprizeTime());
			    dataSet.add(us);
			}
			String xlsPath = sheetName+".xls";
			String timeFormat = "yyyy-MM-dd HH:mm:ss";
			ExcelUtils.exportExcel(sheetName, titleName, headers, dataSet, xlsPath, timeFormat);
			// 文件是否存在
			File file = new File(xlsPath);
			if (file != null) {
				renderFile(file);
			}else{
				renderHtml("<h2>数据导出出错！请刷新当前栏目重试或联系管理员！</h2>");
			}
		}else{
			renderNull();
		}
		
	}
}
