package com.cms.controller;
import java.util.HashMap;
import java.util.Map;
import com.cms.common.Constant;
import com.cms.model.SignPoints;
import com.cms.model.auth.SysUser;
import com.cms.service.SignPointsService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 积分首页管理控制器
 * 
 * @author Lisy
 * @date 2020-05-21
 */
public class SignPointsController extends Controller {
	SignPointsService signPointsService = enhance(SignPointsService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String sign_points_id = getPara("sign_points_id");
		String sign_points_name = getPara("sign_points_name");
		String sign_points_integral = getPara("sign_points_integral");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<SignPoints> signPoints = signPointsService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),
					sign_points_id, sign_points_name, sign_points_integral);
			map.put("total", signPoints.getTotalRow());
			map.put("rows", signPoints.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/signPoints"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = signPointsService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = signPointsService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = signPointsService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			SignPoints signPoints = signPointsService.findById(getParaToInt("sign_points_id"));
			setAttr("signPoints", signPoints);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
