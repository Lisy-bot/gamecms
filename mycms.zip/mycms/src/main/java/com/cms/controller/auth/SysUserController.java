package com.cms.controller.auth;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.auth.SysUser;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysRoleService;
import com.cms.service.auth.SysUserService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 控制器：系统用户
 * @author tanzhuo
 * @date 2017年3月25日
 */
public class SysUserController extends Controller {

	// 系统用户服务类
	SysUserService userService = enhance(SysUserService.class);
	// 系统角色
	SysRoleService roleService = enhance(SysRoleService.class);

	// 首页
	public void index() {
		String page = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小

		if (page != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<SysUser> userPage = userService.queryAll(Integer.parseInt(page), Integer.parseInt(pageSize));// 当前页的记录数
			map.put("total", userPage.getTotalRow());
			map.put("rows", userPage.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/sysUser"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysUser sysUser = getModel(SysUser.class);
			Integer[] roleId = getParaValuesToInt("roleId");
			String mess = userService.addSysUser(sysUser, roleId);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysUser sysUser = getModel(SysUser.class);
			Integer[] roleId = getParaValuesToInt("roleId");
			String mess = userService.editSysUser(sysUser, roleId);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("sysu_id");
			SysUser sysUser = userService.findById(id);
			List<Integer> roleIds = userService.getRoleIds(id);
			setAttr("sysUser", sysUser);
			setAttr("roleIds", roleIds);
			render("edit.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = userService.del(id);
			render(new JsonRender(mess).forIE());
		}
	}

	/**
	 * 向账号中心同步用户列表
	 */
	public void getUserList() {
		String mess = userService.getUserList();
		renderJson(new JsonRender(mess).forIE());
	}
}
