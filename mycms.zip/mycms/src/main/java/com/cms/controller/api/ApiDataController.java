package com.cms.controller.api;

import com.cms.service.api.ApiDataService;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;

/**
 * 控制器：后台数据api接口
 * @author tanzhuo
 * @date 2017年12月4日
 */
@Clear
public class ApiDataController extends Controller {
	// API服务类
	ApiDataService apiDataService = enhance(ApiDataService.class);

	/**
	 * 账号中心下发用户列表
	 */
	public void getUserList() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String data = getPara("data");
			if (data == null) {
				renderText("error");
			} else {
				String mess = apiDataService.getUserList(data);
				renderText(mess);
			}
		} else {
			renderText("ok");
		}
	}

}
