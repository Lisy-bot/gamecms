package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.User;
import com.cms.model.auth.SysUser;
import com.cms.service.UserService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

public class UserController extends Controller {
	UserService userService = enhance(UserService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 用户订购状态态查询
		String user_account = getPara("user_account");
		String user_order_status = getPara("user_order_status");
		String prize_id = getPara("prizeId");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<User> user = userService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), user_account, user_order_status, prize_id);
			map.put("total", user.getTotalRow());
			map.put("rows", user.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/user"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = userService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = userService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = userService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			User user = userService.findById(getParaToInt("user_id"));
			setAttr("user", user);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
