package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.ActivityPrize;
import com.cms.model.auth.SysUser;
import com.cms.service.ActivityPrizeService;
import com.cms.service.ActivityTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 控制器活动奖品
 * @author lisiyun
 * @date 2017-06-07
 */
public class ActivityPrizeController extends Controller {
	/*活动奖品服务类*/
	ActivityPrizeService activityPrize = enhance(ActivityPrizeService.class);
	/*活动类型服务类*/
	ActivityTypeService activityType = enhance(ActivityTypeService.class);
	public void index(){
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		String acty_title = getPara("acty_title"); //奖品名称
		String actp_title = getPara("actp_title"); //活动类型名称
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<ActivityPrize> activity = activityPrize.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), acty_title, actp_title);
			map.put("total", activity.getTotalRow());
			map.put("rows", activity.getList());
			render(new JsonRender(map).forIE());
		}else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/activityPrize"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}
	/**
	 * 添加奖品
	 */
	public void add(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = activityPrize.addActivityPrize(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}
	
	/*删除奖品*/
	public void del(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = activityPrize.delActivityPrize(id);
			render(new JsonRender(mess).forIE());
		}
	}
	/*编辑奖品*/
	public void edit(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = activityPrize.eidtActivityPrize(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			setAttr("resouceUrl", Constant.resouceUrl);
			int id = getParaToInt("actp_id");
			ActivityPrize activity = activityPrize.findById(id);
			setAttr("activityPrize", activity);
			render("edit.html");
		}
	}
	
	
	//获取奖品类型下拉列表
	public void getPrizeList(){
		String acty_id = getPara("acty_id");//奖品类型
		List<ActivityPrize> list = activityPrize.getPrizeType(acty_id);
		render(new JsonRender(list).forIE());
	}
}
