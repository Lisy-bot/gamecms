package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONArray;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.model.PointsSysImg;
import com.cms.model.auth.SysUser;
import com.cms.service.PointsSysImgService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 积分首页管理控制器
 * 
 * @author Lisy
 * @date 2020-05-22
 */
public class PointsSysImgController extends Controller {
	PointsSysImgService pointsSysImgService = enhance(PointsSysImgService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String points_sys_type_id = getPara("points_sys_type_id");
		String point_sys_name = getPara("point_sys_name");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<PointsSysImg> pointsSysImg = pointsSysImgService.queryAll(Integer.parseInt(pageNumber),
					Integer.parseInt(pageSize), point_sys_name, points_sys_type_id);
			map.put("total", pointsSysImg.getTotalRow());
			map.put("rows", pointsSysImg.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/pointsSysImg"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysImgService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}
	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysImgService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsSysImgService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			PointsSysImg pointsSysImg = pointsSysImgService.findById(getParaToInt("points_sys_id"));
			setAttr("pointsSysImg", pointsSysImg);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}

	/**
	 * 根据类型id 获取json中父级页面类型
	 */

	public void getPointsSysPageType() {
		if (getRequest().getMethod().equalsIgnoreCase("GET")) {
			PointsSysImg pointsSysImg = pointsSysImgService.getPointsSysTypeId(getParaToInt("id"));
			if(pointsSysImg != null) {
				PointsSysImg poImg = pointsSysImgService.getPointsSysPageType(pointsSysImg.getPointsSysId());
				String  jsonString  = poImg.getPointsSysJson();
				if (!BaseUtil.isNull(jsonString)) {
					renderJson(new JsonRender(jsonString).forIE());
				} else {
					JSONArray  array = new JSONArray();
					renderJson(new JsonRender(array).forIE());
				}
			}

		}
	}
	/**
	 * 根据id 获取json中父级页面类型
	 */

	public void getPointsSysImgJson() {
		if (getRequest().getMethod().equalsIgnoreCase("GET")) {
				PointsSysImg poImg = pointsSysImgService.getPointsSysPageType(getParaToInt("id"));
				String  jsonString  = poImg.getPointsSysJson();
				if (!BaseUtil.isNull(jsonString)) {
					renderJson(new JsonRender(jsonString).forIE());
				} else {
					JSONArray  array = new JSONArray();
					renderJson(new JsonRender(array).forIE());
				}
			}
	}
}
