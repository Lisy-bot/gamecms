package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.PointsHome;
import com.cms.model.auth.SysUser;
import com.cms.service.PointsHomeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 积分首页管理控制器
 * 
 * @author Lisy
 * @date 2020-05-14
 */
public class PointsHomeController extends Controller {
	PointsHomeService pointsHomeService = enhance(PointsHomeService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String points_home_id = getPara("points_home_id");
		String points_home_name = getPara("points_home_name");
		String points_home_online = getPara("points_home_online");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<PointsHome> home = pointsHomeService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),
					points_home_id, points_home_name, points_home_online);
			map.put("total", home.getTotalRow());
			map.put("rows", home.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/pointsHome"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsHomeService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsHomeService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = pointsHomeService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			PointsHome pointsHome = pointsHomeService.findById(getParaToInt("points_home_id"));
			setAttr("pointsHome", pointsHome);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
