package com.cms.controller.auth;

import com.cms.common.Constant;
import com.cms.model.auth.SysResource;
import com.cms.model.auth.SysUser;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.ResourceService;
import com.jfinal.core.Controller;
import com.jfinal.render.JsonRender;

/**
 * 控制器：访问资源控制器
 * @author tanzhuo
 * @date 2017年5月16日
 */
public class ResourceController extends Controller {
	// 资源服务类
	ResourceService resourceService = enhance(ResourceService.class);

	// 资源首页
	public void index() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String noType = getPara("no");
			renderJson(resourceService.queryAll(noType));
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/resource"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}

	// 添加资源
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysResource sysResource = getModel(SysResource.class);
			String mess = resourceService.add(sysResource);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			SysResource sysResource = getModel(SysResource.class);
			String mess = resourceService.edit(sysResource);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("res_id");
			SysResource sysResource = resourceService.findById(id);
			setAttr("sysResource", sysResource);
			render("edit.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = resourceService.del(id);
			render(new JsonRender(mess).forIE());
		}
	}
}
