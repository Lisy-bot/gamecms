package com.cms.controller;

import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.Game;
import com.cms.model.auth.SysUser;
import com.cms.service.GameService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 游戏管理控制器
 * @author Lisy
 *
 */
public class GameController extends Controller{
	// 游戏类型管理服务类
		GameService gameService = enhance(GameService.class);
		// 首页
		public void index() {
			String pageNumber = getPara("page"); // 当前页
			String pageSize = getPara("rows"); // 每页大小
			// 根据 搜索名称，或 上线状态查询
			String gameId = getPara("game_id");
			String gameName = getPara("game_name");
			String gameTypeId = getPara("game_type_id");
			String gameOnline = getPara("game_online");
			if (pageNumber != null && pageSize != null) {
				Map<String, Object> map = new HashMap<>();
				Page<Game> game = gameService.queyAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize), gameId, gameName, gameTypeId, gameOnline);
				map.put("total", game.getTotalRow());
				map.put("rows", game.getList());
				render(new JsonRender(map).forIE());
			} else {
				// 加载权限
				SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
				setAttrs(AuthService.buttonAuthMap(user, "/game"));
				setAttr("pageSize", Constant.backend_pagesize);
				render("index.html");
			}

		}

		// 添加
		public void add() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				String mess = gameService.add(this);
				renderJson(new JsonRender(mess).forIE());
			} else {
				render("add.html");
			}
		}

		// 删除
		public void del() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				String mess = gameService.del(this);
				renderJson(new JsonRender(mess).forIE());
			}
		}

		// 编辑
		public void edit() {
			if (getRequest().getMethod().equalsIgnoreCase("post")) {
				String mess = gameService.edit(this);
				renderJson(new JsonRender(mess).forIE());
			} else {
				Game game = gameService.findById(getParaToInt("game_id"));
				setAttr("game", game);
				setAttr("resouceUrl", Constant.resouceUrl);
				render("edit.html");
			}
		}
}
