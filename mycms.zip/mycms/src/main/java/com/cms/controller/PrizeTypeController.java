package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.PrizeType;
import com.cms.model.auth.SysUser;
import com.cms.service.PrizeTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 积分首页管理控制器
 * 
 * @author Lisy
 * @date 2020-05-22
 */
public class PrizeTypeController extends Controller {
	PrizeTypeService prizeTypeService = enhance(PrizeTypeService.class);

	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String prize_type_id = getPara("prize_type_id");
		String prize_type_name = getPara("prize_type_name");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<PrizeType> prizeType = prizeTypeService.queryAll(Integer.parseInt(pageNumber),
					Integer.parseInt(pageSize), prize_type_id, prize_type_name);
			map.put("total", prizeType.getTotalRow());
			map.put("rows", prizeType.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/pointsHome"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = prizeTypeService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = prizeTypeService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = prizeTypeService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			PrizeType prizeType = prizeTypeService.findById(getParaToInt("prize_type_id"));
			setAttr("prizeType", prizeType);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
	public void getPrizeTypeList() {
		if (getRequest().getMethod().equalsIgnoreCase("get")) {
			List<PrizeType> mess = prizeTypeService.getPrizeTypeList();
			renderJson(new JsonRender(mess).forIE());
		}
	}
}
