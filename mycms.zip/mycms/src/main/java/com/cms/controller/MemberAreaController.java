package com.cms.controller;
import java.util.HashMap;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.MemberArea;
import com.cms.model.auth.SysUser;
import com.cms.service.MemberAreaService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;

/**
 * 会员专享福利特权专区控制器
 * @author Lisy
 * @date 2020-05-18
 */
public class MemberAreaController extends Controller {
	MemberAreaService memberAreaService = enhance(MemberAreaService.class);
	// 首页
	public void index() {
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		// 根据 搜索名称，或 上线状态查询
		String member_area_id = getPara("member_area_id");
		String member_area_name = getPara("member_area_name");
		String member_area_online = getPara("member_area_online");
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<MemberArea> member_area = memberAreaService.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),
					member_area_id, member_area_name, member_area_online);
			map.put("total", member_area.getTotalRow());
			map.put("rows", member_area.getList());
			render(new JsonRender(map).forIE());
		} else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/memberArea"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}

	}

	// 添加
	public void add() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberAreaService.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}

	// 删除
	public void del() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberAreaService.del(this);
			renderJson(new JsonRender(mess).forIE());
		}
	}

	// 编辑
	public void edit() {
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = memberAreaService.edit(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			MemberArea memberArea = memberAreaService.findById(getParaToInt("member_area_id"));
			setAttr("memberArea", memberArea);
			setAttr("resouceUrl", Constant.resouceUrl);
			render("edit.html");
		}
	}
}
