package com.cms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.model.ActivityType;
import com.cms.model.auth.SysUser;
import com.cms.service.ActivityTypeService;
import com.cms.service.auth.AuthService;
import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.render.JsonRender;
/**
 * 控制器：活动类型管理
 * @author lisiyun
 * @date 2017-06-07
 */
public class ActivityTypeController extends Controller{
	//活动类型服务类
	ActivityTypeService activityType = enhance(ActivityTypeService.class);
	public void index(){
		String pageNumber = getPara("page"); // 当前页
		String pageSize = getPara("rows"); // 每页大小
		String act_name = getPara("act_name"); //活动名称
		if (pageNumber != null && pageSize != null) {
			Map<String, Object> map = new HashMap<>();
			Page<ActivityType> activity = activityType.queryAll(Integer.parseInt(pageNumber), Integer.parseInt(pageSize),act_name);
			map.put("total", activity.getTotalRow());
			map.put("rows", activity.getList());
			render(new JsonRender(map).forIE());
		}else {
			// 加载权限
			SysUser user = getSessionAttr(Constant.CONST_SESSION_SYS_USER);
			setAttrs(AuthService.buttonAuthMap(user, "/activityType"));
			setAttr("pageSize", Constant.backend_pagesize);
			render("index.html");
		}
	}
	/*添加活动类型*/
	public void add(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			String mess = activityType.add(this);
			renderJson(new JsonRender(mess).forIE());
		} else {
			render("add.html");
		}
	}
	
	/*删除活动类型*/
	public void del(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			int id = getParaToInt("id");
			String mess = activityType.delActivityType(id);
			render(new JsonRender(mess).forIE());
		}
	}
	/*编辑活动类型*/
	public void edit(){
		if (getRequest().getMethod().equalsIgnoreCase("post")) {
			
			ActivityType activ = getModel(ActivityType.class);
			activ.set("begin_time", getPara("begin_time"));
			activ.set("end_time", getPara("end_time"));
			String mess = activityType.eidtActivityType(activ);
			renderJson(new JsonRender(mess).forIE());
		} else {
			int id = getParaToInt("acty_id");
			ActivityType activity = activityType.findById(id);
			setAttr("activityType", activity);
			render("edit.html");
		}
	}
	// 获取活动类型下拉列表
		public void getAlls() {
			List<ActivityType> list = activityType.getActyList();
			render(new JsonRender(list).forIE());
		}
}
