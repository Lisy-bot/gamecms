package com.cms.common;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.druid.filter.logging.Slf4jLogFilter;
import com.alibaba.druid.wall.WallFilter;
import com.cms.common.util.Slf4jLogFactory;
import com.cms.model._MappingKit;
import com.cms.model.auth.SysUser;
import com.cms.routes.AdminRoutes;
import com.cms.service.auth.AuthService;
import com.cms.service.auth.SysSettingService;
import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.ext.handler.ContextPathHandler;
import com.jfinal.ext.interceptor.SessionInViewInterceptor;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.plugin.druid.DruidStatViewHandler;
import com.jfinal.plugin.druid.IDruidStatViewAuth;
import com.jfinal.render.ViewType;
import com.jfinal.template.Engine;

/**
 * 配置
 * @author Admins
 * @date 2017年4月23日
 */
public class WebConfig extends JFinalConfig {

	@Override
	public void configConstant(Constants me) {
		// 加载少量必要配置，随后可用getProperty(...)获取值
		loadPropertyFile("config.properties");
		// 设置当前开发模式 如果设置为true 控制台会输出每次请求的Controller action和参数信息
		me.setDevMode(getPropertyToBoolean("devMode", false));
		// 设置视图类型,jfianl_template
		me.setViewType(ViewType.JFINAL_TEMPLATE);
		// 设置Slf4日志
		me.setLogFactory(new Slf4jLogFactory());
		// 设置http 404错误跳转页面
		me.setError404View("/static/template/error/404.html");
		me.setError500View("/static/template/error/500.html");
		// 设置文件下载地址
		// me.setFileRenderPath("/download");
		// 设置上传文件默认保存路径根目录
		me.setBaseUploadPath("upload/temp");
		// 默认大小
		me.setMaxPostSize(getPropertyToInt("maxSize"));
	}

	/**
	 * 配置模板
	 */
	@Override
	public void configEngine(Engine me) {
		// me.setDevMode(true);
		// 配置极速模式，性能提升 13%
		me.setDevMode(true);
		me.addSharedFunction("/static/template/common/_layout.html");
	}

	/**
	 * 配置全局公共处理器
	 */
	@Override
	public void configHandler(Handlers me) {
		me.add(new ContextPathHandler());
		// druid监控
		DruidStatViewHandler dvh = new DruidStatViewHandler("/druid", new IDruidStatViewAuth() {
			public boolean isPermitted(HttpServletRequest request) {
				// 判断当前登录用户账号，且做权限判断
				SysUser user = (SysUser) request.getSession().getAttribute(Constant.CONST_SESSION_SYS_USER);
				boolean auth = AuthService.haveAuth(user, "/druid/index");
				if (user == null) {
					return false;
				} else if (auth) {
					return true;
				}
				return false;
			}
		});
		me.add(dvh);
	}

	/**
	 * 配置全局拦截器
	 */
	@Override
	public void configInterceptor(Interceptors me) {
		me.add(new SessionInViewInterceptor());
	}

	/**
	 * 配置插件
	 */
	@Override
	public void configPlugin(Plugins me) {
		DruidPlugin druid = new DruidPlugin(getProperty("jdbcUrl"), getProperty("username"), getProperty("password"));
		// 初始连接池大小、最小空闲连接数、最大活跃连接数
		druid.set(getPropertyToInt("initialSize"), getPropertyToInt("minIdle"), getPropertyToInt("maxActive"));
		// 设置druid过滤器
		druid.setFilters("stat,wall");
		druid.addFilter(new Slf4jLogFilter());
		WallFilter wall = new WallFilter();
		wall.setDbType("mysql");
		druid.addFilter(wall);

		me.add(druid);

		ActiveRecordPlugin arp = new ActiveRecordPlugin(druid);
		me.add(arp);
		// 显示sql
		arp.setShowSql(getPropertyToBoolean("devSqlMode", false));
		// 所有配置在 MappingKit
		_MappingKit.mapping(arp);
	}

	/**
	 * 配置路由映射
	 */
	@Override
	public void configRoute(Routes me) {
		me.add(new AdminRoutes()); // 后台路由
	}

	/**
	 * 项目启动执行
	 */
	public void afterJFinalStart() {
		// 初始化系统配置，上传路径等
		SysSettingService.initSetting();
	}

	/**
	 * 项目关闭执行
	 */
	public void beforeJFinalStop() {
		// 释放mysql驱动，防止druid报错
		Enumeration<java.sql.Driver> drivers = DriverManager.getDrivers();
		if (drivers != null) {
			while (drivers.hasMoreElements()) {
				try {
					Driver driver = drivers.nextElement();
					DriverManager.deregisterDriver(driver);
				} catch (Exception e) {
					System.out.println((e));
				}
			}
		}
	}
}
