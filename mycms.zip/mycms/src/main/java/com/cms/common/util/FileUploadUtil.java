package com.cms.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.upload.UploadFile;

/**
 * 文件上传工具类
 * 
 * @author tanzhuo
 * @date 2017年4月8日
 */
public class FileUploadUtil {

    /**
     * 弃用 文件上传，先传到临时路径，再移动
     * 
     * @param controller
     * @param name 参数名
     * @param outPath 输出目录
     * @return 文件夹/文件名
     */
    @Deprecated
    public static String uploadImageFile(Controller controller, String name, String outPath) {
        int maxSize = Integer.parseInt(PropKit.use("resource/config.properties").get("maxSize"));
        try {
            UploadFile file = controller.getFile(name, "", maxSize, "utf-8");// 上传文件
            if (file.getFileName().toLowerCase().endsWith(".png") || file.getFileName().toLowerCase().endsWith(".jpg")
                || file.getFileName().toLowerCase().endsWith(".gif")) {
                // 重命名
                String newFile = updateFileName(file.getUploadPath() + file.getFileName(), null);
                if (newFile != null) {
                    // 移动文件
                    String move = moveFile(newFile, outPath);
                    if (move != null) {
                        move = move.replace("\\\\", "/").replace("\\", "/").replace("//", "/");
                        String[] sp = move.split("/");
                        int num = sp.length;
                        if (num - 2 > 0) {
                            return sp[num - 2] + "/" + sp[num - 1]; // 文件夹/文件名
                        }
                    }
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    /**
     * 文件改名
     * 
     * @param pathFile 文件绝对路径
     * @param newName 新名字，不带后缀
     * @return 文件决定路径
     */
    public static String updateFileName(String pathFile, String newName) {
        File oldFile = new File(pathFile);
        if (oldFile.exists()) {
            String rootPath = oldFile.getParent();
            String prefix = oldFile.getName().substring(oldFile.getName().lastIndexOf("."));
            if (newName == null) {// 时间戳命名
                File newFile = new File(rootPath + File.separator + BaseUtil.getRandTime() + prefix);
                oldFile.renameTo(newFile);
                return newFile.getAbsolutePath();
            } else {
                File newFile = new File(rootPath + File.separator + newName + prefix);
                oldFile.renameTo(newFile);
                return newFile.getAbsolutePath();
            }
        }
        return null;
    }

    /**
     * 文件移动
     * 
     * @param pathFile 文件所在绝对路径
     * @param outPath 目标路径
     * @return 文件绝对路径
     */
    public static String moveFile(String pathFile, String outPath) {
        File oldFile = new File(pathFile);
        outPath += "/";
        File path = new File(outPath);
        if (!path.exists()) {
            path.mkdirs();
        }
        File newFile = new File(outPath + oldFile.getName());
        /*
        由于Java linux 系统上移动文件出现文件移动不过去的问题，将文件的renameTo方法改为Files.copy的方法，然后在删除原来的文件
        if (oldFile.renameTo(newFile)) {
        	return newFile.getAbsolutePath();
        }*/
        try {
            Path result = Files.copy(oldFile.toPath(), newFile.toPath());
            oldFile.delete();
            return result.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 删除文件
     * 
     * @param filePath
     * @return
     */
    public static boolean delFile(String filePath) {
        File file = new File(filePath);
        if (file.exists() && file.isFile()) {
            if (file.delete()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 图片文件类型检查
     * 
     * @param ContentType 文件类型
     * @return
     */
    public static boolean checkImageType(String ContentType) {
        if ("image/png".equals(ContentType) || "image/jpeg".equals(ContentType) || "image/gif".equals(ContentType)) {
            return true;
        }
        return false;
    }

    /**
     * 文件类型检查
     * 
     * @param ContentType 文件类型
     * @return
     */
    public static boolean checkFileType(String ContentType) {
        if ("image/png".equals(ContentType) || "image/jpg".equals(ContentType) || "image/gif".equals(ContentType)
            || "file/zip".equals(ContentType) || "file/jar".equals(ContentType) || "file/jad".equals(ContentType)) {
            return true;
        }
        return false;
    }

    /**
     * 广告文件重命名后移动
     * 
     * @param pathFile 文件所在绝对路径
     * @param outPath 目标路径
     */
    public static String moveNewFile(String pathFile, String outPath) {
        // 重命名
        String newFile = updateFileName(pathFile, null);
        if (newFile != null) {
            // 移动文件
            String move = moveFile(newFile, outPath);
            if (move != null) {
                move = move.replace("\\\\", "/").replace("\\", "/").replace("//", "/");
                String[] sp = move.split("/");
                int num = sp.length;
                if (num - 3 > 0) {
                    return sp[num - 2] + "/" + sp[num - 1]; // 文件夹/文件名
                }
            }
        }
        return null;
    }
    /**
     * 广告文件重命名后移动，返回图片
     * 
     * @param pathFile 文件所在绝对路径
     * @param outPath 目标路径
     */
    public static String moveFiles(String pathFile, String outPath) {
        // 重命名
        String newFile = updateFileName(pathFile, null);
        if (newFile != null) {
            // 移动文件
            String move = moveFile(newFile, outPath);
            if (move != null) {
                move = move.replace("\\\\", "/").replace("\\", "/").replace("//", "/");
                String[] sp = move.split("/");
                int num = sp.length;
                if (num - 3 > 0) {
                    return sp[num - 1]; //文件名
                }
            }
        }
        return null;
    }
    /**
     * 游戏图片重命名后移动
     * 
     * @param pathFile 文件所在绝对路径
     * @param outPath 目标路径
     */
    public static String moveGameNewFile(String pathFile, String outPath) {
        // 重命名
        String newFile = updateFileName(pathFile, null);
        if (newFile != null) {
            // 移动文件
            String move = moveFile(newFile, outPath);
            if (move != null) {
                move = move.replace("\\\\", "/").replace("\\", "/").replace("//", "/");
                String[] sp = move.split("/");
                int num = sp.length;
                if (num - 3 > 0) {
                    return sp[num - 3] + "/" + sp[num - 2] + "/" + sp[num - 1]; // 文件夹/文件名
                }
            }
        }
        return null;
    }

    /**
     * 移动游戏包
     * 
     * @param pathFile
     * @param outPath
     * @return
     */
    public static String moveGameFile(String pathFile, String outPath) {
        // 重命名
        File newFile = new File(pathFile);
        if (newFile != null) {
            // 移动文件
            String move = moveFile(newFile.getAbsolutePath(), outPath);
            if (move != null) {
                move = move.replace("\\\\", "/").replace("\\", "/").replace("//", "/");
                String[] sp = move.split("/");
                int num = sp.length;
                if (num - 3 > 0) {
                    return sp[num - 3] + "/" + sp[num - 2] + "/" + sp[num - 1]; // 文件夹/文件名
                }
            }
        }
        return null;
    }

    /**
     * 解压zip格式的压缩文件到指定位置
     * 
     * @param zipFileName 压缩文件
     * @param extPlace 解压目录
     */
    public static void unzip(String zipFileName, String extPlace) {
        try {
            ZipUtil.decompress(zipFileName, extPlace);
        } catch (Exception e) {
             e.printStackTrace();
        }
    }

    /**
     * 删除文件夹
     * 
     * @param file 文件
     */
    public static void deleteFile(File file) {
        if (file.exists()) {
            if (file.isDirectory()) {
                File files[] = file.listFiles();
                for (int i = 0; i < files.length; i++) {
                    deleteFile(files[i]); // 迭代删除
                }
            }
            file.delete();
        } else {
            System.out.println("所删除的文件不存在！" + '\n');
        }
    }

    /**
     * 复制文件
     * 
     * @param inputFile 原路径
     * @param outputFile 需要复制到的路径
     * @return
     */
    public static String copyFile(File inputFile, File outputFile) {
        InputStream inStream = null;
        OutputStream outStream = null;
        try {
            inStream = new FileInputStream(inputFile);
            outStream = new FileOutputStream(outputFile);
            // inputFile.length(),用输入文件的字节长度作为开辟的字节数组的长度
            byte[] b = new byte[(int)inputFile.length()];
            inStream.read(b);
            // 把输入流中 的内容取出来，并把内容读取到byte数组中（一次性读出）
            outStream.write(b);
            // 将byte数组中的内容写到输出流中（一次性写入）
            inStream.close();
            outStream.close();
        } catch (IOException e) {
            return BaseUtil.returnMess(0, "游戏添加失败，复制文件" + inputFile + "到" + outputFile + "时出错", "");
        } finally {
            try {
                inStream.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return null;
    }

}
