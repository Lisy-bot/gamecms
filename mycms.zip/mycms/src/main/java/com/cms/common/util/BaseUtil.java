package com.cms.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

import javax.servlet.http.HttpServletRequest;

import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.upload.UploadFile;

/**
 * 公共工具类
 * @author tanzhuo
 * @date 2017年3月25日
 */
public class BaseUtil {

	/**
	 * 获取前端异步交互时后台响应的结果
	 * @param status 状态：1-成功，0-失败
	 * @param info	响应信息
	 * @param data	成功状态返回的数据
	 * @return map
	 */
	public static String returnMess(Object status, String info, Object data) {
		return "{\"status\":\"" + status + "\",\"info\":\"" + info + "\",\"data\":\"" + data + "\"}";
	}

	/**
	 * 获取客户端ip
	 * @param request
	 * @return
	 */
	public static String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
			if (ip.equals("127.0.0.1")) {
				// 根据网卡取本机配置的IP
				InetAddress inet = null;
				try {
					inet = InetAddress.getLocalHost();
					ip = inet.getHostAddress();
				} catch (UnknownHostException e) {
					System.out.println("get ip error." + e.toString());
				}
			}
		}

		// 多个路由时，取第一个非unknown的ip
		final String[] arr = ip.split(",");
		for (final String str : arr) {
			if (!"unknown".equalsIgnoreCase(str)) {
				ip = str;
				break;
			}
		}

		return ip;
	}

	/**
	 * 获取时间戳+随机数
	 * @return
	 */
	public static String getRandTime() {
		return System.currentTimeMillis() + "" + (new java.util.Random().nextInt(1000));
	}

	/**
	 * 判断是否是数字
	 * @param str
	 * @return
	 */
	public static boolean isNumer(Object str) {
		if (str != null) {
			Pattern pattern = Pattern.compile("[0-9]*");
			Matcher isNum = pattern.matcher(str.toString());
			if (isNum.matches()) {
				return true;
			}
		}
		return false;
	}
	/**
	 * 判断只能输入英文
	 * @param input
	 * @return
	 */
	public static boolean isEnglish(String str) {
		Pattern pattern = Pattern.compile("^[A-Za-z]+$");
		Matcher m = pattern.matcher(str);
		if (!m.matches()) { // 匹配不到,說明輸入的不符合條件
			return false;
		}
		return true;
	}
	/**
	 * 判断是否为空，空返回true
	 * @param value
	 * @return
	 */
	public static boolean isNull(Object value) {
		if (value != null && !"".equals(value) && !"null".equals(value) && !"undefined".equals(value)) {
			return false;
		}
		return true;
	}

	/**
	 * 判断是否是系统服务时间
	 * @return
	 */
	public static boolean isRunTime() {
		try {
			SimpleDateFormat spf = new SimpleDateFormat("HH:mm");
			Date date = spf.parse(spf.format(new Date()));
			Date start = spf.parse(PropKit.use("config.properties").get("startTime"));
			Date end = spf.parse(PropKit.use("config.properties").get("endTime"));

			if ((date.getTime() > start.getTime()) && (date.getTime() < end.getTime())) {
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	/**
	 * 时间相减
	 * @param bigDate
	 * @param smallDate
	 * @return 分钟
	 */
	public static long timeMinus(Date bigDate, Date smallDate) {
		return (bigDate.getTime() - smallDate.getTime()) / (1000 * 60);
	}

	/**
	 * 出路数据库存游戏配置
	 * @param params
	 * @return
	 */
	public static String handParams(String params) {
		if (params != null) {
			StringBuffer result = new StringBuffer();
			Map<String, String> map = new HashMap<String, String>();
			String[] arr = params.split("\n");
			for (int i = 0; i < arr.length; i++) {
				String[] code = arr[i].split("=");
				if (code.length > 1) {
					map.put(code[0].trim(), code[1].trim());
				}
			}
			for (String key : map.keySet()) {
				result.append("<param name=\"" + key + "\" value=\"" + map.get(key) + "\" />\n");
			}
			return result.toString();
		} else {
			return null;
		}
	}

	/**
	 * 处理页面显示游戏配置
	 * @param params
	 * @return
	 */
	public static String unhandParams(String params) {
		if (params != null) {
			params = params.replace("<param ", "").replace("\"", "").replace("\n", "").replace("/>", "").replaceFirst("name=", "").replace("value=",
			        "");
			StringBuffer result = new StringBuffer();
			Map<String, String> map = new HashMap<String, String>();
			String[] arr = params.split("name=");
			for (int i = 0; i < arr.length; i++) {
				String[] code = arr[i].split(" ");
				map.put(code[0], code[1]);
			}
			for (String key : map.keySet()) {
				result.append(key + "=" + map.get(key) + "\n");
			}
			return result.toString();
		} else {
			return null;
		}
	}

	/**
	 * 获取去掉"-" UUID
	 * @return
	 */
	public static String get32UUID() {
		return UUID.randomUUID().toString().replace("-", "");
	}

	/**
	 * 时间超时验证（超过多少分钟则返回false）
	 * @param time 时间
	 * @param num 分钟
	 * @return
	 */
	public static boolean minuteTimeOut(long time, int num) {
		long nowData = System.currentTimeMillis();
		nowData = (nowData - time) / 1000 / 60;
		if (nowData < num) {
			return true;
		}
		return false;
	}

	/**
	 * 获取文件CRC32码
	 * @param file
	 * @return
	 */
	public static String getCRC32(File file) {
		CRC32 crc32 = new CRC32();
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(file);
			byte[] buffer = new byte[8192];
			int length;
			while ((length = fileInputStream.read(buffer)) != -1) {
				crc32.update(buffer, 0, length);
			}
			return String.format("%08X", crc32.getValue());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fileInputStream != null)
					fileInputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	/**
	 * 获取上传的文件
	 * @param controller
	 * @return
	 */
	public static List<UploadFile> getFile(Controller controller){
		// 上传文件
		List<UploadFile> list = null;
		try {
			list = controller.getFiles();
		} catch (Exception e) {
			if (e instanceof com.oreilly.servlet.multipart.ExceededSizeException) {
				return null;
			}
		}
		return list;
	}
}
