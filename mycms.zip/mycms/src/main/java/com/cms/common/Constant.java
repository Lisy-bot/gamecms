package com.cms.common;

/**
 * 常量类
 * 
 * @author tanzhuo
 * @date 2016年7月7日
 */
public class Constant {
	 // 成功
	public static final String CONST_SUCCESS = "success";
	 // 失败
	public static final String CONST_ERROR = "error";
	// 状态：启用
	public static final int CONST_STATUS_ENABLE = 1; 
	// 状态：禁用
	public static final int CONST_STATUS_DISABLE = 0; 
	 // 管理员用户变量名（session）
	public static final String CONST_SESSION_SYS_USER = "backend_sys_user";
	// 超级管理用户标识
	public static final int CONST_SYS_SUPER_USER = 1; 
	 // 资源可以访问标示
	public static final int CONST_RES_ACCESS_AUTH_YES = 1;
	// 资源不能访问标示
	public static final int CONST_RES_ACCESS_AUTH_NO = 0; 
	// 每页显示数据条数
	public static final int backend_pagesize = 30; 
	// 系统标题
	public static String title;
	// 资源URL
	public static String resouceUrl;
	// 根目录
	public static String baseUploadPath;
	// 公钥
	public static String publicKey;
	// 私钥
	public static String privateKey;
	// tomcat 上传路径
	public static String tomcatUploadPath;
	// 广告上传路径
	public static String advertUploadPath;
	// 游戏上传路径
	public static String gameUploadPath;
}
