package com.cms.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/**
 * Excel表操作工具类  导出，获取excelq全部数据
 * @author lisiyun
 *
 */
public class ExcelUtils {

	public static final String HEADERINFO = "headInfo";
	public static final String DATAINFON = "dataInfo";

	/**
	 * 
	 * @Title: getWeebWork
	 * @Description: TODO(根据传入的文件名获取工作簿对象(Workbook))
	 * @param filename
	 * @return
	 * @throws IOException
	 */
	public static Workbook getWeebWork(String filename) throws IOException {
		Workbook workbook = null;
		if (null != filename) {
			String fileType = filename.substring(filename.lastIndexOf("."),
					filename.length());
			FileInputStream fileStream = new FileInputStream(new File(filename));
			if (".xls".equals(fileType.trim().toLowerCase())) {
				workbook = new HSSFWorkbook(fileStream);// 创建 Excel 2003 工作簿对象
			} else if (".xlsx".equals(fileType.trim().toLowerCase())) {
				workbook = new XSSFWorkbook(fileStream);// 创建 Excel 2007 工作簿对象
			}
		}
		return workbook;
	}

	/**
	 * 
	 * @Title: writeExcel
	 * @Description: TODO(导出Excel表)
	 * @param pathname
	 *            :导出Excel表的文件路径
	 * @param map
	 *            ：封装需要导出的数据(HEADERINFO封装表头信息，DATAINFON：封装要导出的数据信息,此处需要使用TreeMap
	 *            ) 例如： map.put(ExcelUtil.HEADERINFO,List<String> headList);
	 *            map.put(ExcelUtil.DATAINFON,List<TreeMap<String,Object>>
	 *            dataList);
	 * @param wb
	 * @throws IOException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public static void writeExcel(String pathname, Map<String, Object> map,
			Workbook wb) throws IOException {
		if (null != map && null != pathname) {
			List<Object> headList = (List<Object>) map.get(ExcelUtils.HEADERINFO);
			List<TreeMap<String, Object>> dataList = (List<TreeMap<String, Object>>) map.get(ExcelUtils.DATAINFON);
			CellStyle style = getCellStyle(wb);
			Sheet sheet = wb.createSheet();// 在文档对象中创建一个表单..默认是表单名字是Sheet0、Sheet1....
			
			// Sheet sheet = wb.createSheet("hell poi");//在创建爱你表单的时候指定表单的名字
			
			/**
			 * 设置Excel表的第一行即表头
			 */
			Row row = sheet.createRow(0);
			for (int i = 0; i < headList.size(); i++) {
				Cell headCell = row.createCell(i);
				headCell.setCellType(Cell.CELL_TYPE_STRING);// 设置这个单元格的数据的类型,是文本类型还是数字类型
				headCell.setCellStyle(style);// 设置表头样式
				headCell.setCellValue(String.valueOf(headList.get(i)));// 给这个单元格设置值
				sheet.setColumnWidth(i, 100*70); //设置单元格宽度
				row.setHeightInPoints(30);
			}

			for (int i = 0; i < dataList.size(); i++) {
				Row rowdata = sheet.createRow(i + 1);// 创建数据行
				TreeMap<String, Object> mapdata = dataList.get(i);
				Iterator it = mapdata.keySet().iterator();
				int j = 0;
				while (it.hasNext()) {
					String strdata = String.valueOf(mapdata.get(it.next()));
					Cell celldata = rowdata.createCell(j);// 在一行中创建某列..
					celldata.setCellType(Cell.CELL_TYPE_STRING);
					celldata.setCellStyle(style);//设置行字体样式
					celldata.setCellValue(strdata);
					j++;
				}
				sheet.setColumnWidth(i, 100*70); //设置单元格宽度
				row.setHeightInPoints(30);
			}

			// 文件流
			File file = new File(pathname);
			OutputStream os = new FileOutputStream(file);
			os.flush();
			wb.write(os);
			os.close();
		}
	}

	/**
	 * 
	 * @Title: getCellStyle
	 * @Description: TODO（设置表头样式）
	 * @param wb
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public static CellStyle getCellStyle(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		Font font = wb.createFont();
		font.setFontName("宋体");
		font.setFontHeightInPoints((short) 12);// 设置字体大小
		//font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);// 加粗
		style.setFillForegroundColor(HSSFColor.LIME.index);// 设置背景色
		//style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setAlignment(HSSFCellStyle.SOLID_FOREGROUND);// 让单元格居中
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 居中  
		// style.setWrapText(true);//设置自动换行
		style.setFont(font);
		return style;
	}
	@SuppressWarnings({ "unused", "resource" })
	public static void readFromExcelDemo(String fileAbsolutePath) throws IOException {
		/**
		 * 读取Excel表中的所有数据
		 */
		Workbook workbook = null;//getWeebWork(fileAbsolutePath);
		//兼容2007    2003版本
		   try { 
			   workbook = new XSSFWorkbook(fileAbsolutePath); 
	        } catch (Exception ex) { 
	        	workbook = new HSSFWorkbook(new FileInputStream(fileAbsolutePath)); 
	        } 
		System.out.println("总表页数为：" + workbook.getNumberOfSheets());// 获取表页数
		Sheet sheet = workbook.getSheetAt(0);
		// Sheet sheet = workbook.getSheetAt(1);
		int rownum = sheet.getLastRowNum();// 获取总行数
		for (int i = 0; i <= rownum; i++) {
			Row row = sheet.getRow(i);
			Cell orderno = row.getCell(2);// 获取指定单元格中的数据
			 //System.out.println(orderno.getCellType());//这个打印的是cell的type
			short cellnum = row.getLastCellNum(); // 获取单元格的总列数
			for (int j = row.getFirstCellNum(); j < row.getLastCellNum(); j++) {
				Cell celldata = row.getCell(j);
				System.out.print(celldata + "\t");
			}
			System.out.println();
		}
	}

	/**
	 * 功能: 导出为Excel工作簿
	 * 参数: sheetName[工作簿中的一张工作表的名称]
	 * 参数: titleName[表格的标题名称]
	 * 参数: headers[表格每一列的列名]
	 * 参数: dataSet[要导出的数据源]
	 * 参数: xlsPath[导出的excel文件地址]
	 * 参数: timeFormat[时间类型数据的格式]
	 */
	public static void exportExcel(String sheetName, String titleName, String[] headers, Collection<?> dataSet, String xlsPath, String timeFormat) {
		// 声明一个工作薄
		HSSFWorkbook workbook = new HSSFWorkbook();

		// 生成一个工作表
		HSSFSheet sheet = workbook.createSheet(sheetName);
		// 设置工作表默认列宽度为20个字节
		sheet.setDefaultColumnWidth((short) 20);
		// 在工作表中合并首行并居中
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, headers.length - 1));

		// 创建[标题]样式
		HSSFCellStyle titleStyle = workbook.createCellStyle();
		// 设置[标题]样式
		titleStyle.setFillForegroundColor(IndexedColors.LIGHT_TURQUOISE.getIndex());
		titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		titleStyle.setBorderBottom(BorderStyle.THIN);
		titleStyle.setBorderLeft(BorderStyle.THIN);
		titleStyle.setBorderRight(BorderStyle.THIN);
		titleStyle.setBorderTop(BorderStyle.THIN);
		titleStyle.setAlignment(HorizontalAlignment.CENTER);
		// 创建[标题]字体
		HSSFFont titleFont = workbook.createFont();
		// 设置[标题]字体
		titleFont.setColor((short) 0);
		titleFont.setFontHeightInPoints((short) 24);
		// 把[标题字体]应用到[标题样式]
		titleStyle.setFont(titleFont);

		// 创建[列首]样式
		HSSFCellStyle headersStyle = workbook.createCellStyle();
		// 设置[列首]样式
		// headersStyle.setFillForegroundColor(HSSFColor.LIGHT_ORANGE.index);
		headersStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headersStyle.setBorderBottom(BorderStyle.THIN);
		headersStyle.setBorderLeft(BorderStyle.THIN);
		headersStyle.setBorderRight(BorderStyle.THIN);
		headersStyle.setBorderTop(BorderStyle.THIN);
		headersStyle.setAlignment(HorizontalAlignment.CENTER);
		// 创建[列首]字体
		HSSFFont headersFont = workbook.createFont();
		// 设置[列首]字体
		headersFont.setColor((short) 0);
		headersFont.setFontHeightInPoints((short) 12);
		// 把[列首字体]应用到[列首样式]
		headersStyle.setFont(headersFont);

		// 创建[表中数据]样式
		HSSFCellStyle dataSetStyle = workbook.createCellStyle();
		// 设置[表中数据]样式
		// dataSetStyle.setFillForegroundColor(HSSFColor.GOLD.index);
		dataSetStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		dataSetStyle.setBorderBottom(BorderStyle.THIN);
		dataSetStyle.setBorderLeft(BorderStyle.THIN);
		dataSetStyle.setBorderRight(BorderStyle.THIN);
		dataSetStyle.setBorderTop(BorderStyle.THIN);
		dataSetStyle.setAlignment(HorizontalAlignment.CENTER);
		dataSetStyle.setVerticalAlignment(VerticalAlignment.CENTER);
		// 创建[表中数据]字体
		HSSFFont dataSetFont = workbook.createFont();
		// 设置[表中数据]字体
		dataSetFont.setColor((short) 0);
		// 把[表中数据字体]应用到[表中数据样式]
		dataSetStyle.setFont(dataSetFont);

		// 创建标题行-增加样式-赋值
		HSSFRow titleRow = sheet.createRow(0);
		HSSFCell titleCell = titleRow.createCell(0);
		titleCell.setCellStyle(titleStyle);
		titleCell.setCellValue(titleName);

		// 创建列首-增加样式-赋值
		HSSFRow row = sheet.createRow(1);
		for (short i = 0; i < headers.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellStyle(headersStyle);
			HSSFRichTextString text = new HSSFRichTextString(headers[i]);
			cell.setCellValue(text);
			sheet.setColumnWidth(i, 100*70); //设置单元格宽度
			row.setHeightInPoints(20);
		}

		// 创建表中数据行-增加样式-赋值
		Iterator<?> it = dataSet.iterator();
		int index = 1;
		while (it.hasNext()) {
			index++;
			row = sheet.createRow(index);
			Object t = it.next();
			// 利用反射，根据javabean属性的先后顺序，动态调用getXxx()方法得到属性值
			Field[] fields = t.getClass().getDeclaredFields();
			for (short i = 0; i < fields.length; i++) {
				HSSFCell cell = row.createCell(i);
				sheet.setColumnWidth(i, 100*70); //设置单元格宽度
				row.setHeightInPoints(20);//设置行高
				cell.setCellStyle(dataSetStyle);
				Field field = fields[i];
				String fieldName = field.getName();
				String getMethodName = "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
				try {
					@SuppressWarnings("rawtypes")
					Class tCls = t.getClass();
					@SuppressWarnings("unchecked")
					Method getMethod = tCls.getMethod(getMethodName, new Class[]{});
					Object value = getMethod.invoke(t, new Object[]{});

					// 如果是时间类型,按照格式转换
					String textValue = null;
					if (value instanceof Date) {
						Date date = (Date) value;
						SimpleDateFormat sdf = new SimpleDateFormat(timeFormat);
						textValue = sdf.format(date);
					} else {
						// 其它数据类型都当作字符串简单处理
						textValue = (String) value;
					}
					// 利用正则表达式判断textValue是否全部由数字组成
					if (textValue != null) {
						cell.setCellValue(textValue);
					}
					OutputStream out = null;
					try {
						out = new FileOutputStream(xlsPath);
						workbook.write(out);
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						try {
							out.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}

				} catch (SecurityException e) {
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} finally {
					// 清理资源
					try {
						workbook.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
	