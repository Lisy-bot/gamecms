package com.cms.interceptor;

import com.alibaba.fastjson.JSON;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.RsaUtil;
import com.cms.model.auth.SysUser;
import com.cms.model.auth.Token;
import com.cms.service.auth.AuthService;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;

/**
 * 后台拦截器
 * @author Admins
 * @date 2017年4月23日
 */
public class AdminAuthInterceptor implements Interceptor {

	@Override
	public void intercept(Invocation inv) {
		Controller contro = inv.getController();

		// 用户过期验证，权限验证
		SysUser user = getUser(contro);
		int authMess = urlAuth(user, inv);
		if (authMess == 0) {
			inv.invoke();
			AuthService.sysLog(user, inv);
		} else if (authMess == 1) {
			contro.redirect("/home/login");
		} else {
			contro.renderHtml("<h1>您没有操作权限！</h1>");
		}
	}

	/**
	 * 从session或cookie获取用户
	 * @param contro
	 * @return
	 */
	private SysUser getUser(Controller contro) {
		SysUser user = (SysUser) contro.getSession().getAttribute(Constant.CONST_SESSION_SYS_USER);
		if (user == null) {
			// 从cookie中获取token
			String token = contro.getCookie(PropKit.use("config.properties").get("ssoCookieName"));
			if (token != null) {
				try {
					token = new String(RsaUtil.decryptByPublicKey(RsaUtil.string_to_buf(token), PropKit.use("config.properties").get("ssoPublicKey")),
					        "utf-8");
					Token tk = JSON.parseObject(token, Token.class);
					// 超时判断，超过半小时失效
					if (BaseUtil.minuteTimeOut(tk.getTime(), 30)) {
						user = AuthService.getUserByAccount(tk.getId());
						// 跟新到session
						contro.getSession().setAttribute(Constant.CONST_SESSION_SYS_USER, user);
						return user;
					} else {
						// 清掉cookie
						contro.removeCookie(PropKit.use("config.properties").get("ssoCookieName"), contro.getRequest().getContextPath());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			return null;
		}
		return user;
	}

	/**
	 * 权限验证
	 * @param user
	 * @param inv
	 * @return
	 */
	private int urlAuth(SysUser user, Invocation inv) {
		if (user == null) {
			return 1;
		} else {
			String url = inv.getControllerKey() + "/" + inv.getMethodName();
			// 后台首页，树形菜单
			if ((url).equals("/home/index") || (url).equals("/home/tree")) {
				return 0;
			}

			boolean auth = AuthService.haveAuth(user, url);
			if (auth) {
				return 0;
			}
			return 2;
		}
	}

}
