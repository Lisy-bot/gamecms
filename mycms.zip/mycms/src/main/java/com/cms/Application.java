package com.cms;

import java.text.ParseException;

import com.jfinal.core.JFinal;

/**
 * 本地开发启动项目
 * @author tanzhuo
 * @date 2017年2月8日
 */
public class Application {
	// 项目启动
	public static void main(String[] args) throws ParseException {
		String userDir = System.getProperty("user.dir");
		// 适应测试阶段的jetty，日志写入目录，tomcat写入tomcat/logs下
		String catalinaBase = System.getProperty("catalina.base", userDir);
		System.setProperty("catalina.base", catalinaBase);

		JFinal.start("src/main/webapp", 80, "/mycms", 5);
	}
}
