package com.cms.routes;
import com.cms.controller.ActivityPrizeController;
import com.cms.controller.ActivityTypeController;
import com.cms.controller.ActivityUserController;
import com.cms.controller.GameController;
import com.cms.controller.GameTypeController;
import com.cms.controller.InterceptController;
import com.cms.controller.InterceptTypeController;
import com.cms.controller.MemberAreaController;
import com.cms.controller.MemberTypeController;
import com.cms.controller.PlayerKillingController;
import com.cms.controller.PlayerKillingUserController;
import com.cms.controller.PointsHomeController;
import com.cms.controller.PointsSysImgController;
import com.cms.controller.PointsSysTypeController;
import com.cms.controller.PrizeController;
import com.cms.controller.PrizeTypeController;
import com.cms.controller.ProductOrderController;
import com.cms.controller.SignPointsController;
import com.cms.controller.UserController;
import com.cms.controller.api.ApiDataController;
import com.cms.controller.auth.ApiAuthController;
import com.cms.controller.auth.HomeController;
import com.cms.controller.auth.ResourceController;
import com.cms.controller.auth.SysLogController;
import com.cms.controller.auth.SysRoleController;
import com.cms.controller.auth.SysSettingController;
import com.cms.controller.auth.SysUserController;
import com.cms.interceptor.AdminAuthInterceptor;
import com.jfinal.config.Routes;
/**
 * 后台路由
 * @author Admins
 * @date 2017年4月23日
 */
public class AdminRoutes extends Routes {
	@Override
	public void config() {
		setBaseViewPath("/WEB-INF/admin/");
		add("/apiData", ApiDataController.class, ""); // 后台数据API，开放型api
		addInterceptor(new AdminAuthInterceptor()); // 后台拦截器
		add("/home", HomeController.class, ""); // 后台首页
		add("/", HomeController.class, ""); // 后台首页
		add("/resource", ResourceController.class, "seting/sysResource"); // 后台资源
		add("/sysUser", SysUserController.class, "seting/sysUser"); // 后台用户管理
		add("/sysRole", SysRoleController.class, "seting/sysRole"); // 后台角色管理
		add("/sysLog", SysLogController.class, "seting/sysLog"); // 后台日志
		add("/sysSetting", SysSettingController.class, "seting/sysSetting"); // 系统设置
		add("/api", ApiAuthController.class, ""); // 系统API
		
		
		add("/interceptType", InterceptTypeController.class, "content/interceptType"); // 拦截类型管理
		add("/intercept", InterceptController.class, "content/intercept"); // 拦截管理
		add("/game", GameController.class, "content/game"); // 游戏内容
		add("/gameType", GameTypeController.class, "content/gameType");// 游戏类型管理
		add("/pointsHome", PointsHomeController.class, "content/home"); // 积分首页
		add("/memberType", MemberTypeController.class, "content/memberType"); // 会员类型
		add("/memberArea", MemberAreaController.class, "content/memberArea"); // 会员专区
		add("/playerKilling", PlayerKillingController.class, "content/playerKilling"); // PK类型
		add("/playerKillingUser", PlayerKillingUserController.class, "content/playerKillingUser"); // 用户PK投票管理类型
		add("/signPoints", SignPointsController.class, "content/signPoints"); // 签到积分管理
		add("/prizeType", PrizeTypeController.class, "content/prizeType"); // 奖品类型管理
		add("/prize", PrizeController.class, "content/prize"); // 奖品管理
		add("/pointsSysType", PointsSysTypeController.class, "content/pointsSysType"); // 系统类型管理
		add("/pointsSysImg", PointsSysImgController.class, "content/pointsSysImg"); // 系统图片管理
		add("/user", UserController.class, "content/user"); // 用户管理
		add("/activityType", ActivityTypeController.class, "content/activityType"); // 活动类型管理
		add("/activityPrize", ActivityPrizeController.class, "content/activityPrize");// 活动类型
		add("/activityUser", ActivityUserController.class, "content/activityUser");// 活动用户
		add("/product", ProductOrderController.class, "content/product"); // 产品管理
	}

}
