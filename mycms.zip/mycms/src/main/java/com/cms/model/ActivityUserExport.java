package com.cms.model;

import java.util.Date;

/**
 * 活动用户批量导出中间类
 * @author lisiyun
 * date 2017-10-12
 */
public class ActivityUserExport {
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getActivityUser() {
		return ActivityUser;
	}
	public void setActivityUser(String activityUser) {
		ActivityUser = activityUser;
	}
	public String getActivityUserPhone() {
		return ActivityUserPhone;
	}
	public void setActivityUserPhone(String activityUserPhone) {
		ActivityUserPhone = activityUserPhone;
	}
	public String getActivityType() {
		return ActivityType;
	}
	public void setActivityType(String activityType) {
		ActivityType = activityType;
	}
	public String getPrizeType() {
		return prizeType;
	}
	public void setPrizeType(String prizeType) {
		this.prizeType = prizeType;
	}
	public String getLotteryCount() {
		return lotteryCount;
	}
	public void setLotteryCount(String lotteryCount) {
		this.lotteryCount = lotteryCount;
	}
	public String getLoginRanking() {
		return loginRanking;
	}
	public void setLoginRanking(String loginRanking) {
		this.loginRanking = loginRanking;
	}
	public Date getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}
	public Date getWinningTime() {
		return WinningTime;
	}
	public void setWinningTime(Date winningTime) {
		WinningTime = winningTime;
	}
	//自增id
	private String id;
	//用户
	private String ActivityUser;
	//用户电话
	private String ActivityUserPhone;
	//活动类型
	private String ActivityType;
	//奖品类型
	private String prizeType;
	//抽奖次数
	private String lotteryCount;
	//登录排名
	private String loginRanking;
	//登录时间
	private Date loginTime;
	//中间时间
	private Date WinningTime;
}
