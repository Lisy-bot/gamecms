package com.cms.model;

import java.util.List;

import com.cms.model.base.BaseGameType;
import com.jfinal.plugin.activerecord.Page;

@SuppressWarnings("serial")
public class GameType extends BaseGameType<GameType> {
	public static final GameType dao = new GameType().dao();
	/**
	 * 分页查询游戏类型
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	public Page<GameType> queryGameTypeByPage(int pageNumber, int pageSize){
		return dao.paginate(pageNumber, pageSize,"select game_type_id, game_type_name ","from game_type");
	}
	
	/**
	 * 新增游戏类型
	 */
	public boolean addGameType(GameType gameType){
		return gameType.save();
	}
	
	/**
	 * 根据id获取游戏类型
	 */
	public GameType queryGameTypeById(int gameTypeId){
		return dao.findById(gameTypeId);
	}
	
	/**
	 * 修改游戏类型
	 */
	public boolean updateGameType(GameType gameType){
		return gameType.update();
	}
	
	/**
	 * 根据id删除游戏类型
	 */
	public boolean delGameType(int gameTypeId){
		return dao.deleteById(gameTypeId);
	}
	
	/**
	 * 查询所有游戏类型
	 */
	public List<GameType> queryAllGameType(){
		return dao.find("select game_type_id, game_type_name from game_type");
	}
}
