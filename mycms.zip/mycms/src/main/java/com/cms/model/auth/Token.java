package com.cms.model.auth;

/**
 * sso实体类
 * @author tanzhuo
 * @date 2017年11月7日
 */
public class Token {
	/**
	 * 主键
	 */
	private String id;
	/**
	 * IP地址
	 */
	private String ip;
	/**
	 * 创建时间
	 */
	private long time = System.currentTimeMillis();
	/**
	 * 登录通知地址
	 */
	private String LoginNoticeUrl;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getLoginNoticeUrl() {
		return LoginNoticeUrl;
	}
	public void setLoginNoticeUrl(String loginNoticeUrl) {
		LoginNoticeUrl = loginNoticeUrl;
	}

}
