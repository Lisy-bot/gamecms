package com.cms.service;

import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.model.InterceptType;
import com.jfinal.plugin.activerecord.Page;
/**
 * 拦截类型服务层
 * @author gengyl
 * @date 2017年8月7日
 */
public class InterceptTypeService {
	/**
	 * 根据ID查询拦截类型
	 * @param id
	 * @return
	 */
	public InterceptType findById(int id) {
		return InterceptType.dao.findById(id);
	}

	/**
	 * 查询所有拦截类型
	 * @param page
	 * @param pageSize
	 * @param compName
	 * @param compUserName
	 * @return
	 */
	public Page<InterceptType> queryAll(int page, int pageSize, String intyName) {
		return InterceptType.dao.queryAll(page, pageSize, intyName);
	}
	
	/**
	 * 查询所有的拦截类型集合
	 * @return
	 */
	public List<InterceptType> getInterceptTypeList() {
		return InterceptType.dao.getInterceptTypeList();
	}
	

	/**
	 * 添加拦截类型
	 * @param interceptType
	 * @return
	 */
	public String add(InterceptType interceptType) {
		if(BaseUtil.isNull(interceptType.getInterceptTypeName())){
			return BaseUtil.returnMess(0, "拦截类型中文名不能为空", "");
		}else if(BaseUtil.isNull(interceptType.getInterceptTypeNameEn())){
			return BaseUtil.returnMess(0, "拦截类型英文名不能为空", "");
		}
		boolean status = InterceptType.dao.addInterceptType(interceptType);
		if (status) {
			return BaseUtil.returnMess(1, "拦截类型添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截类型添加失败，请重试！", "");
		}
	}

	/**
	 * 编辑拦截类型
	 * @param interceptType
	 * @return
	 */
	public String edit(InterceptType interceptType) {
		if(BaseUtil.isNull(interceptType.getInterceptTypeName())){
			return BaseUtil.returnMess(0, "拦截类型中文名不能为空", "");
		}else if(BaseUtil.isNull(interceptType.getInterceptTypeNameEn())){
			return BaseUtil.returnMess(0, "拦截类型英文名不能为空", "");
		}
		boolean status = InterceptType.dao.editInterceptType(interceptType);
		if (status) {
			return BaseUtil.returnMess(1, "拦截类型修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截类型修改失败，请重试！", "");
		}
	}
	
	/**
	 * 删除公司
	 * @param id
	 * @return
	 */
	public String del(int id) {
		boolean status = InterceptType.dao.deleteById(id);
		if (status) {
			return BaseUtil.returnMess(1, "拦截类型删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截类型删除失败，请重试！", "");
		}
	}
}
