package com.cms.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.PointsSysImgController;
import com.cms.model.PointsSysImg;
import com.cms.model.PointsSysType;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

/**
 * 奖品Service层
 * 
 * @author Lisy
 */
public class PointsSysImgService {
	// 根据条件，分页查询
	public Page<PointsSysImg> queryAll(int pageNumber, int pageSize, String point_sys_name, String points_sys_type_id) {
		return PointsSysImg.dao.queryAll(pageNumber, pageSize, point_sys_name, points_sys_type_id);
	}

	// 根据ID查找
	public PointsSysImg findById(int id) {
		return PointsSysImg.dao.findById(id);
	}

	// 图片添加
	public String add(PointsSysImgController con) {
		UploadFile upfile = con.getFile();// JFinal规定getFile()必须最先执行
		boolean status = false;
		String addType = con.getPara("addType"); // 判断添加类型

		if (!BaseUtil.isNull(addType)) {
			PointsSysImg pointsSysImg = con.getModel(PointsSysImg.class);
			if (Integer.parseInt(addType) == 1) { // 内容添加
				if (BaseUtil.isNull(con.getPara("title"))) {
					return BaseUtil.returnMess(0, "添加失败，请输入系统名称!", "");
				}
				pointsSysImg.setPointsSysName(con.getPara("title"));
				status = PointsSysImg.dao.add(pointsSysImg);
			} else {
				PointsSysImg sysImg = PointsSysImg.dao.getPointsSysTypeId(pointsSysImg.getPointsSysTypeId());
				if (BaseUtil.isNull(sysImg)) {
					return BaseUtil.returnMess(0, "请先添加系统内容！", "");
				}
				String title = con.getPara("title"); // 获取标题名称，用于json中标识作用
				if (BaseUtil.isNull(title)) {
					return BaseUtil.returnMess(0, "请输入名称！", "");
				}
				pointsSysImg.setPointsSysId(sysImg.getPointsSysId());
				pointsSysImg.setPointsSysName(sysImg.getPointsSysName());
				// 获取全部json数据
				String json = sysImg.getPointsSysJson();
				JSONArray jsonArray = new JSONArray();
				if (Integer.parseInt(addType) == 2) { // json 中，页面标识类型添加
					JSONObject object = new JSONObject();
					object.put("lable", title);
					if (!BaseUtil.isNull(json)) {
						jsonArray = JSONObject.parseArray(json);
						jsonArray.add(object);
						pointsSysImg.setPointsSysJson(jsonArray.toJSONString());
					} else {
						jsonArray.add(object);
						pointsSysImg.setPointsSysJson(jsonArray.toString());
					}
				} else if (Integer.parseInt(addType) == 3) { // 图片添加
					String pageType = con.getPara("pageType");
					if (!BaseUtil.isNull(json) && !BaseUtil.isNull(pageType)) {
						if (!BaseUtil.isNull(upfile)) {
							PointsSysType pointsSysType = PointsSysType.dao.findById(pointsSysImg.getPointsSysTypeId());
							String file = FileUploadUtil.moveFiles(
									upfile.getUploadPath() + "/" + upfile.getFileName(), pointsSysType.getPointsSysImgPath());
							// 将string转成json数组
							jsonArray = JSONObject.parseArray(json);
							// 得到页面类型json操作下标
							int jsonIndex = Integer.parseInt(pageType) - 1;
							JSONObject object = JSONObject.parseObject(jsonArray.get(jsonIndex).toString());
							Object objectChild = object.get("child"); // 获取子集数据
							JSONObject jsonObject = new JSONObject();
							JSONArray array = new JSONArray();
							// 首次添加child
							if (BaseUtil.isNull(objectChild)) {
								jsonObject.put("title", title);
								jsonObject.put("imgUrl", file);
								array.add(jsonObject);
								object.put("child", array);
								// 根据下标删除原有的json数据
								jsonArray.remove(jsonIndex);
								jsonArray.add(jsonIndex, object);
							} else { // 已经有子集数据
								JSONArray childArray = JSONObject.parseArray(objectChild.toString());
								int childIndex = -1; // 标识是否有重复数据
								for (int i = 0; i < childArray.size(); i++) {
									JSONObject newJsonObjectI = (JSONObject) childArray.get(i);
									String imgName = newJsonObjectI.get("title").toString();
									if (imgName.equals(title)) { // 有重复数据
										childIndex = i;
										FileUploadUtil.delFile(
												pointsSysType.getPointsSysImgPath() + newJsonObjectI.get("imgUrl").toString()); // 删除文件
										break;
									}
								}
								// 添加child新数据
								JSONObject jsonChild = new JSONObject();
								jsonChild.put("title", title);
								jsonChild.put("imgUrl", file);
								if (childIndex != -1) {// 删除原有的数据，更新最新数据
									childArray.remove(childIndex);
									childArray.add(childIndex, jsonChild);
								} else {
									childArray.add(jsonChild);
								}
								object.put("child", childArray);
								// 根据下标删除原有的json数据
								jsonArray.remove(jsonIndex);
								jsonArray.add(jsonIndex, object);
							}
							pointsSysImg.setPointsSysJson(jsonArray.toJSONString());
						} else {
							return BaseUtil.returnMess(0, "请选择图片!", "");
						}
					} else {
						return BaseUtil.returnMess(0, "添加失败，请选择页面类型重试！", "");
					}	
				}
				status = PointsSysImg.dao.edit(pointsSysImg);
			}
			if (status) {
				return BaseUtil.returnMess(1, "添加成功！", "");
			} else {
				return BaseUtil.returnMess(0, "添加失败，请重试！", "");
			}
		} else {
			return BaseUtil.returnMess(0, "请选择添加类型!", "");
		}
	}

	// 编辑
	public String edit(PointsSysImgController con) {
		UploadFile file = con.getFile();// JFinal规定getFile()必须最先执行
		PointsSysImg pointsSysImg = con.getModel(PointsSysImg.class);
		// 编辑的页面类型下标
		int pageTypeIndex = con.getParaToInt("pageTypeIndex") - 1;
		// 编辑的图片下标
		int editChildIndex = con.getParaToInt("editChildIndex") - 1;
		if (!BaseUtil.isNull(file)) {
			PointsSysImg pImg = PointsSysImg.dao.findById(pointsSysImg.getPointsSysId());
			String json = pImg.getPointsSysJson();
			JSONArray array = JSONArray.parseArray(json);
			// 获取json 页面数据
			Object object = array.get(pageTypeIndex);
			JSONObject object1 = (JSONObject) JSONObject.parse(object.toString());
			JSONArray jsonArray = JSONArray.parseArray(object1.get("child").toString());
			// 获取json 的图片数据
			JSONObject jsonObject = (JSONObject) jsonArray.get(editChildIndex);
			// 根据系统类型ID获取上传文件路径
			PointsSysType pointsSysType = PointsSysType.dao.findById(pImg.getPointsSysTypeId());
			String path = pointsSysType.getPointsSysImgPath();
			String upfile = FileUploadUtil.moveFiles(file.getUploadPath() + "/" + file.getFileName(), path);
			FileUploadUtil.delFile(path+jsonObject.get("imgUrl"));
			// 更新图片
			jsonObject.put("imgUrl", upfile);
			// 删除child
			jsonArray.remove(editChildIndex);
			// 添加新的child
			jsonArray.add(editChildIndex, jsonObject);
			object1.put("child", jsonArray);
			// 删除页面类型数据
			array.remove(pageTypeIndex);
			// 添加新的页面类型数据
			array.add(pageTypeIndex, object1);
			pointsSysImg.setPointsSysJson(array.toJSONString());
			if (PointsSysImg.dao.edit(pointsSysImg)) {
				return BaseUtil.returnMess(1, "添加成功！", "");
			} else {
				return BaseUtil.returnMess(0, "添加失败，请重试！", "");
			}
		}else {
			return BaseUtil.returnMess(0, "请选择图片!", "");
		}	
	}
	/**
	 * 根据id查询
	 * @param point_sys_id
	 * @return
	 */
	public PointsSysImg getPointsSysPageType(int point_sys_id) {
		return PointsSysImg.dao.getPointsSysPageType(point_sys_id);
	}
	/**
	 * 根据类型ID查询
	 * 
	 * @param point_sys_type_id
	 * @return
	 */
	public PointsSysImg getPointsSysTypeId(int point_sys_type_id) {
		return PointsSysImg.dao.getPointsSysTypeId(point_sys_type_id);
	}

	public String del(PointsSysImgController pointsSysImgController) {
		int id = pointsSysImgController.getParaToInt("id");
		PointsSysImg pointsSysImg = PointsSysImg.dao.findById(id);
		PointsSysType pointsSysType = PointsSysType.dao.findById(pointsSysImg.getPointsSysTypeId());
		Boolean status = PointsSysImg.dao.deleteById(id);
		if (status) {
			JSONArray arr  = JSONArray.parseArray(pointsSysImg.getPointsSysJson());
			for(int i = 0 ;  i < arr.size(); i++) {
				JSONObject object = (JSONObject) JSONObject.parse(arr.get(i).toString());
				JSONArray jsonArray = JSONArray.parseArray(object.get("child").toString());
				for(int j = 0; j < jsonArray.size(); j++) {
					JSONObject jsonObject = (JSONObject) JSONObject.parse(jsonArray.get(j).toString());
					FileUploadUtil.delFile(pointsSysType.getPointsSysImgPath()+jsonObject.get("imgUrl"));
				}
			}
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
}
