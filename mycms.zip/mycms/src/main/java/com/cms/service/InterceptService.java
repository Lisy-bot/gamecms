package com.cms.service;

import com.cms.common.util.BaseUtil;
import com.cms.model.Intercept;
import com.jfinal.plugin.activerecord.Page;
/**
 * 拦截服务层
 * @author gengyl
 * @date 2017年8月7日
 */
public class InterceptService {
	/**
	 * 根据ID查询拦截
	 * @param id
	 * @return
	 */
	public Intercept findById(int id) {
		return Intercept.dao.findById(id);
	}

	/**
	 * 查询所有拦截
	 * @param page
	 * @param pageSize
	 * @param compName
	 * @param compUserName
	 * @return
	 */
	public Page<Intercept> queryAll(int page, int pageSize, String intyName, String inteParam) {
		return Intercept.dao.queryAll(page, pageSize, intyName, inteParam);
	}

	/**
	 * 添加拦截
	 * @param Intercept
	 * @return
	 */
	public String add(Intercept intercept) {
		if(BaseUtil.isNull(intercept.getInterceptTypeId())){
			return BaseUtil.returnMess(0, "拦截类型不能为空", "");
		}else if(BaseUtil.isNull(intercept.getInterceptUrl())){
			return BaseUtil.returnMess(0, "拦截地址不能为空", "");
		}
		boolean status = Intercept.dao.addIntercept(intercept);
		if (status) {
			return BaseUtil.returnMess(1, "拦截添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截添加失败，请重试！", "");
		}
	}

	/**
	 * 编辑拦截
	 * @param Intercept
	 * @return
	 */
	public String edit(Intercept intercept) {
		if(BaseUtil.isNull(intercept.getInterceptId())){
			return BaseUtil.returnMess(0, "拦截类型不能为空", "");
		}else if(BaseUtil.isNull(intercept.getInterceptUrl())){
			return BaseUtil.returnMess(0, "拦截地址不能为空", "");
		}
		boolean status = Intercept.dao.editIntercept(intercept);
		if (status) {
			return BaseUtil.returnMess(1, "拦截修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截修改失败，请重试！", "");
		}
	}
	
	/**
	 * 删除拦截
	 * @param id
	 * @return
	 */
	public String del(int id) {
		boolean status = Intercept.dao.deleteById(id);
		if (status) {
			return BaseUtil.returnMess(1, "拦截删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "拦截删除失败，请重试！", "");
		}
	}
}
