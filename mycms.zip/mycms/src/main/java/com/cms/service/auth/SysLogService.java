package com.cms.service.auth;

import com.cms.model.auth.SysLog;
import com.jfinal.plugin.activerecord.Page;

/**
 * 服务类：系统日志
 * @author tanzhuo
 * @date 2017年7月1日
 */
public class SysLogService {

	/**
	 * 查询所有日志
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<SysLog> queryAll(int page, int pageSize, String name, String startTime, String endTime) {
		return SysLog.dao.queryAll(page, pageSize, name, startTime, endTime);
	}

	/**
	 * 根据id查询id
	 * @param id
	 * @return
	 */
	public SysLog findById(String id) {
		return SysLog.dao.findById(id);
	}

}
