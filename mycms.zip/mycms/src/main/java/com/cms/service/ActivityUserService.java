package com.cms.service;

import com.cms.common.util.BaseUtil;
import com.cms.controller.ActivityUserController;
import com.cms.model.ActivityUser;
import com.jfinal.plugin.activerecord.Page;

public class ActivityUserService {
	/**
	 * 查询活动用户
	 * @param pageNumber
	 * @param pageSize
	 * @param actu_name
	 * @param acty_id
	 * @param flag
	 * @param getprize_time
	 * @param getprize_endTime
	 * @return
	 */
	public Page<ActivityUser> queryAll(int pageNumber, int pageSize ,String actu_name, String acty_id, String flag, String getprize_time,String getprize_endTime){
		return ActivityUser.dao.queryAll(pageNumber, pageSize, actu_name, acty_id, flag, getprize_time, getprize_endTime);
	}
	
	/**
	 * 添加活动用户
	 * @param activityUser
	 * @return
	 */
	public String addActivityUser(ActivityUserController controller){
		ActivityUser user = controller.getModel(ActivityUser.class);
		//非空判断
		if(BaseUtil.isNull(user.getActuName())){
			return BaseUtil.returnMess(0, "活动用户不能为空", "");
		}else if(BaseUtil.isNull(user.getActyId())){
			return BaseUtil.returnMess(0, "活动所属类型不能为空", "");
		}
		if(BaseUtil.isNull(user.getActuGetprizeCount())  || user.getActuGetprizeCount() < 0){
			user.setActuGetprizeCount(0);
		}
		if(BaseUtil.isNull(user.getActuLoginRank())  || user.getActuLoginRank() < 0){
			user.setActuLoginRank(0);
		}
		boolean status = ActivityUser.dao.addActivityUser(user);
		if(status){
			return BaseUtil.returnMess(1, "添加成功", "");
		}else{
			return BaseUtil.returnMess(1, "添加失败", "");
		}
	}
	
	/**
	 * 根据Id查询一条数据
	 * @param id
	 * @return
	 */
	public ActivityUser findById(int id){
		return ActivityUser.dao.findById(id);
	}
	
	/***
	 * 编辑活动用户
	 * @param activityUser
	 * @return
	 */
	
	public String eidtActivityPrize(ActivityUser activityUser){
		boolean status = ActivityUser.dao.editActivityUset(activityUser);
		if(status){
			return BaseUtil.returnMess(1, "修改成功!", "");
		}else{
			return BaseUtil.returnMess(0, "修改失败!", "");
		}
	}
	/**
	 * 根据活动id删除活动奖品
	 * @param acty_id
	 * @return
	 */
	public String delActivityUser(int acty_id){
		boolean status = ActivityUser.dao.deleteById(acty_id);
		if(status){
			return BaseUtil.returnMess(1, "删除成功!", "");
		}else{
			return BaseUtil.returnMess(0, "删除失败!", "");
		}
	}
	
}
