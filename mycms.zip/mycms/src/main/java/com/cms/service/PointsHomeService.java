package com.cms.service;

import java.util.Date;
import java.util.List;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.PointsHomeController;
import com.cms.model.PointsHome;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

/**
 * 积分系统首页Service层
 * 
 * @author Lisy
 */
public class PointsHomeService {
	// 根据条件，分页查询
	public Page<PointsHome> queryAll(int pageNumber, int pageSize, String points_home_id, String points_home_name,
			String points_home_online) {
		return PointsHome.dao.queryAll(pageNumber, pageSize, points_home_id, points_home_name, points_home_online);
	}

	// 根据ID查找
	public PointsHome findById(int id) {
		return PointsHome.dao.findById(id);
	}

	// 添加
	public String add(PointsHomeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		PointsHome pointsHome = controller.getModel(PointsHome.class);
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					pointsHome.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(pointsHome.getPointsHomeName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(pointsHome.getPointsHomeSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		pointsHome.setPointsHomeAddTime(new Date());
		boolean status = PointsHome.dao.add(pointsHome);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(PointsHomeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		PointsHome pointsHome = controller.getModel(PointsHome.class);
		// 根据ID查询
		PointsHome pHome = PointsHome.dao.findById(pointsHome.getPointsHomeId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					// 将图片移动到指定的上传目录下
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// String obj = list.get(i).getParameterName().replace("pointsHome.", ""); //
					// 得到当前mode对象字段名称
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					pointsHome.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + pHome.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(pointsHome.getPointsHomeName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(pointsHome.getPointsHomeSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		pointsHome.setPointsHomeUpdateTime(new Date());
		boolean status = PointsHome.dao.edit(pointsHome);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试!", "");
		}
	}

	// 删除
	public String del(PointsHomeController controller) {
		int points_home_id = controller.getParaToInt("id");
		PointsHome pointsHome = PointsHome.dao.findById(points_home_id);
		boolean status = PointsHome.dao.deleteById(points_home_id);
		if (status) {
			// 删除图片资源
			FileUploadUtil.delFile(Constant.baseUploadPath + pointsHome.getPointsHomeSelectedImage());
			FileUploadUtil.delFile(Constant.baseUploadPath + pointsHome.getPointsHomeUnselectedImage());
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
}
