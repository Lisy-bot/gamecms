package com.cms.service;

import java.util.List;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.SignPointsController;
import com.cms.model.SignPoints;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

/**
 * 签到积分Service层
 * 
 * @author Lisy
 */
public class SignPointsService {
	// 根据条件，分页查询
	public Page<SignPoints> queryAll(int pageNumber, int pageSize, String sign_points_id, String sign_points_name,
			String sign_points_integral) {
		return SignPoints.dao.queryAll(pageNumber, pageSize, sign_points_id, sign_points_name, sign_points_integral);
	}

	// 根据ID查找
	public SignPoints findById(int id) {
		return SignPoints.dao.findById(id);
	}

	// 添加
	public String add(SignPointsController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		SignPoints signPoints = controller.getModel(SignPoints.class);
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					signPoints.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(signPoints.getSignPointsName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(signPoints.getSignPointsSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		boolean status = SignPoints.dao.add(signPoints);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(SignPointsController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		SignPoints signPoints = controller.getModel(SignPoints.class);
		// 根据ID查询
		SignPoints sPoints = SignPoints.dao.findById(signPoints.getSignPointsId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					// 将图片移动到指定的上传目录下
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// String obj = list.get(i).getParameterName().replace("signPoints.", ""); //
					// 得到当前mode对象字段名称
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					signPoints.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + sPoints.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(signPoints.getSignPointsName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(signPoints.getSignPointsSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		boolean status = SignPoints.dao.edit(signPoints);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试!", "");
		}
	}

	// 删除
	public String del(SignPointsController controller) {
		int points_home_id = controller.getParaToInt("id");
		SignPoints signPoints = SignPoints.dao.findById(points_home_id);
		boolean status = SignPoints.dao.deleteById(points_home_id);
		if (status) {
			// 删除图片资源
			FileUploadUtil.delFile(Constant.baseUploadPath + signPoints.getSignPointsSelectedImg());
			FileUploadUtil.delFile(Constant.baseUploadPath + signPoints.getSignPointsUnselectedImg());
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
}
