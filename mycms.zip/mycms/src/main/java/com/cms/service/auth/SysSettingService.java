package com.cms.service.auth;
import java.util.Map;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.RsaUtil;
import com.cms.model.auth.SysSetting;
import com.jfinal.plugin.activerecord.Page;
/**
 * 服务类：系统设置
 * @author tanzhuo
 * @date 2017年8月22日
 */
public class SysSettingService {

	/**
	 * 初始化系统设置
	 */
	public static void initSetting() {
		SysSetting setting = SysSetting.dao
		        .findFirst("select set_id, set_title, set_url, set_upload, set_tm_upload, set_publickey, set_privatekey from sys_setting");
		// 系统标题
		Constant.title = setting.getSetTitle();
		// 资源URL
		Constant.resouceUrl = setting.getSetUrl();
		// 上传路径
		Constant.baseUploadPath = setting.getSetUpload();
		// Tomcat上传路径
		Constant.tomcatUploadPath = setting.getSetTmUpload();
		// 公钥
		Constant.publicKey = setting.getSetPublickey();
		// 私钥
		Constant.privateKey = setting.getSetPrivatekey();
		// 广告图片目录
		Constant.advertUploadPath = Constant.baseUploadPath + "/advert";
		// 游戏图片目录
		Constant.gameUploadPath = Constant.baseUploadPath + "/game";
	}

	/**
	 * 初始化RSA密钥
	 * @return 
	 */
	public boolean initRSA(int setId) {
		try {
			Map<String, Object> keyMap = RsaUtil.genKeyPair();
			SysSetting setting = new SysSetting();
			setting.setSetId(setId);
			setting.setSetPublickey(RsaUtil.getPublicKey(keyMap));
			setting.setSetPrivatekey(RsaUtil.getPrivateKey(keyMap));
			return setting.update();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 查询系统设置
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<SysSetting> queryAll(int page, int pageSize) {
		return SysSetting.dao.queryAll(page, pageSize);
	}

	/**
	 * 编辑
	 * @param sysSetting
	 * @return
	 */
	public String editSysSetting(SysSetting sysSetting, int initRSA) {
		boolean status = sysSetting.update();
		if (status) {
			if (initRSA == 1) {
				// 初始化RSA
				status = initRSA(sysSetting.getSetId());
				// 更新系统配置
				SysSettingService.initSetting();
				if (status) {
					return BaseUtil.returnMess(1, "系统配置修改成功，RSA初始化成功！", "");
				} else {
					return BaseUtil.returnMess(1, "系统配置修改成功，RSA初始化失败！", "");
				}
			} else {
				// 更新系统配置
				SysSettingService.initSetting();
				return BaseUtil.returnMess(1, "系统配置修改成功！", "");
			}
		} else {
			return BaseUtil.returnMess(0, "系统配置修改失败，请重试！", "");
		}
	}

	/**
	 * 根据ID查找
	 * @param id
	 * @return
	 */
	public SysSetting findById(int id) {
		return SysSetting.dao.findById(id);
	}

}
