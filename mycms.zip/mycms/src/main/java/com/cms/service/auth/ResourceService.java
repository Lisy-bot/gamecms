package com.cms.service.auth;

import java.util.Date;
import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.model.auth.SysResource;

/**
 * 服务类：系统资源
 * @author tanzhuo
 * @date 2017年5月17日
 */
public class ResourceService {

	/**
	 * 查询所有资源
	 * @return 
	 */
	public List<SysResource> queryAll(String noType) {
		return SysResource.dao.queryAll(noType);
	}

	/**
	 * 增加资源
	 * @param sysResource
	 * @return
	 */
	public String add(SysResource sysResource) {
		sysResource.setResCreateTime(new Date());
		boolean status = SysResource.dao.add(sysResource);
		if (status) {
			return BaseUtil.returnMess(1, "系统资源添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统资源添加失败，请重试！", "");
		}
	}

	/**
	 * 编辑
	 * @param sysResource
	 * @return
	 */
	public String edit(SysResource sysResource) {
		boolean status = SysResource.dao.edit(sysResource);
		if (status) {
			return BaseUtil.returnMess(1, "系统资源修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统资源修改失败，请重试！", "");
		}
	}

	/**
	 * 根据ID查询
	 * @param id
	 * @return
	 */
	public SysResource findById(int id) {
		return SysResource.dao.findById(id);
	}

	/**
	 * 根据ID删除
	 * @param id
	 * @return
	 */
	public String del(int id) {
		boolean status = SysResource.dao.deleteById(id);
		if (status) {
			return BaseUtil.returnMess(1, "系统资源删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统资源删除失败，请重试！", "");
		}
	}

}
