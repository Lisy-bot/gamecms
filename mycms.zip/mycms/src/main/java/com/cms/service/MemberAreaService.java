package com.cms.service;

import java.util.Date;
import java.util.List;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.MemberAreaController;
import com.cms.model.MemberArea;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

public class MemberAreaService {
	// 根据ID查找
	public MemberArea findById(int id) {
		return MemberArea.dao.findById(id);
	}

	// 根据条件分页查询
	public Page<MemberArea> queryAll(int pageNumber, int pageSize, String member_area_id, String member_area_name,
			String member_area_online) {
		return MemberArea.dao.queryAll(pageNumber, pageSize, member_area_id, member_area_name, member_area_online);
	}

	// 添加
	public String add(MemberAreaController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		MemberArea memberArea = controller.getModel(MemberArea.class);
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					memberArea.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(memberArea.getMemberAreaName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(memberArea.getMemberAreaSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		memberArea.setMemberAreaAddTime(new Date());
		boolean status = MemberArea.dao.add(memberArea);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(MemberAreaController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		MemberArea memberArea = controller.getModel(MemberArea.class);
		// 根据ID查询
		MemberArea mArea = MemberArea.dao.findById(memberArea.getMemberAreaId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					memberArea.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + mArea.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(memberArea.getMemberAreaName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(memberArea.getMemberAreaSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		memberArea.setMemberAreaUpdateTime(new Date());
		boolean status = MemberArea.dao.edit(memberArea);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试！", "");
		}
	}

	// 删除
	public String del(MemberAreaController controller) {
		int id = controller.getParaToInt("id");
		MemberArea memberArea = MemberArea.dao.findById(id);
		boolean status = MemberArea.dao.deleteById(id);
		if (status) {
			// 删除图片资源
			FileUploadUtil.delFile(Constant.baseUploadPath + memberArea.getMemberAreaUnselectedImg());
			FileUploadUtil.delFile(Constant.baseUploadPath + memberArea.getMemberAreaSelectedImg());
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
}
