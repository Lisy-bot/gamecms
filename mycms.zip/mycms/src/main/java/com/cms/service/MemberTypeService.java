package com.cms.service;

import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.controller.MemberTypeController;
import com.cms.model.MemberType;
import com.jfinal.plugin.activerecord.Page;

public class MemberTypeService {
	// 根据ID查找
	public MemberType findById(int id) {
		return MemberType.dao.findById(id);
	}
	// 根据条件分页查询
	public Page<MemberType> queryAll(int pageNumber, int pageSize, String member_type_id, String member_type_name,
			String member_type_online, String member_type_integral) {
		return MemberType.dao.queryAll(pageNumber, pageSize, member_type_id, member_type_name, member_type_online,
				member_type_integral);
	}
	// 添加
	public String add(MemberTypeController controller) {
		MemberType memberType = controller.getModel(MemberType.class);
		if (BaseUtil.isNull(memberType.getMemberTypeName())) {
			return BaseUtil.returnMess(0, "请输入会员类型名称!", "");
		}
		boolean status = MemberType.dao.add(memberType);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}
	// 编辑
	public String edit(MemberTypeController controller) {
		MemberType memberType = controller.getModel(MemberType.class);
		if (BaseUtil.isNull(memberType.getMemberTypeName())) {
			return BaseUtil.returnMess(0, "请输入会员类型名称!", "");
		}
		boolean status = MemberType.dao.edit(memberType);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试！", "");
		}
	}
	// 删除
	public String del(MemberTypeController controller) {
		boolean status = MemberType.dao.deleteById(controller.getParaToInt("id"));
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
	
	/**
	 * 查询全部会员
	 * @return
	 */
	public List<MemberType> querrAll(){
		return MemberType.dao.querrAll();
	}
}
