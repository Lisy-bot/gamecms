package com.cms.service.auth;

import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.cms.common.util.BaseUtil;
import com.cms.model.auth.SysResource;
import com.cms.model.auth.SysUser;
import com.jfinal.aop.Invocation;
import com.jfinal.plugin.activerecord.Db;

/**
 * 服务类：权限管理
 * @author tanzhuo
 * @date 2017年5月17日
 */
public class AuthService {

	/**
	 * 加载菜单资源
	 * @param sysRole
	 * @return 
	 * @return menus 菜单资源集合
	 */
	public List<SysResource> initMenusResource(SysUser sysUser, int type) {
		List<SysResource> list = new ArrayList<SysResource>();
		if (sysUser == null) {
			return list;
		} else {
			// 获取角色ID
			List<Long> roleList = Db.query("select sysr_id from sys_user_role where sysu_id=?", sysUser.getSysuId());
			Integer size = roleList.size();
			if (size > 0) {
				String rid = "";
				for (int i = 0; i < size; i++) {
					rid += "," + roleList.get(i);
				}
				rid = rid.substring(1, rid.length());
				list = SysResource.dao
				        .find("select distinct s.res_id, s.res_pid, s.res_name, s.res_icon, s.res_url, s.res_open_type, s.res_resource_type, s.res_status, s.res_sort  from sys_role r left join sys_role_resource rr on r.sysr_id=rr.rores_roleid left join sys_resource s on rr.rores_resid=s.res_id where r.sysr_id in ("
				                + rid + ") and s.res_status=1 and s.res_resource_type=? order by res_sort desc", type);

			}
			return list;
		}
	}

	/**
	 * 地址权限
	 * @param url
	 * @return
	 */
	public static boolean haveAuth(SysUser user, String url) {
		if (user != null) {
			List<SysResource> list = getMenus(user, "!=2");
			for (SysResource sysResource : list) {
				if (url.equals(sysResource.getResUrl())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 按钮权限
	 * @param sysUser
	 * @param action
	 * @return
	 */
	public static Map<String, Object> buttonAuthMap(SysUser user, String ControllerKey) {
		List<SysResource> list = getMenus(user, "=1");
		Map<String, Object> butMap = new HashMap<String, Object>(); 
		if (list != null) {
			String url = null;
			for (SysResource sysResource : list) {
				url = sysResource.getResUrl();
				if (url.indexOf(ControllerKey) == 0) {
					String methodName = url.substring(ControllerKey.length() + 1, url.length());
					butMap.put(methodName, 1);
				}
			}
		}
		return butMap;
	}

	/**
	 * 权限列表
	 * @return
	 */
	public static List<SysResource> getMenus(SysUser user, String Type) {
		List<Long> roleList = Db.query("select sysr_id from sys_user_role where sysu_id=?", user.getSysuId());
		Integer size = roleList.size();
		if (size > 0) {
			String rid = "";
			for (int i = 0; i < size; i++) {
				rid += "," + roleList.get(i);
			}
			rid = rid.substring(1, rid.length());
			List<SysResource> list = SysResource.dao
			        .find("select distinct s.res_id, s.res_pid, s.res_name, s.res_icon, s.res_url, s.res_open_type, s.res_resource_type, s.res_status, s.res_sort  from sys_role r left join sys_role_resource rr on r.sysr_id=rr.rores_roleid left join sys_resource s on rr.rores_resid=s.res_id where r.sysr_id in ("
			                + rid + ") and s.res_status=1 and s.res_resource_type" + Type + " order by res_sort desc");
			return list;
		}
		return null;
	}

	/**
	 * 系统日志
	 * @param inv
	 */
	public static void sysLog(SysUser user, Invocation inv) {
		StringBuffer bfParams = new StringBuffer();
		HttpServletRequest request = inv.getController().getRequest();
		Enumeration<String> enu = request.getParameterNames();
		while (enu.hasMoreElements()) {
			String key = enu.nextElement();
			String value = request.getParameter(key);
			bfParams.append(key).append("=").append(value).append("&");
		}
		String params = null;
		if (BaseUtil.isNull(bfParams.toString())) {
			params = request.getQueryString();
		} else {
			// 去掉最后的&
			params = bfParams.substring(0, bfParams.length() - 1);
		}
		if (!BaseUtil.isNull(params)) {
			params = params.replaceAll("\r|\n", "");
		}

		String text = String.format("[用户ID]:%s,[控制器]:%s,[方法]:%s,[参数]:%s", user.getSysuId(), inv.getControllerKey(), inv.getMethodName(), params);

		if (inv.getController().getRequest().getMethod().equalsIgnoreCase("post") && !inv.getMethodName().equals("index")
		        && inv.getMethodName() != null) {
			Db.update("insert into sys_log(sysl_name,sysl_text,sysl_ip,sys_time) values(?,?,?,?)", user.getSysuName(), text,
			        BaseUtil.getIpAddr(inv.getController().getRequest()), new Date());
		}
	}

	/**
	 * 根据用户账号查询用户
	 */
	public static SysUser getUserByAccount(String account) {
		return SysUser.dao.loadByAccount(account);
	}
	
}
