package com.cms.service;
import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.controller.PrizeTypeController;
import com.cms.model.PrizeType;
import com.jfinal.plugin.activerecord.Page;

/**
 * 奖品Service层
 * 
 * @author Lisy
 */
public class PrizeTypeService {
	// 根据条件，分页查询
	public Page<PrizeType> queryAll(int pageNumber, int pageSize, String prize_type_id, String prize_type_name) {
		return PrizeType.dao.queryAll(pageNumber, pageSize, prize_type_id, prize_type_name);
	}

	// 根据ID查找
	public PrizeType findById(int id) {
		return PrizeType.dao.findById(id);
	}

	// 添加
	public String add(PrizeTypeController controller) {
		PrizeType prizeType = controller.getModel(PrizeType.class);
		if (BaseUtil.isNull(prizeType.getPrizeTypeName())) {
			return BaseUtil.returnMess(0, "请输入奖品类型名称", "");
		}
		boolean status = PrizeType.dao.add(prizeType);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(PrizeTypeController controller) {
		PrizeType prizeType = controller.getModel(PrizeType.class);
		if (BaseUtil.isNull(prizeType.getPrizeTypeName())) {
			return BaseUtil.returnMess(0, "请输入奖品类型名称", "");
		}
		boolean status = PrizeType.dao.edit(prizeType);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试!", "");
		}
	}

	// 删除
	public String del(PrizeTypeController controller) {
		boolean status = PrizeType.dao.deleteById(controller.getParaToInt("id"));
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}

	public List<PrizeType> getPrizeTypeList() {
		// TODO Auto-generated method stub
		return PrizeType.dao.getPrizeTypeList();
	}
}
