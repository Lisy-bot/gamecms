package com.cms.service;

import java.util.List;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.PlayerKillingController;
import com.cms.model.PlayerKilling;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

public class PlayerKillingService {
	// 根据条件分页查询
	public Page<PlayerKilling> queryAll(int pageNumber, int pageSize, String player_killing_id,
			String player_killing_name, String player_killing_online) {
		// TODO Auto-generated method stub
		return PlayerKilling.dao.queryAll(pageNumber, pageSize, player_killing_id, player_killing_name,
				player_killing_online);
	}

	// 添加
	public String add(PlayerKillingController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		PlayerKilling playerKilling = controller.getModel(PlayerKilling.class);
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					playerKilling.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(playerKilling.getPlayerKillingName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(playerKilling.getPlayerKillingSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		boolean status = PlayerKilling.dao.add(playerKilling);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

// 删除
	public String del(PlayerKillingController controller) {
		int id = controller.getParaToInt("id");
		PlayerKilling playerKilling = PlayerKilling.dao.findById(id);
		boolean status = PlayerKilling.dao.deleteById(id);
		if (status) {
			// 删除图片资源
			FileUploadUtil.delFile(Constant.baseUploadPath + playerKilling.getPlayerKillingSelectedImg());
			FileUploadUtil.delFile(Constant.baseUploadPath + playerKilling.getPlayerKillingUnselectedImg());
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}

// 编辑
	public String edit(PlayerKillingController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		PlayerKilling playerKilling = controller.getModel(PlayerKilling.class);
		// 根据ID查询
		PlayerKilling pKilling = PlayerKilling.dao.findById(playerKilling.getPlayerKillingId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					playerKilling.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + pKilling.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(playerKilling.getPlayerKillingName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(playerKilling.getPlayerKillingSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		}
		boolean status = PlayerKilling.dao.edit(playerKilling);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试！", "");
		}
	}

// 根据ID查询
	public PlayerKilling findById(int id) {
		// TODO Auto-generated method stub
		return PlayerKilling.dao.findById(id);
	}

	public List<PlayerKilling> getPlayerKillingList(PlayerKillingController playerKillingController) {
		// TODO Auto-generated method stub
		return PlayerKilling.dao.getPlayerKillingList();
	}

}
