package com.cms.service;

import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.controller.ActivityTypeController;
import com.cms.model.ActivityType;
import com.jfinal.plugin.activerecord.Page;

public class ActivityTypeService {
	/**
	 * 查询全部活动类型
	 * @param pageNumber
	 * @param pageSize
	 * @param act_name
	 * @return
	 */
	public Page<ActivityType> queryAll(int pageNumber,int pageSize,String act_name){
		return ActivityType.dao.queryAll(pageNumber,pageSize,act_name);
	}
	/**
	 * 添加活动类型
	 * @param controller
	 * @return
	 */
	public String add(ActivityTypeController controller){
		ActivityType activityType = controller.getModel(ActivityType.class);
		//为空判断
		if(BaseUtil.isNull(activityType.getActyTitle())){
			return BaseUtil.returnMess(0, "活动名称不能为空", "");
		}else if(BaseUtil.isNull(activityType.getBeginTime())||
				 BaseUtil.isNull(activityType.getEndTime())){
			return BaseUtil.returnMess(0, "活动时间不能为空", "");
		}
		boolean activity = ActivityType.dao.add(activityType);
		if(activity){
			return BaseUtil.returnMess(1, "新增成功！", "");
		}else{
			return BaseUtil.returnMess(0, "新增失败！", "");
		}
	}
	/**
	 * 根据活动id删除活动类型
	 * @param acty_id
	 * @return
	 */
	public String delActivityType(int acty_id){
		boolean status = ActivityType.dao.deleteById(acty_id);
		if(status){
			return BaseUtil.returnMess(1, "删除成功！", "");
		}else{
			return BaseUtil.returnMess(0, "删除失败！", "");
		}
	}
	/***
	 * 编辑活动类型
	 * @param activityType
	 * @return
	 */
	
	public String eidtActivityType(ActivityType activityType){
		boolean status = ActivityType.dao.edit(activityType);
		if(status){
			return BaseUtil.returnMess(1, "修改成功！", "");
		}else{
			return BaseUtil.returnMess(0, "修改失败！", "");
		}
	}
	/**
	 * 根据活动类型id查询
	 * @param id
	 * @return
	 */
	
	public ActivityType findById(int id){
		return ActivityType.dao.findById(id);
	}
	/**
	 * 获取活动类型下拉列表
	 * @return
	 */
	public List<ActivityType> getActyList(){
		return ActivityType.dao.getActyList();
	}
}
