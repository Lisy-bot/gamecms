package com.cms.service;

import com.cms.common.util.BaseUtil;
import com.cms.controller.PlayerKillingUserController;
import com.cms.model.PlayerKillingUser;
import com.jfinal.plugin.activerecord.Page;

public class PlayerKillingUserService {
	// 根据条件分页查询
	public Page<PlayerKillingUser> queryAll(int pageNumber, int pageSize, String player_killing_id,
			String player_killing_user_account) {
		return PlayerKillingUser.dao.queryAll(pageNumber, pageSize, player_killing_id, player_killing_user_account);
	}

	// 添加
	public String add(PlayerKillingUserController controller) {
		PlayerKillingUser playerKillingUser = controller.getModel(PlayerKillingUser.class);
		if (BaseUtil.isNull(playerKillingUser.getPlayerKillingUserAccount())) {
			return BaseUtil.returnMess(0, "请输入用户账号", "");
		} else if (BaseUtil.isNull(playerKillingUser.getPlayerKillingId())) {
			return BaseUtil.returnMess(0, "请选择阵营!", "");
		}
		boolean status = PlayerKillingUser.dao.add(playerKillingUser);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

// 删除
	public String del(PlayerKillingUserController controller) {
		boolean status = PlayerKillingUser.dao.deleteById(controller.getParaToInt("id"));
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}

// 编辑
	public String edit(PlayerKillingUserController controller) {
		PlayerKillingUser playerKillingUser = controller.getModel(PlayerKillingUser.class);
		if (BaseUtil.isNull(playerKillingUser.getPlayerKillingUserAccount())) {
			return BaseUtil.returnMess(0, "请输入用户账户", "");
		} else if (BaseUtil.isNull(playerKillingUser.getPlayerKillingId())) {
			return BaseUtil.returnMess(0, "请选择PK类型!", "");
		}
		boolean status = PlayerKillingUser.dao.edit(playerKillingUser);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试！", "");
		}
	}

	// 根据账户查询
	public PlayerKillingUser findById(int id) {
		// TODO Auto-generated method stub
		return PlayerKillingUser.dao.findById(id);
	}

}
