package com.cms.service.api;

import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.cms.common.util.RsaUtil;
import com.cms.model.auth.SysUser;
import com.jfinal.aop.Clear;

/**
 * 服务类：后台数据api接口
 * @author tanzhuo
 * @date 2017年10月14日
 */
@Clear
public class ApiDataService {

	/**
	 * 账号中心下发用户列表
	 * @param param 
	 * @return
	 */
	public String getUserList(String listStr) {
		try {
			byte[] datas = RsaUtil.uncompress(RsaUtil.base64Decode(listStr));
			if (datas == null) {
				return "error";
			}
			listStr = new String(datas, "utf-8");
			// 数据解析
			List<SysUser> datalist = JSON.parseArray(listStr, SysUser.class);
			// 获取本地数据
			List<SysUser> mylist = SysUser.dao.getUserList();
			boolean upStatus = false;
			for (SysUser sysUser : datalist) {
				// 从自己的库查找，有存档：判断是否需要修改。 无存档：判断是账号中心的，新增
				for (SysUser myUser : mylist) {
					if (sysUser.getSysuAccount().equals(myUser.getSysuAccount())) {
						// 存在相同账号，处理修改
						SysUser.dao.updateUser(sysUser, myUser);
						upStatus = true;
						break;
					}
				}
				// 判断是否需要新增
				if (!upStatus) {
					sysUser.setSysuAddTime(new Date());
					sysUser.setSysuStatus(1);
					sysUser.save();
				}
				// 还原标识
				upStatus = false;
			}
			// 处理删除
			upStatus = false;
			for (SysUser myUser : mylist) {
				for (SysUser sysUser : datalist) {
					if (myUser.getSysuAccount().equals(sysUser.getSysuAccount())) {
						upStatus = true;
					}
				}
				// 没找到，删除
				if (!upStatus) {
					myUser.delete();
				}
				// 还原标识
				upStatus = false;
			}

			return "success";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "error";
	}
}
