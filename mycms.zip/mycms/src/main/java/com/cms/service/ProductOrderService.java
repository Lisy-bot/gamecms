package com.cms.service;

import com.cms.common.util.BaseUtil;
import com.cms.controller.ProductOrderController;
import com.cms.model.ProductOrder;
import com.jfinal.plugin.activerecord.Page;

public class ProductOrderService {
	public Page<ProductOrder> queryAll(int pageNumber, int pageSize, String p_name, String p_online) {
		return ProductOrder.dao.queryAll(pageNumber, pageSize, p_name, p_online);
	}

	/**
	 * 添加数据
	 * 
	 * @param prizeType
	 * @return
	 */
	public String add(ProductOrderController controller) {
		ProductOrder productOrder = controller.getModel(ProductOrder.class);

		boolean status = ProductOrder.dao.add(productOrder);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	/**
	 * 编辑数据
	 * 
	 * @param prizeType
	 * @return
	 */
	public String edit(ProductOrderController controller) {
		ProductOrder productOrder = controller.getModel(ProductOrder.class);
		boolean status = ProductOrder.dao.edit(productOrder);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试！", "");
		}
	}

	// 删除
	public String del(ProductOrderController controller) {
		boolean status = ProductOrder.dao.deleteById(controller.getParaToInt("id"));
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}

	// 根据ID查询
	public ProductOrder findById(int id) {
		// TODO Auto-generated method stub
		return ProductOrder.dao.findById(id);
	}
}
