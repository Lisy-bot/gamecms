package com.cms.service.auth;

import java.util.Date;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.RsaUtil;
import com.cms.controller.auth.ApiAuthController;
import com.cms.model.auth.SysUser;
import com.cms.model.auth.SysUserRole;

/**
 * 服务类：中央管理后台对接API
 * @author tanzhuo
 * @date 2017年8月24日
 */
public class ApiService {

	/**
	 * 用户鉴权<br>
	 * 用户名、密码、命令lg
	 * @param params
	 * @param apiController 
	 * @return 1：成功，0：账号或密码输入错误！，2：账号已被锁定
	 */
	public int auth(String params, ApiAuthController apiController) {
		try {
			byte[] text = RsaUtil.string_to_buf(params);
			String data = new String(RsaUtil.decryptByPrivateKey(text, Constant.privateKey), "utf-8");
			JSONObject json = JSON.parseObject(data);
			if ("lg".equals(json.getString("cmd"))) {
				SysUser sysUser = SysUser.dao.loadByAccount(json.getString("u"));
				if (sysUser == null) {
					return 0;
				} else if (sysUser.getSysuStatus() == 0) {
					return 2;
				} else {
					if (json.getString("p").equals(sysUser.getSysuPassword())) {
						apiController.setSessionAttr(Constant.CONST_SESSION_SYS_USER, sysUser);
						// 登入成功更新用户登入信息
						SysUser tempUser = new SysUser();
						tempUser.setSysuId(sysUser.getSysuId());
						tempUser.setSysuLastIp(BaseUtil.getIpAddr(apiController.getRequest()));
						tempUser.setSysuLastTime(new Date());
						tempUser.update();

						return 1;
					} else {
						return 0;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * 用户同步、新增、修改<br>
	 * 用户名、密码、姓名、角色、状态、命令ds
	 * @param params
	 * @return
	 */
	public boolean dsUser(String params) {
		try {
			byte[] text = RsaUtil.string_to_buf(params);
			String data = new String(RsaUtil.decryptByPrivateKey(text, Constant.privateKey), "utf-8");
			JSONObject json = JSON.parseObject(data);
			if ("ds".equals(json.getString("cmd"))) {
				SysUser sysUser = SysUser.dao.loadByAccount(json.getString("u"));
				if (sysUser == null) {
					SysUser addUser = new SysUser();
					if (!BaseUtil.isNull(json.getString("u"))) {
						addUser.setSysuAccount(json.getString("u"));
					}
					if (!BaseUtil.isNull(json.getString("p"))) {
						addUser.setSysuPassword(json.getString("p"));
					}
					if (!BaseUtil.isNull(json.getString("n"))) {
						addUser.setSysuName(json.getString("n"));
					}
					if (!BaseUtil.isNull(json.getString("s"))) {
						addUser.setSysuStatus(json.getInteger("s"));
					}
					addUser.setSysuAddTime(new Date());
					// 新增用户
					boolean status = addUser.save();
					if (status) {
						// 新增角色
						String roleId = json.getString("r");
						if (!BaseUtil.isNull(roleId)) {
							String[] roleIds = roleId.split(",");
							for (int i = 0; i < roleIds.length; i++) {
								if (!BaseUtil.isNull(roleIds[i])) {
									SysUserRole ur = new SysUserRole();
									ur.setSysuId(addUser.getSysuId());
									ur.setSysrId(Integer.valueOf(roleIds[i]));
									ur.save();
								}
							}
						}
						return true;
					} else {
						return false;
					}
				} else {
					// 修改用户
					if (!BaseUtil.isNull(json.getString("p"))) {
						sysUser.setSysuPassword(json.getString("p"));
					}
					if (!BaseUtil.isNull(json.getString("n"))) {
						sysUser.setSysuName(json.getString("n"));
					}
					if (!BaseUtil.isNull(json.getString("s"))) {
						sysUser.setSysuStatus(json.getInteger("s"));
					}
					boolean status = sysUser.update();
					if (status) {
						// 根据用户ID，先删除所有角色
						SysUserRole.dao.delByUserId(sysUser.getSysuId());
						// 修改角色
						String roleId = json.getString("r");
						if (!BaseUtil.isNull(roleId)) {
							String[] roleIds = roleId.split(",");
							for (int i = 0; i < roleIds.length; i++) {
								if (!BaseUtil.isNull(roleIds[i])) {
									SysUserRole ur = new SysUserRole();
									ur.setSysuId(sysUser.getSysuId());
									ur.setSysrId(Integer.valueOf(roleIds[i]));
									ur.save();
								}
							}
						}
						return true;
					} else {
						return false;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 用户修改密码<br>
	 * 用户名、密码、命令ep
	 * @param params
	 * @return
	 */
	public boolean editPass(String params) {
		try {
			byte[] text = RsaUtil.string_to_buf(params);
			String data = new String(RsaUtil.decryptByPrivateKey(text, Constant.privateKey), "utf-8");
			JSONObject json = JSON.parseObject(data);
			if ("ep".equals(json.getString("cmd"))) {
				SysUser sysUser = SysUser.dao.loadByAccount(json.getString("u"));
				if (sysUser == null) {
					return false;
				} else {
					boolean status = false;
					if (!BaseUtil.isNull(json.getString("p"))) {
						sysUser.setSysuPassword(json.getString("p"));
						status = sysUser.update();
					}
					if (status) {
						return true;
					} else {
						return false;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 删除用户<br>
	 * 用户名、命令dl
	 * @param params
	 * @return
	 */
	public boolean delUser(String params) {
		try {
			byte[] text = RsaUtil.string_to_buf(params);
			String data = new String(RsaUtil.decryptByPrivateKey(text, Constant.privateKey), "utf-8");
			JSONObject json = JSON.parseObject(data);
			if ("dl".equals(json.getString("cmd"))) {
				SysUser sysUser = SysUser.dao.loadByAccount(json.getString("u"));
				if (sysUser == null) {
					return false;
				} else {
					// 根据用户ID，先删除所有角色
					SysUserRole.dao.delByUserId(sysUser.getSysuId());

					boolean status = sysUser.delete();
					if (status) {
						return true;
					} else {
						return false;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
