package com.cms.service.auth;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.OpenUrl;
import com.cms.common.util.OtpUtil;
import com.cms.common.util.RsaUtil;
import com.cms.controller.auth.HomeController;
import com.cms.model.auth.SysUser;
import com.cms.model.auth.SysUserRole;
import com.jfinal.captcha.CaptchaRender;
import com.jfinal.kit.HashKit;
import com.jfinal.kit.PropKit;
import com.jfinal.kit.StrKit;
import com.jfinal.plugin.activerecord.Page;

/**
 * 服务类：系统用户
 * @author tanzhuo
 * @date 2017年3月25日
 */
public class SysUserService {

	/**
	 * 用户信息验证
	 * @param sysUser
	 * @param password
	 * @return
	 */
	public String loginValidate(String account, String password, String captcha, HomeController homeController) {
		// 为空验证
		String userIsNull = isNull(account, password, captcha);
		if (userIsNull == null) {
			boolean CaptchaVal = CaptchaRender.validate(homeController, captcha);
			if (CaptchaVal) {
				SysUser sysUser = loadByAccount(account);
				if (sysUser == null) {
					return BaseUtil.returnMess("0", "账号或密码输入错误！", "");
				} else if (sysUser.getSysuStatus() == 0) {
					return BaseUtil.returnMess("0", "账号已被锁定，请联系管理员！", "");
				} else {
					password = HashKit.md5(HashKit.sha256(password + sysUser.getSysuToken()));
					if (password.equals(sysUser.getSysuPassword())) {
						homeController.setSessionAttr(Constant.CONST_SESSION_SYS_USER, sysUser);
						// 登入成功更新用户登入信息
						SysUser tempUser = new SysUser();
						tempUser.setSysuId(sysUser.getSysuId());
						tempUser.setSysuLastIp(BaseUtil.getIpAddr(homeController.getRequest()));
						tempUser.setSysuLastTime(new Date());
						tempUser.update();

						return BaseUtil.returnMess("1", "登录成功！", homeController.getRequest().getContextPath() + "/home/index");
					}
					return BaseUtil.returnMess("0", "账号或密码输入错误！", "");
				}
			} else {
				return BaseUtil.returnMess("0", "验证码输入错误！", "");
			}
		} else {
			return userIsNull;
		}
	}

	/**
	 * 登录非空判断
	 * @param account	账号
	 * @param password	密码
	 * @param captcha	验证码
	 * @return
	 */
	public String isNull(String account, String password, String captcha) {
		if (StrKit.isBlank(account)) {
			return BaseUtil.returnMess("0", "用户名不能为空！", "");
		} else if (StrKit.isBlank(password)) {
			return BaseUtil.returnMess("0", "密码不能为空！", "");
		} else if (StrKit.isBlank(captcha)) {
			return BaseUtil.returnMess("0", "验证码不能为空！", "");
		}
		return null;
	}

	/**
	 * 根据账号查询用户信息
	 * @param account
	 * @return
	 */
	public SysUser loadByAccount(String account) {
		return SysUser.dao.loadByAccount(account);
	}

	/**
	 * 查询全部用户
	 * @param page	页码
	 * @param pageSize	每页大小
	 * @return
	 */
	public Page<SysUser> queryAll(int pageNumber, int pageSize) {
		return SysUser.dao.queryAll(pageNumber, pageSize);
	}

	/**
	 * 添加管理员
	 * @param sysUser
	 * @return
	 */
	public String addSysUser(SysUser sysUser, Integer[] roleId) {
		// 生成usertoken
		String userToken = HashKit.md5(HashKit.sha256(BaseUtil.getRandTime()));
		// 生成密码
		String passWord = HashKit.md5(HashKit.sha256(sysUser.getSysuPassword() + userToken));
		sysUser.setSysuToken(userToken);
		sysUser.setSysuPassword(passWord);
		sysUser.setSysuAddTime(new Date());

		// 先查，再加
		SysUser getUser = SysUser.dao.loadByAccount(sysUser.getSysuAccount());
		if (getUser != null) {
			return BaseUtil.returnMess(0, "管理员账号已存在,请勿重复添加！", "");
		}
		boolean status = SysUser.dao.addSysUser(sysUser);
		if (status) {
			// 添加用户-角色
			for (int i = 0; i < roleId.length; i++) {
				SysUserRole ur = new SysUserRole();
				ur.setSysuId(sysUser.getSysuId());
				ur.setSysrId(roleId[i]);
				ur.save();
			}
			return BaseUtil.returnMess(1, "系统用户添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统用户添加失败，请重试！", "");
		}
	}

	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	public SysUser findById(int id) {
		return SysUser.dao.findById(id);
	}

	/**
	 * 修改
	 * @param sysUser
	 * @return
	 */
	public String editSysUser(SysUser sysUser, Integer[] roleId) {
		SysUser user = new SysUser();
		user.setSysuId(sysUser.getSysuId());
		user.setSysuAccount(sysUser.getSysuAccount());
		if (sysUser.getSysuPassword() != null) {
			// 生成usertoken
			String userToken = HashKit.md5(HashKit.sha256(BaseUtil.getRandTime()));
			// 生成密码
			String passWord = HashKit.md5(HashKit.sha256(sysUser.getSysuPassword() + userToken));
			user.setSysuToken(userToken);
			user.setSysuPassword(passWord);
		}
		user.setSysuName(sysUser.getSysuName());
		user.setSysuStatus(sysUser.getSysuStatus());

		boolean status = user.update();
		if (status) {
			// 根据用户ID，先删除所有角色
			SysUserRole.dao.delByUserId(sysUser.getSysuId());
			// 添加用户-角色
			for (int i = 0; i < roleId.length; i++) {
				SysUserRole ur = new SysUserRole();
				ur.setSysuId(sysUser.getSysuId());
				ur.setSysrId(roleId[i]);
				ur.save();
			}
			return BaseUtil.returnMess(1, "系统用户修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统用户修改失败，请重试！", "");
		}
	}

	/**
	 * 删除
	 * @param id
	 * @return
	 */
	public String del(int id) {
		// 根据用户ID，先删除所有角色
		SysUserRole.dao.delByUserId(id);

		boolean status = SysUser.dao.deleteById(id);
		if (status) {
			return BaseUtil.returnMess(1, "管理员账号删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "管理员账号删除失败，请重试！", "");
		}
	}

	/**
	 * 根据用户ID获取角色Ids
	 * @param id
	 * @return
	 */
	public List<Integer> getRoleIds(int id) {
		List<SysUserRole> list = SysUserRole.dao.getRoleIds(id);
		List<Integer> ids = new ArrayList<>();
		for (SysUserRole sysUserRole : list) {
			ids.add(sysUserRole.getSysrId());
		}
		return ids;
	}

	// 修改用户个人密码
	public String editPass(SysUser user, String pass, String pass2) {
		if (user != null && pass.equals(pass2)) {
			pass = HashKit.md5(HashKit.sha256(pass));
			boolean status = SysUser.dao.findById(user.getSysuId()).set("sysu_password", pass).update();
			if (status) {
				return BaseUtil.returnMess(1, "密码修改成功！", "");
			} else {
				return BaseUtil.returnMess(0, "密码修改失败，请重试！", "");
			}
		} else {
			return BaseUtil.returnMess(0, "非法操作！", "");
		}

	}

	/**
	 * 向账号中心同步用户列表
	 * @return
	 */
	public String getUserList() {
		String url = PropKit.use("config.properties").get("ssoUserListUrl");
		// RSA(long time#token)
		String key = System.currentTimeMillis() + "#" + OtpUtil.generate(PropKit.use("config.properties").get("otpKey"));
		byte[] data = null;
		try {
			data = RsaUtil.encryptByPrivateKey(key.getBytes(), PropKit.use("config.properties").get("authPrivateKey"));
			url = url + "?k=" + RsaUtil.buf_to_string(data);
			// 获取数据
			String listStr = OpenUrl.sendGet(url);
			byte[] datas = RsaUtil.uncompress(RsaUtil.base64Decode(listStr));
			if (datas == null) {
				return BaseUtil.returnMess(0, "网络出错或数据解析失败，请联系管理员！", "");
			}
			listStr = new String(datas, "utf-8");
			// 数据解析
			List<SysUser> datalist = JSON.parseArray(listStr, SysUser.class);
			// 获取本地数据
			List<SysUser> mylist = SysUser.dao.getUserList();
			boolean upStatus = false;
			for (SysUser sysUser : datalist) {
				// 从自己的库查找，有存档：判断是否需要修改。 无存档：判断是账号中心的，新增
				for (SysUser myUser : mylist) {
					if (sysUser.getSysuAccount().equals(myUser.getSysuAccount())) {
						// 存在相同账号，处理修改
						SysUser.dao.updateUser(sysUser, myUser);
						upStatus = true;
						break;
					}
				}
				// 判断是否需要新增
				if (!upStatus) {
					sysUser.setSysuAddTime(new Date());
					sysUser.setSysuStatus(1);
					sysUser.save();
				}
				// 还原标识
				upStatus = false;
			}
			// 处理删除
			upStatus = false;
			for (SysUser myUser : mylist) {
				for (SysUser sysUser : datalist) {
					if (myUser.getSysuAccount().equals(sysUser.getSysuAccount())) {
						upStatus = true;
					}
				}
				// 没找到，删除
				if (!upStatus) {
					myUser.delete();
				}
				// 还原标识
				upStatus = false;
			}

			return BaseUtil.returnMess(1, "用户同步成功！", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return BaseUtil.returnMess(0, "用户同步失败，请重试！", "");
	}
}
