package com.cms.service.auth;

import java.util.Date;
import java.util.List;

import com.cms.common.util.BaseUtil;
import com.cms.model.auth.SysRole;
import com.cms.model.auth.SysRoleResource;
import com.jfinal.plugin.activerecord.Page;

/**
 * 服务类：角色角色
 * @author tanzhuo
 * @date 2016年7月7日
 */
public class SysRoleService {

	/**
	 * 根据ID查询角色
	 * @param id
	 * @return
	 */
	public SysRole findById(int id) {
		return SysRole.dao.findById(id);
	}

	/**
	 * 查询全部角色
	 * @param params
	 * @return
	 */
	public Page<SysRole> queryAll(int pageNumber, int pageSize) {
		return SysRole.dao.queryAll(pageNumber, pageSize);
	}

	/**
	 * 查询角色列表
	 * @return
	 */
	public List<SysRole> getSysRoleList() {
		return SysRole.dao.getSysRoleList();
	}

	/**
	 * 添加角色
	 * @param sysRole
	 * @return
	 */
	public String add(SysRole sysRole) {
		sysRole.setSysrAddTime(new Date());
		boolean status = SysRole.dao.addSysRole(sysRole);
		if (status) {
			return BaseUtil.returnMess(1, "系统角色添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统角色添加失败，请重试！", "");
		}
	}

	/**
	 * 编辑角色
	 * @param sysRole
	 * @return
	 */
	public String edit(SysRole sysRole) {
		boolean status = SysRole.dao.editSysRole(sysRole);
		if (status) {
			return BaseUtil.returnMess(1, "系统角色修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统角色修改失败，请重试！", "");
		}
	}

	/**
	 * 删除角色
	 * @param id
	 * @return
	 */
	public String del(int id) {
		boolean status = SysRole.dao.deleteById(id);
		if (status) {
			return BaseUtil.returnMess(1, "系统角色删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "系统角色删除失败，请重试！", "");
		}
	}

	/**
	 * 根据角色ID查资源
	 * @param id
	 * @return
	 */
	public List<SysRoleResource> findAuth(int id) {
		return SysRoleResource.dao.findByRoleId(id);
	}

	/**
	 * 编辑角色权限
	 * @param id
	 * @param auth
	 * @return
	 */
	public String editAuth(int id, String auth) {
		// 先删除，再增加
		SysRoleResource.dao.deleteByRoleId(id);
		String[] res = auth.split(",");
		for (int i = 0; i < res.length; i++) {
			int resId = Integer.parseInt(res[i]);
			SysRoleResource.dao.add(id, resId);
		}
		return BaseUtil.returnMess(1, "角色授权成功！", "");
	}

}
