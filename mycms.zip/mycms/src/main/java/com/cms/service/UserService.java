package com.cms.service;
import java.util.Date;

import com.cms.common.util.BaseUtil;
import com.cms.controller.UserController;
import com.cms.model.User;
import com.jfinal.plugin.activerecord.Page;

/**
 * 奖品Service层
 * 
 * @author Lisy
 */
public class UserService {
	// 根据条件，分页查询
	public Page<User> queryAll(int pageNumber, int pageSize, String user_account, String user_order_status, String prize_id) {
		return User.dao.queryAll(pageNumber, pageSize, user_account, user_order_status, prize_id);
	}

	// 根据ID查找
	public User findById(int id) {
		return User.dao.findById(id);
	}

	// 添加
	public String add(UserController controller) {
		User user = controller.getModel(User.class);
		if (BaseUtil.isNull(user.getUserAccount())) {
			return BaseUtil.returnMess(0, "请输入用户账号!", "");
		}
		if(!BaseUtil.isNull(user.getUserPrizeId())) {
			user.setUserWinningTime(new Date());
		}
		user.setUserAddTime(new Date());
		boolean status = User.dao.add(user);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(UserController controller) {
		User user = controller.getModel(User.class);
		if (BaseUtil.isNull(user.getUserAccount())) {
			return BaseUtil.returnMess(0, "请输入用户账号!", "");
		}
		user.setUserUpdateTime(new Date());
		boolean status = User.dao.edit(user);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试!", "");
		}
	}

	// 删除
	public String del(UserController controller) {
		boolean status = User.dao.deleteById(controller.getParaToInt("id"));
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
}
