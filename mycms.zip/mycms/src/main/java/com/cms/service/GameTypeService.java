package com.cms.service;

import java.util.List;

import com.cms.model.GameType;
import com.jfinal.plugin.activerecord.Page;

/**
 * 游戏类型管理服务类
 * @author zengjinhao
 *
 */
public class GameTypeService {

	/**
	 * 分页查询游戏类型
	 */
	public Page<GameType> queryGameTypeByPage(int pageNumber, int pageSize){
		return GameType.dao.queryGameTypeByPage(pageNumber, pageSize);
	}
	
	/**
	 * 新增游戏类型
	 */
	public boolean addGameType(GameType gameType){
		return GameType.dao.addGameType(gameType);
	}
	
	/**
	 * 根据id获取游戏类型
	 */
	public GameType queryGameTypeById(int gameTypeId){
		return GameType.dao.queryGameTypeById(gameTypeId);
	}
	
	/**
	 * 修改游戏类型
	 */
	public boolean updateGameType(GameType gameType){
		return GameType.dao.updateGameType(gameType);
	}
	
	/**
	 * 根据id删除游戏类型
	 */
	public boolean delGameType(int gameTypeId){
		return GameType.dao.delGameType(gameTypeId);
	}
	
	/**
	 * 查询所有游戏类型
	 */
	public List<GameType> queryAllGameType(){
		return GameType.dao.queryAllGameType();
	}
	
}
