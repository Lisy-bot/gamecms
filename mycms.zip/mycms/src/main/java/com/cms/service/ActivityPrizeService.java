package com.cms.service;

import java.util.List;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.ActivityPrizeController;
import com.cms.model.ActivityPrize;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

public class ActivityPrizeService {
	/**
	 * 查询全部奖品类型
	 * @param pageNumber
	 * @param pageSize
	 * @param acty_title
	 * @param actp_title
	 * @return
	 */
	public Page<ActivityPrize> queryAll(int pageNumber, int pageSize, String acty_title, String actp_title) {
		return ActivityPrize.dao.queryAll(pageNumber, pageSize, acty_title, actp_title);
	}
	/**
	 * 添加奖品
	 * @param controller
	 * @return
	 */
	public String addActivityPrize(ActivityPrizeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		ActivityPrize activityPrize = new ActivityPrize();
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					activityPrize.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		// 为空判断
		if (BaseUtil.isNull(controller.getPara("activityPrize.acty_id"))) {

			return BaseUtil.returnMess(0, "活动名称不能为空", "");

		} else if (BaseUtil.isNull(controller.getPara("activityPrize.actp_title"))) {

			return BaseUtil.returnMess(0, "奖品名称不能为空", "");

		} else if (BaseUtil.isNull(controller.getPara("activityPrize.actp_count"))
		        || !BaseUtil.isNumer(controller.getPara("activityPrize.actp_count"))) {

			return BaseUtil.returnMess(0, "奖品数量不能为空或必须是数字", "");

		} else if (BaseUtil.isNull(controller.getPara("activityPrize.actp_probability"))) {

			return BaseUtil.returnMess(0, "奖品概率不能为空", "");

		}

		activityPrize.setActyId(Integer.parseInt(controller.getPara("activityPrize.acty_id")));

		activityPrize.setActpCount(Integer.parseInt(controller.getPara("activityPrize.actp_count")));

		activityPrize.setActpProbability(controller.getPara("activityPrize.actp_probability"));

		activityPrize.setActpTitle(controller.getPara("activityPrize.actp_title"));

		activityPrize.setActpRemark(controller.getPara("activityPrize.actp_remark"));

		boolean status = ActivityPrize.dao.add(activityPrize);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功", "");
		} else {
			return BaseUtil.returnMess(1, "添加失败", "");
		}
	}

	/**
	 * 根据活动id删除活动奖品
	 * @param acty_id
	 * @return
	 */
	public String delActivityPrize(int acty_id) {
		boolean status = ActivityPrize.dao.deleteById(acty_id);
		if (status) {
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败！", "");
		}
	}
	/***
	 * 编辑活动活动奖品
	 * @param activityType
	 * @return
	 */

	public String eidtActivityPrize(ActivityPrizeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		ActivityPrize activityPrize = controller.getModel(ActivityPrize.class);
		// 根据ID查询
		ActivityPrize prize = ActivityPrize.dao.findById(activityPrize.getActpId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					// 将图片移动到指定的上传目录下
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// String obj = list.get(i).getParameterName().replace("pointsHome.", ""); //
					// 得到当前mode对象字段名称
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					activityPrize.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + prize.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		boolean status = ActivityPrize.dao.edit(activityPrize);
		if (status) {
			return BaseUtil.returnMess(1, "活动类型修改成功！", "");
		} else {
			return BaseUtil.returnMess(0, "活动类型修改失败！", "");
		}
	}
	/**
	 * 根据Id查询一条数据
	 * @param id
	 * @return
	 */
	public ActivityPrize findById(int id) {
		return ActivityPrize.dao.findById(id);
	}
	/**
	 * 获取奖品类型下拉列表
	 * @return
	 */
	public List<ActivityPrize> getPrizeType(String acty_id) {
		return ActivityPrize.dao.getPrizeType(acty_id);
	}
}
