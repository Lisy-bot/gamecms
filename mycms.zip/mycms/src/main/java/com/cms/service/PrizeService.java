package com.cms.service;
import java.util.Date;
import java.util.List;
import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.PrizeController;
import com.cms.model.Prize;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

/**
 * 奖品Service层
 * 
 * @author Lisy
 */
public class PrizeService {
	// 根据条件，分页查询
	public Page<Prize> queryAll(int pageNumber, int pageSize, String prize_id, String prize_type_id, String prize_name,
			String prize_online) {
		return Prize.dao.queryAll(pageNumber, pageSize, prize_id, prize_type_id, prize_name, prize_online);
	}

	// 根据ID查找
	public Prize findById(int id) {
		return Prize.dao.findById(id);
	}

	// 添加
	public String add(PrizeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		Prize prize = controller.getModel(Prize.class);
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					prize.set(obj, file);
				}
			}
		} else {
			return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(prize.getPrizeName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(prize.getPrizeSort())) {
			return BaseUtil.returnMess(0, "请输入排序", "");
		} else if (BaseUtil.isNull(prize.getPrizeTypeId())) {
			return BaseUtil.returnMess(0, "请选择奖品类型", "");
		} 
		prize.setPrizeAddTime(new Date());
		boolean status = Prize.dao.add(prize);
		if (status) {
			return BaseUtil.returnMess(1, "添加成功！", "");
		} else {
			return BaseUtil.returnMess(0, "添加失败，请重试！", "");
		}
	}

	// 编辑
	public String edit(PrizeController controller) {
		List<UploadFile> list = BaseUtil.getFile(controller);
		Prize prize = controller.getModel(Prize.class);
		// 根据ID查询
		Prize prize2 = Prize.dao.findById(prize.getPrizeId());
		if (!BaseUtil.isNull(list)) {
			for (int i = 0; i < list.size(); i++) {
				if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
					return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
				} else {
					// 将图片移动到指定的上传目录下
					String file = FileUploadUtil.moveNewFile(
							list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
					// String obj = list.get(i).getParameterName().replace("pointsHome.", ""); //
					// 得到当前mode对象字段名称
					// 截取 . 后面的字符 例如：model.name 结果 name
					String obj = "";
					String str = list.get(i).getParameterName();
					if (str.indexOf(".") > 0) {
						String str1 = str.substring(0, str.indexOf("."));
						obj = str.substring(str1.length() + 1, str.length());
					}
					prize.set(obj, file); // 赋值
					// 删除以前的图片
					FileUploadUtil.delFile(Constant.baseUploadPath + prize2.get(obj));
				}
			}
		} else {
			return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
		}
		if (BaseUtil.isNull(prize.getPrizeName())) {
			return BaseUtil.returnMess(0, "请输入标题名称", "");
		} else if (BaseUtil.isNull(prize.getPrizeSort())) {
			return BaseUtil.returnMess(0, "请输入排序!", "");
		} else if (BaseUtil.isNull(prize.getPrizeTypeId())) {
			return BaseUtil.returnMess(0, "请输入奖品类型", "");
		}
		prize.setPrizeUpdateTime(new Date());
		boolean status = Prize.dao.edit(prize);
		if (status) {
			return BaseUtil.returnMess(1, "更新成功！", "");
		} else {
			return BaseUtil.returnMess(0, "更新失败，请重试!", "");
		}
	}

	// 删除
	public String del(PrizeController controller) {
		int prize_id = controller.getParaToInt("id");
		Prize prize = Prize.dao.findById(prize_id);
		boolean status = Prize.dao.deleteById(prize_id);
		if (status) {
			// 删除图片资源
			FileUploadUtil.delFile(Constant.baseUploadPath + prize.getPrizeSelectedImg());
			FileUploadUtil.delFile(Constant.baseUploadPath + prize.getPrizeUnselectedImg());
			return BaseUtil.returnMess(1, "删除成功！", "");
		} else {
			return BaseUtil.returnMess(0, "删除失败，请重试！", "");
		}
	}
	public List<Prize> getPrizeList(){
		return Prize.dao.getPrizeList();
	}
}
