package com.cms.service;
import java.util.Date;
import java.util.List;

import com.cms.common.Constant;
import com.cms.common.util.BaseUtil;
import com.cms.common.util.FileUploadUtil;
import com.cms.controller.GameController;
import com.cms.model.Game;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.upload.UploadFile;

/**
 * 游戏类型管理服务类
 * @author Lisy
 *
 */
public class GameService {
		/**
		 * 分页查询/按条件查询 游戏
		 * @param pageNumber
		 * @param pageSize
		 * @param gameId
		 * @param gameName
		 * @param gameTypeId
		 * @param gameOnline
		 * @return
		 */
		public Page<Game> queyAll(int pageNumber, int pageSize, String gameId, String gameName, String gameTypeId, String gameOnline) {
			return Game.dao.queryAll(pageNumber, pageSize, gameId, gameName, gameTypeId, gameOnline);
		}
		// 添加
		public String add(GameController controller) {
			List<UploadFile> list = BaseUtil.getFile(controller);
			Game game = controller.getModel(Game.class);
			if (!BaseUtil.isNull(list)) {
				for (int i = 0; i < list.size(); i++) {
					if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
						return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
					} else {
						String file = FileUploadUtil.moveNewFile(
								list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
						// 截取 . 后面的字符 例如：model.name 结果 name
						String obj = "";
						String str = list.get(i).getParameterName();
						if (str.indexOf(".") > 0) {
							String str1 = str.substring(0, str.indexOf("."));
							obj = str.substring(str1.length() + 1, str.length());
						}
						game.set(obj, file);
					}
				}
			} else {
				return BaseUtil.returnMess(0, "添加失败，上传资源太大,或未选中图片未上传!", "");
			}
			
			if (BaseUtil.isNull(game.getGameName())) {
				return BaseUtil.returnMess(0, "请输入游戏名称", "");
			} else if (BaseUtil.isNull(game.getGameTypeId())) {
				return BaseUtil.returnMess(0, "请选择游戏类型!", "");
			}
			game.setGameAddTime(new Date());
			boolean status = Game.dao.add(game);
			if (status) {
				return BaseUtil.returnMess(1, "添加成功！", "");
			} else {
				return BaseUtil.returnMess(0, "添加失败，请重试！", "");
			}
		}

	// 删除
		public String del(GameController controller) {
			int id = controller.getParaToInt("id");
			Game game = Game.dao.findById(id);
			boolean status = Game.dao.deleteById(id);
			if (status) {
				// 删除图片资源
				FileUploadUtil.delFile(Constant.baseUploadPath + game.getGameSelectedImg());
				FileUploadUtil.delFile(Constant.baseUploadPath + game.getGameUnselectedImg());
				return BaseUtil.returnMess(1, "删除游戏成功！", "");
			} else {
				return BaseUtil.returnMess(0, "删除游戏失败，请重试！", "");
			}
		}

	// 编辑
		public String edit(GameController controller) {
			
			List<UploadFile> list = BaseUtil.getFile(controller);
			Game game = controller.getModel(Game.class);
			// 根据ID查询
			Game game2 = Game.dao.findById(game.getGameId());
			if (!BaseUtil.isNull(list)) {
				for (int i = 0; i < list.size(); i++) {
					if (!FileUploadUtil.checkImageType(list.get(i).getContentType())) {
						return BaseUtil.returnMess(0, "上传图片格式错误，文件类型只能为png、jpg、gif!", "");
					} else {
						String file = FileUploadUtil.moveNewFile(
								list.get(i).getUploadPath() + "/" + list.get(i).getFileName(), Constant.advertUploadPath);
						// 截取 . 后面的字符 例如：model.name 结果 name
						String obj = "";
						String str = list.get(i).getParameterName();
						if (str.indexOf(".") > 0) {
							String str1 = str.substring(0, str.indexOf("."));
							obj = str.substring(str1.length() + 1, str.length());
						}
						game.set(obj, file); // 赋值
						// 删除以前的图片
						FileUploadUtil.delFile(Constant.baseUploadPath + game2.get(obj));
					}
				}
			} else {
				return BaseUtil.returnMess(0, "更新失败，上传资源太大,或未选中图片未上传!", "");
			}
			if (BaseUtil.isNull(game.getGameName())) {
				return BaseUtil.returnMess(0, "请输入游戏名称", "");
			} else if (BaseUtil.isNull(game.getGameTypeId())) {
				return BaseUtil.returnMess(0, "请选择游戏类型!", "");
			}
			game.setGameAddTime(new Date());
			boolean status = Game.dao.edit(game);
			if (status) {
				return BaseUtil.returnMess(1, "更新成功！", "");
			} else {
				return BaseUtil.returnMess(0, "更新失败，请重试！", "");
			}
		}

		// 根据账户查询
		public Game findById(int id) {
			// TODO Auto-generated method stub
			return Game.dao.findById(id);
		}
}
