
/**
 * 把时间戳格式化成日期
 */
function formatTime(time) { 
	return new Date(parseInt(time)).toLocaleString().replace(/年|月/g, "-").replace(/日/g, " "); 
}

// 判断是否是正整数
function IsNum(s)
{
    if(s!=null && s!=""){
        var r,re;
        re = /\d*/i; // \d表示数字,*表示匹配多个数字
        r = s.match(re);
        return (r==s)?true:false;
    }
    return false;
}

// 判断是否是浮点数
function isFloat(c)
{
    var r= /^[+-]?[1-9]?[0-9]*\.[0-9]*$/;
    return r.test(c);
}

/*******************************************************************************
 * 
 * @requires jQuery
 * 
 * 页面加载加载进度条启用
 ******************************************************************************/
function progressLoad(){  
    $("<div class=\"datagrid-mask\" style=\"position:absolute;z-index: 9999;\"></div>").css({display:"block",width:"100%",height:$(window).height()}).appendTo("body");  
    $("<div class=\"datagrid-mask-msg\" style=\"position:absolute;z-index: 9999;\"></div>").html("正在处理，请稍候。。。").appendTo("body").css({display:"block",left:($(document.body).outerWidth(true) - 190) / 2,top:($(window).height() - 45) / 2});  
}

/*******************************************************************************
 * 
 * @requires jQuery
 * 
 * 页面加载加载进度条关闭
 ******************************************************************************/
function progressClose(){
    $(".datagrid-mask").remove();  
    $(".datagrid-mask-msg").remove();
}

/**
 * 获取昨天的时间年-月-日
 */
function getCurrentTime1() {
	var myDate = new Date();
	myDate.setDate(myDate.getDate() - 1);
	var year = myDate.getFullYear(),
		month = (myDate.getMonth() + 1) > 9 ? (myDate.getMonth() + 1) : '0' + (myDate.getMonth() + 1),
		day = myDate.getDate() > 9 ? myDate.getDate() : '0' + myDate.getDate();
	return year + '-' + month + '-' + day;
}

/**
 * 时间比较{结束时间大于开始时间}
 * 
 * @parameter startTime: 开始时间； endTime: 结束时间
 */
function compareDateEndTimeGTStartTime(startTime, endTime) {
    return ((new Date(endTime.replace(/-/g, "/"))) >= (new Date(
            startTime.replace(/-/g, "/"))));
}

function addSort(str,id,sort,offline,name) {
	$(str).parent().remove();
	var li="<li class='sortonline'>"+name+"<span class='minus online' onclick='delSort(this,"+id+","+sort+","+offline+",\""+name+"\");'></span></li>";
	$("#onlinetb").append(li);
} 

function delSort(str,id,sort,online,name) {
	$(str).parent().remove();
	var li="<li class='sortdefault'>"+name+"<span class='plus offline' onclick='addSort(this,"+id+","+sort+","+online+",\""+name+"\");'></span></li>";
	$("#offlinetb").append(li);
}

var list = new Array();
function getList(){
	list = [];
	var lenght = $("#offlinetb li").length;
	$("#offlinetb li span").each(function (index, element) {
	    if(element.className.indexOf("offline")>-1){
	    	var str = $(element).attr("onclick");
	    	str = str.replace("addSort(this,","").replace(");","");
	    	str = str.split(",");
	    	if(str[2]!=0){
	    		list.push(new but(str[0],lenght-index,str[3]));
	    	}
	    }
	});
	return JSON.stringify(list);
}

var onlineList = new Array();
function getOnline(){
	onlineList = [];
	var lenght = $("#onlinetb li").length;
	$("#onlinetb li span").each(function (index, element) {
    	var str = $(element).attr("onclick");
    	str = str.replace("delSort(this,","").replace(");","");
    	str = str.split(",");
    	if(element.className.indexOf("online")>-1){
    		onlineList.push(new but(str[0],lenght-index,str[3]));
		}else if (str[1]!=(lenght-index)) {
			onlineList.push(new but(str[0],lenght-index,str[3]));
		}
	});
	return JSON.stringify(onlineList);
}

function but(id,sort,name){
	this.id=id;
	this.sort=sort;
	// this.name=name;
}

// 数据分析模块
var statis=function(){
	/**
	 * 全选全不选
	 * 
	 * @param this指向改checkbox;
	 */
	var changeCheckbox=function(_this) {
		if ($(_this).is(':checked')) {
			$(_this).parents('p').siblings().find("input:checkbox").prop("checked", true);
		} else {
			$(_this).parents('p').siblings().find("input:checkbox").prop("checked", false);
		}
	};
	/**
	 * 隐藏字段
	 */
	var hiddenFieldFun=function(dialogId,datagrId) {
		var data = $("#"+dialogId+" input[name='checkbox']");
		$.each(data, function(key, value) {
			var str = value.value;
			if ($(value).is(':checked')) {
				$('#'+datagrId).datagrid('showColumn', str);
			} else {
				$('#'+datagrId).datagrid('hideColumn', str);
			}
		});
	};
	/**
	 * 弹出框
	 */
	var dialogFun = function (dialog,datagrid){		
		$('#'+dialog).dialog({
			title : '字段筛选',
			collapsible : true,
			minimizable : true,
			maximizable : true,
			resizable : true,
			width : 500,
			height : 400,
			modal : true,
			buttons : [ {
				text : '确定',
				iconCls : 'icon-ok',
				handler : function() {
					statis.hiddenFieldFun(dialog,datagrid);
					$('#'+dialog).dialog('close');
				}
			}, {
				text : '取消',
				iconCls : 'icon-cancel',
				handler : function() {
					$('#'+dialog).dialog('close');
				}
			}]
		});
	};
	/**
	 * 获取显示的列的值
	 */
	var getList =function(formid,fielid,fielname){
		var fielid=fielid||'statdate,area_name';
		var fielname=fielname||'日期,专区名称';
		var list=$("#"+formid+" input[name='checkbox']");
		$.each(list,function(key,value){
			var idstr=value.value;	
			var idname=$(value).parent().text();
			
			if($(value).is(':checked')){
				fielid+=','+idstr;
				fielname+=','+idname;
			}
		});
		return {
			fielid:fielid,
			fielname:fielname
		}
	};
	
	/**
	 * 初始化下拉列表
	 */
	var comboFun = function (id,data){		
		$('#'+id).combobox({
			data : data,
			width : '200',
			height : '25',
			valueField : 'id',
			textField : 'area_name',
			panelWidth : '200',
			panelHeight : 'auto',
			panelMaxHeight : '300',
			editable : false,
		});
	};
	/**
	 * 初始化日期
	 */
	var timeFormat=function(temp1,temp2){
		var start = getCurrentTime1();// 初始化数据报表开始时间
		/**
		 * 初始化开始日期
		 */
		$("#"+temp1).datebox().datebox('calendar').calendar({
			validator:function(date){
				var y = date.getFullYear(),
					m = date.getMonth()+1,
					d = date.getDate();
				
				var time=y+"-"+m+"-"+d;
			
				var td=compareDateEndTimeGTStartTime(time,start);
				if (td) {
				 	return true;
				}else {
					 return false;
				}
			}
		});
		/**
		 * 赋值开始日期
		 */
		$("#"+temp1).datebox().datebox('setValue',start);
		/**
		 * 初始化结束日期
		 */
		$("#"+temp2).datebox().datebox('calendar').calendar({
			validator:function(date){
				var y = date.getFullYear(),
					m = date.getMonth()+1,
					d = date.getDate();
				
				var time=y+"-"+m+"-"+d;
			
				var td=compareDateEndTimeGTStartTime(time,start);
				if (td) {
				 	return true;
				}else {
					 return false;
				}
			}
		});
		/**
		 * 赋值结束日期
		 */
		$("#"+temp2).datebox().datebox('setValue',start);
	};
	
	return {
		changeCheckbox:changeCheckbox,
		hiddenFieldFun:hiddenFieldFun,
		dialogFun:dialogFun,
		comboFun:comboFun,
		timeFormat:timeFormat,
		getList:getList,
	}
}();

function showImging(imgUrl){
    if(!imgUrl || !/\.(gif|jpg|jpeg|png|GIF|JPEG|JPG|PNG)$/.test(imgUrl)){
    	console.log("没有图片哦!")
        return false;
    }
    if(document.getElementById('showImg-container')) return false;
    var div = document.createElement('div');
    div.style.cssText="position:absolute;top: 274px; z-index: 9999; max-width:600px;max-height: 300px;";
    div.id = 'showImg-container';
    document.body.appendChild(div);
    div.innerHTML='<img src="'+imgUrl+'" alt="图片不存在" style=" max-width:600px;max-height: 300px"/>';
}
/**
 * 判断是否为空
 * 
 * @param obj
 * @returns 空值有：undefined、 null、 ''、 NaN、false、0、[]、{} 、空白字符串，这些都返回true。
 */
function isEmpty(v) {
    switch (typeof v) {
	    case 'undefined':
	        return true;
	        break;
	    case 'string':
	        if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
	        break;
	    case 'boolean':
	        if (!v) return true;
	        break;
	    case 'number':
	        if (0 === v || isNaN(v)) return true;
	        break;
	    case 'object':
	        if (null === v || v.length === 0) return true;
	        for (var i in v) {
	            return false;
	        }
	        return true;
	    }
    return false;
}
function hideImging(){
	document.getElementById('showImg-container') && document.body.removeChild(document.getElementById('showImg-container'));
}