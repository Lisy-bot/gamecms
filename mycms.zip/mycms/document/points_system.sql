/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50549
 Source Host           : localhost:3306
 Source Schema         : points_system

 Target Server Type    : MySQL
 Target Server Version : 50549
 File Encoding         : 65001

 Date: 30/06/2020 18:20:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for game
-- ----------------------------
DROP TABLE IF EXISTS `game`;
CREATE TABLE `game`  (
  `game_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `game_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游戏名称',
  `game_type_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游戏PK类型ID',
  `game_url` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '游戏跳转地址',
  `game_selected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '游戏选中图',
  `game_unselected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '游戏不选中图',
  `game_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上线；0下线，1上线',
  `game_is_param` tinyint(2) NOT NULL DEFAULT 0 COMMENT '是否带参数：0 否，1是',
  `game_sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `game_add_time` datetime NOT NULL COMMENT '游戏添加时间',
  `game_update_time` datetime NULL DEFAULT NULL COMMENT '游戏更新时间',
  PRIMARY KEY (`game_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of game
-- ----------------------------
INSERT INTO `game` VALUES (2, '打法的', '1', NULL, NULL, 'advert/1591585440060585.jpg', 0, 0, 1, '2020-06-08 11:04:00', NULL);
INSERT INTO `game` VALUES (3, '123', '1', NULL, NULL, NULL, 0, 0, NULL, '2020-06-08 11:04:26', NULL);
INSERT INTO `game` VALUES (6, '图片删除测试', '3', NULL, 'advert/1591596896038229.jpg', 'advert/1591596896040681.png', 0, 0, 1, '2020-06-08 14:14:56', NULL);

-- ----------------------------
-- Table structure for game_type
-- ----------------------------
DROP TABLE IF EXISTS `game_type`;
CREATE TABLE `game_type`  (
  `game_type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `game_type_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '游戏类型名称',
  PRIMARY KEY (`game_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of game_type
-- ----------------------------
INSERT INTO `game_type` VALUES (1, '动作1');
INSERT INTO `game_type` VALUES (3, '休闲');

-- ----------------------------
-- Table structure for intercept
-- ----------------------------
DROP TABLE IF EXISTS `intercept`;
CREATE TABLE `intercept`  (
  `intercept_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '拦截ID',
  `intercept_type_id` int(11) NOT NULL COMMENT '拦截类型ID',
  `intercept_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上下线，0否，1是',
  `intercept_param` tinyint(2) NOT NULL DEFAULT 0 COMMENT '是否带参数，0否，1是',
  `intercept_url` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '拦截地址',
  PRIMARY KEY (`intercept_id`) USING BTREE,
  INDEX `inte_id_index`(`intercept_type_id`) USING BTREE,
  INDEX `inty_id_index`(`intercept_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '拦截表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of intercept
-- ----------------------------
INSERT INTO `intercept` VALUES (1, 1, 1, 0, 'http:www.baidu.com');
INSERT INTO `intercept` VALUES (2, 1, 1, 0, 'www.baidu');
INSERT INTO `intercept` VALUES (3, 3, 1, 0, '123123123');
INSERT INTO `intercept` VALUES (4, 1, 0, 0, '123123123');

-- ----------------------------
-- Table structure for intercept_type
-- ----------------------------
DROP TABLE IF EXISTS `intercept_type`;
CREATE TABLE `intercept_type`  (
  `intercept_type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '拦截类型ID',
  `intercept_type_name` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '拦截类型中文名',
  `intercept_type_name_en` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '拦截类型英文名',
  PRIMARY KEY (`intercept_type_id`) USING BTREE,
  INDEX `inty_name_index`(`intercept_type_name`) USING BTREE,
  INDEX `inty_id_index`(`intercept_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '拦截类型表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of intercept_type
-- ----------------------------
INSERT INTO `intercept_type` VALUES (1, '首页拦截1', 'home_index');
INSERT INTO `intercept_type` VALUES (3, 'adfadf', 'adfadf12312312');

-- ----------------------------
-- Table structure for member_area
-- ----------------------------
DROP TABLE IF EXISTS `member_area`;
CREATE TABLE `member_area`  (
  `member_area_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `member_area_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '标题名称',
  `member_area_selected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '选中图',
  `member_area_unselected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '不选中图',
  `member_area_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '跳转地址',
  `member_area_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上线，0下线，1上线',
  `member_area_sort` int(11) NOT NULL COMMENT '排序时间',
  `member_area_isparam` tinyint(2) NOT NULL DEFAULT 0 COMMENT '是否带参数：0不带参。1带参',
  `member_area_add_time` datetime NOT NULL COMMENT '添加时间',
  `member_area_update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`member_area_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员专享福利特权专区表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of member_area
-- ----------------------------
INSERT INTO `member_area` VALUES (1, '123123', 'advert/1589789587141369.gif', 'advert/1589789587120311.png', NULL, 1, 5, 0, '2020-05-18 15:50:24', '2020-05-18 16:13:07');
INSERT INTO `member_area` VALUES (3, '测试2', 'advert/1589854307160408.png', 'advert/1589854321815707.png', NULL, 1, 1, 0, '2020-05-19 09:50:39', '2020-05-19 10:12:01');
INSERT INTO `member_area` VALUES (4, '测试3', '', 'advert/1589853532130861.png', NULL, 1, 2, 0, '2020-05-19 09:56:14', '2020-05-19 09:58:52');
INSERT INTO `member_area` VALUES (5, '组合测试', 'advert/1589856260573642.png', 'advert/1589856260571247.png', 'md.jd.com', 1, 1, 1, '2020-05-19 10:44:20', NULL);
INSERT INTO `member_area` VALUES (7, '1123123', 'advert/1589856660367877.jpg', 'advert/158985666036596.jpg', NULL, 1, -1, 1, '2020-05-19 10:51:00', NULL);
INSERT INTO `member_area` VALUES (8, '123123', 'advert/1589856707700638.jpg', 'advert/1589856707697128.jpg', NULL, 1, 1, 1, '2020-05-19 10:51:47', NULL);
INSERT INTO `member_area` VALUES (9, 'asfda', 'advert/158985683499413.png', 'advert/1589856834992187.png', '123123123', 0, 2, 1, '2020-05-19 10:52:19', '2020-05-19 10:53:54');

-- ----------------------------
-- Table structure for member_type
-- ----------------------------
DROP TABLE IF EXISTS `member_type`;
CREATE TABLE `member_type`  (
  `member_type_id` int(2) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `member_type_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '会员名称',
  `member_type_integral` int(11) NOT NULL DEFAULT 0 COMMENT '会员到达积分数',
  `member_type_online` tinyint(2) NOT NULL COMMENT '是否上下线：0下线，1上线 ，其他',
  PRIMARY KEY (`member_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员类型表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of member_type
-- ----------------------------
INSERT INTO `member_type` VALUES (1, '普通会员', 0, 1);
INSERT INTO `member_type` VALUES (2, '白银会员', 200, 1);
INSERT INTO `member_type` VALUES (3, '黄金会员', 300, 1);
INSERT INTO `member_type` VALUES (4, '钻石会员', 400, 1);
INSERT INTO `member_type` VALUES (5, '黄金会员', 500, 1);

-- ----------------------------
-- Table structure for player_killing
-- ----------------------------
DROP TABLE IF EXISTS `player_killing`;
CREATE TABLE `player_killing`  (
  `player_killing_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK自增ID',
  `player_killing_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'PK类型名称',
  `player_killing_votes` int(11) NOT NULL DEFAULT 0 COMMENT '获得PK票数',
  `player_killing_selected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'PK选中图片',
  `player_killing_unselected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'PK不选中图片',
  `player_killing_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '结束PK后，跳转的地址',
  `palyer_killing_isparam` tinyint(2) NOT NULL COMMENT '是否带参数： 0 不带，1带',
  `player_killing_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上下线；0下线 1上线',
  `player_killing_sort` int(11) NOT NULL DEFAULT 1 COMMENT '排序',
  `player_killing_end_time` datetime NOT NULL COMMENT 'PK结束时间',
  PRIMARY KEY (`player_killing_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = 'PK结果表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of player_killing
-- ----------------------------
INSERT INTO `player_killing` VALUES (1, '棋牌游戏', 0, 'advert/1589876963083234.png', 'advert/1589875736694317.jpg', 'http://127.0.0.1:8080/mycms/playerKilling/edit?player_killing_id=3', 1, 1, 15916261, '2020-05-20 23:59:59');
INSERT INTO `player_killing` VALUES (2, '动作游戏', 999999999, 'advert/1589876932682984.png', 'advert/1589876932680374.png', 'www.baidu.com', 0, 2, 12, '2020-05-28 23:59:59');
INSERT INTO `player_killing` VALUES (3, '休闲游戏', 100, '', 'advert/1589876874336849.jpg', NULL, 0, 1, 815, '2020-05-19 23:59:59');

-- ----------------------------
-- Table structure for player_killing_user
-- ----------------------------
DROP TABLE IF EXISTS `player_killing_user`;
CREATE TABLE `player_killing_user`  (
  `player_killing_user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `player_killing_user_type_id` int(11) NOT NULL COMMENT 'PK类型ID',
  `player_killing_user_account` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'PK账户',
  PRIMARY KEY (`player_killing_user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '标识用户投票的PK类型' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of player_killing_user
-- ----------------------------
INSERT INTO `player_killing_user` VALUES (1, 2, 'test');
INSERT INTO `player_killing_user` VALUES (2, 1, '123Test');

-- ----------------------------
-- Table structure for points_home
-- ----------------------------
DROP TABLE IF EXISTS `points_home`;
CREATE TABLE `points_home`  (
  `points_home_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `points_home_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '入口名称',
  `points_home_url` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '跳转地址',
  `points_home_unselected_image` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '未选中图',
  `points_home_selected_image` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '选中图',
  `points_home_sort` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `points_home_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上线，0下线，1上线',
  `points_home_update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `points_home_add_time` datetime NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`points_home_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '积分系统首页' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of points_home
-- ----------------------------
INSERT INTO `points_home` VALUES (1, '会员积分实物兑奖', '/prize', 'advert/1593412402359989.png', 'advert/1593412402361736.png', 1, 1, '2020-06-29 14:33:22', '2020-05-15 16:05:28');
INSERT INTO `points_home` VALUES (2, '玩家派有奖PK', NULL, 'advert/1593412382655368.png', 'advert/1593412382657224.png', 3, 1, '2020-06-29 14:33:02', '2020-05-15 16:17:00');
INSERT INTO `points_home` VALUES (3, '会员专享特权福利', NULL, 'advert/159341239237048.png', 'advert/1593412392372948.png', 2, 1, '2020-06-29 14:33:12', '2020-05-18 10:08:17');
INSERT INTO `points_home` VALUES (4, '每日签到抽大奖', NULL, 'advert/1593412370043668.png', 'advert/1593412370046241.png', 4, 1, '2020-06-29 14:32:50', '2020-06-29 11:09:31');

-- ----------------------------
-- Table structure for points_sys_img
-- ----------------------------
DROP TABLE IF EXISTS `points_sys_img`;
CREATE TABLE `points_sys_img`  (
  `points_sys_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `points_sys_type_id` int(11) NULL DEFAULT NULL COMMENT '系统类型ID',
  `points_sys_json` varchar(2048) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '积分系统或积分活动全部图片',
  `points_sys_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '积分系统或活动名称',
  PRIMARY KEY (`points_sys_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '积分系统图片表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of points_sys_img
-- ----------------------------
INSERT INTO `points_sys_img` VALUES (1, 1, '[{\"lable\":\"首页\",\"child\":[{\"imgUrl\":\"sysImg/1593412024961585.png\",\"title\":\"背景图\"},{\"imgUrl\":\"sysImg/1593412526954544.png\",\"title\":\"返回按钮不选中图\"},{\"imgUrl\":\"sysImg/159341207096326.png\",\"title\":\"返回按钮选中图\"}]},{\"lable\":\"积分兑换实物奖品专区\",\"child\":[{\"imgUrl\":\"sysImg/1593415696668765.png\",\"title\":\"背景图\"},{\"imgUrl\":\"sysImg/159348014613961.png\",\"title\":\"返回按钮未选中图\"},{\"imgUrl\":\"sysImg/1593480156843939.png\",\"title\":\"返回按钮选中图\"},{\"imgUrl\":\"sysImg/1593415793035330.png\",\"title\":\"兑奖信息按钮未选中图\"},{\"imgUrl\":\"sysImg/1593415812930241.png\",\"title\":\"兑奖信息按钮选中图\"}]},{\"lable\":\"规则页面\",\"child\":[{\"imgUrl\":\"sysImg/1593511860792652.png\",\"title\":\"背景图\"},{\"imgUrl\":\"sysImg/1593511881106246.png\",\"title\":\"返回按钮未选中图\"},{\"imgUrl\":\"sysImg/1593511904865552.png\",\"title\":\"返回按钮选中图\"}]}]', '积分乐园');

-- ----------------------------
-- Table structure for points_sys_type
-- ----------------------------
DROP TABLE IF EXISTS `points_sys_type`;
CREATE TABLE `points_sys_type`  (
  `points_sys_type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `points_sys_type_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '系统类型名称:活动系统，积分系统',
  PRIMARY KEY (`points_sys_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统类型表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of points_sys_type
-- ----------------------------
INSERT INTO `points_sys_type` VALUES (1, '积分系统管理');

-- ----------------------------
-- Table structure for prize
-- ----------------------------
DROP TABLE IF EXISTS `prize`;
CREATE TABLE `prize`  (
  `prize_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `prize_type_id` int(11) NOT NULL COMMENT '奖品类型ID',
  `prize_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '奖品名称',
  `prize_selected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '奖品选中图片',
  `prize_unselected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '奖品不选中图片',
  `prize_sort` int(11) NOT NULL COMMENT '奖品排序',
  `prize_probability` tinyint(4) NOT NULL DEFAULT 0 COMMENT '奖品中奖概率',
  `prize_points` int(11) NULL DEFAULT 0 COMMENT '奖品兑奖积分数',
  `prize_quantity` int(6) NULL DEFAULT 0 COMMENT '奖品数量',
  `prize_online` tinyint(2) NOT NULL DEFAULT 1 COMMENT '是否上下线，0下线，1上线',
  `prize_remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '奖品备注',
  `prize_add_time` datetime NOT NULL COMMENT '添加时间',
  `prize_update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`prize_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '奖品表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of prize
-- ----------------------------
INSERT INTO `prize` VALUES (1, 1, 'IpaiMini', 'advert/1593506679538863.png', 'advert/1593480889274709.png', 1, 0, 5000, 2, 1, '奖品描述', '2020-05-22 11:37:33', '2020-06-30 16:44:39');
INSERT INTO `prize` VALUES (2, 1, '华为手机', 'advert/1593506750733633.png', 'advert/1593480941376546.png', 2, 0, 4000, 2, 1, NULL, '2020-05-22 14:40:55', '2020-06-30 16:45:50');
INSERT INTO `prize` VALUES (3, 1, 'PS4游戏机', 'advert/1593506758049501.png', 'advert/1593480980598695.png', 3, 0, 3500, 1, 1, NULL, '2020-05-22 17:03:20', '2020-06-30 16:45:58');
INSERT INTO `prize` VALUES (4, 1, '漫步者耳机', 'advert/1593506764521109.png', 'advert/1593481020226460.png', 4, 0, 3000, 3, 1, NULL, '2020-06-30 09:37:00', '2020-06-30 16:46:04');
INSERT INTO `prize` VALUES (5, 1, '蓝牙游戏手柄', 'advert/159350681694599.png', 'advert/1593481065044962.png', 5, 0, 2500, 5, 1, NULL, '2020-06-30 09:37:45', '2020-06-30 16:46:56');
INSERT INTO `prize` VALUES (6, 1, '游戏鼠标', 'advert/1593506823931803.png', 'advert/1593481102430152.png', 6, 0, 2000, 5, 1, NULL, '2020-06-30 09:38:22', '2020-06-30 16:47:03');
INSERT INTO `prize` VALUES (7, 1, '小米智能音响', 'advert/1593506831138872.png', 'advert/1593481171607149.png', 7, 0, 1500, 6, 1, NULL, '2020-06-30 09:39:31', '2020-06-30 16:47:11');
INSERT INTO `prize` VALUES (8, 1, '迪士尼彩笔', 'advert/1593506839505969.png', 'advert/159348124256577.png', 8, 0, 1000, 10, 1, NULL, '2020-06-30 09:40:42', '2020-06-30 16:47:19');
INSERT INTO `prize` VALUES (9, 1, '百科全书', 'advert/1593506845969798.png', 'advert/1593481288377562.png', 9, 0, 800, 10, 1, NULL, '2020-06-30 09:41:28', '2020-06-30 16:47:25');
INSERT INTO `prize` VALUES (10, 1, '动漫卡通拼图', 'advert/1593506852064691.png', 'advert/1593481345986565.png', 10, 0, 600, 15, 1, NULL, '2020-06-30 09:42:25', '2020-06-30 16:47:32');
INSERT INTO `prize` VALUES (11, 1, '奥特曼文具套装', 'advert/1593506858092925.png', 'advert/1593481385708100.png', 11, 0, 500, 20, 1, NULL, '2020-06-30 09:43:05', '2020-06-30 16:47:38');
INSERT INTO `prize` VALUES (12, 1, '熊出没玩具', 'advert/1593506864721809.png', 'advert/1593481421938870.png', 12, 0, 400, 20, 1, NULL, '2020-06-30 09:43:41', '2020-06-30 16:47:44');
INSERT INTO `prize` VALUES (13, 1, '猪猪侠玩具', 'advert/1593506871225929.png', 'advert/1593483085449397.png', 13, 0, 200, 30, 0, NULL, '2020-06-30 09:44:32', '2020-06-30 17:15:53');

-- ----------------------------
-- Table structure for prize_type
-- ----------------------------
DROP TABLE IF EXISTS `prize_type`;
CREATE TABLE `prize_type`  (
  `prize_type_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `prize_type_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '奖品类型名称',
  PRIMARY KEY (`prize_type_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '奖品类型表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of prize_type
-- ----------------------------
INSERT INTO `prize_type` VALUES (1, '积分乐园奖品');
INSERT INTO `prize_type` VALUES (2, '测试2');

-- ----------------------------
-- Table structure for sign_points
-- ----------------------------
DROP TABLE IF EXISTS `sign_points`;
CREATE TABLE `sign_points`  (
  `sign_points_id` int(3) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `sign_points_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '签到名称',
  `sign_points_integral` int(6) NOT NULL COMMENT '签到获得积分数',
  `sign_points_unselected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '签到不选中图',
  `sign_points_selected_img` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '签到选中图',
  `sign_points_sort` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`sign_points_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '签到积分表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sign_points
-- ----------------------------
INSERT INTO `sign_points` VALUES (1, '周一签到', 5, 'advert/1590042482923725.jpg', '', 1);
INSERT INTO `sign_points` VALUES (3, '周三签到', 15, 'advert/1590041455598207.png', 'advert/1590041463750483.png', 3);
INSERT INTO `sign_points` VALUES (4, '周二签到', 10, 'advert/1590042160350123.jpg', '', 2);

-- ----------------------------
-- Table structure for sys_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log`  (
  `sysl_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `sysl_name` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户账号',
  `sysl_text` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '日志内容',
  `sysl_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '日志ip',
  `sys_time` datetime NOT NULL COMMENT '日志时间',
  PRIMARY KEY (`sysl_id`) USING BTREE,
  INDEX `sysl_name_index`(`sysl_name`) USING BTREE COMMENT '日志用户账号索引'
) ENGINE = InnoDB AUTO_INCREMENT = 661 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统日志' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_log
-- ----------------------------
INSERT INTO `sys_log` VALUES (1, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=98&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=58&sysResource.res_icon=&res_id=58&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 16:55:49');
INSERT INTO `sys_log` VALUES (2, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=58&sysResource.res_note=&sysResource.res_id=59&sysResource.res_icon=&res_id=59&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=首页管理', '192.168.56.1', '2020-05-14 16:57:51');
INSERT INTO `sys_log` VALUES (3, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsHome/del&sysResource.res_pid=59&sysResource.res_note=&sysResource.res_id=62&sysResource.res_icon=pic_439&res_id=62&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-14 16:58:14');
INSERT INTO `sys_log` VALUES (4, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsHome/edit&sysResource.res_pid=59&sysResource.res_note=&sysResource.res_id=61&sysResource.res_icon=pic_439&res_id=61&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=修改', '192.168.56.1', '2020-05-14 16:58:24');
INSERT INTO `sys_log` VALUES (5, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsHome/add&sysResource.res_pid=59&sysResource.res_note=&sysResource.res_id=60&sysResource.res_icon=pic_439&res_id=60&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-14 16:58:31');
INSERT INTO `sys_log` VALUES (6, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=5&sysResource.res_url=/pointsHome/getList&sysResource.res_pid=59&sysResource.res_note=&sysResource.res_id=68&sysResource.res_icon=pic_381&res_id=68&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取广告类型列表', '192.168.56.1', '2020-05-14 16:59:01');
INSERT INTO `sys_log` VALUES (7, '管家33', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,21,43,80,76,46,45,44,20,70,24,23,22,58,59,68,62,61,60,63,66,65,64,47,48,49,50,28,25,53,52,51,26,75,74,73,72,69,27,67,56,55,54,29,30,33,71,32,31,34,35,39,38,37,36,57,42,41,40,1,2,5,4,3,6,12,11,10,9,8,7,13,81,16,15,14,78,79,17,18,77', '192.168.56.1', '2020-05-14 17:00:23');
INSERT INTO `sys_log` VALUES (8, '管家33', '[用户ID]:1,[控制器]:/sysUser,[方法]:edit,[参数]:sysu_id=1&sysUser.sysu_account=admin&sysUser.sysu_name=管家33&sysUser.sysu_password=&roleId=1&sysUser.sysu_id=1&sysUser.sysu_status=1', '192.168.56.1', '2020-05-14 17:01:15');
INSERT INTO `sys_log` VALUES (9, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=98&sysResource.res_url=/pointsHome/index&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=58&sysResource.res_icon=&res_id=58&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 17:03:52');
INSERT INTO `sys_log` VALUES (10, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=29', '192.168.56.1', '2020-05-14 17:05:18');
INSERT INTO `sys_log` VALUES (11, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=98&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=58&sysResource.res_icon=&res_id=58&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 17:05:48');
INSERT INTO `sys_log` VALUES (12, '管家33', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=63', '192.168.56.1', '2020-05-14 17:06:51');
INSERT INTO `sys_log` VALUES (13, '管家33', '[用户ID]:1,[控制器]:/sysUser,[方法]:edit,[参数]:sysu_id=1&sysUser.sysu_account=admin&sysUser.sysu_name=管家&sysUser.sysu_password=&roleId=1&sysUser.sysu_id=1&sysUser.sysu_status=1', '192.168.56.1', '2020-05-14 17:08:08');
INSERT INTO `sys_log` VALUES (14, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=30', '192.168.56.1', '2020-05-14 17:16:45');
INSERT INTO `sys_log` VALUES (15, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=33', '192.168.56.1', '2020-05-14 17:17:07');
INSERT INTO `sys_log` VALUES (16, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=66', '192.168.56.1', '2020-05-14 17:17:13');
INSERT INTO `sys_log` VALUES (17, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=64', '192.168.56.1', '2020-05-14 17:17:17');
INSERT INTO `sys_log` VALUES (18, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=31', '192.168.56.1', '2020-05-14 17:17:22');
INSERT INTO `sys_log` VALUES (19, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=65', '192.168.56.1', '2020-05-14 17:17:26');
INSERT INTO `sys_log` VALUES (20, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=32', '192.168.56.1', '2020-05-14 17:17:30');
INSERT INTO `sys_log` VALUES (21, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=71', '192.168.56.1', '2020-05-14 17:17:34');
INSERT INTO `sys_log` VALUES (22, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,21,43,80,76,46,45,44,20,70,24,23,22,47,48,49,50,28,25,53,52,51,26,75,74,73,72,69,27,67,56,55,54,34,35,39,38,37,36,57,42,41,40,1,2,5,4,3,6,12,11,10,9,8,7,13,81,16,15,14,78,79,17,18,77', '192.168.56.1', '2020-05-14 17:18:15');
INSERT INTO `sys_log` VALUES (23, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,21,43,80,76,46,45,44,20,70,24,23,22,58,59,68,62,61,60,47,48,49,50,28,25,53,52,51,26,75,74,73,72,69,27,67,56,55,54,34,35,39,38,37,36,57,42,41,40,1,2,5,4,3,6,12,11,10,9,8,7,13,81,16,15,14,78,79,17,18,77', '192.168.56.1', '2020-05-14 17:18:26');
INSERT INTO `sys_log` VALUES (24, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=68', '192.168.56.1', '2020-05-14 17:22:39');
INSERT INTO `sys_log` VALUES (25, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=62', '192.168.56.1', '2020-05-14 17:22:44');
INSERT INTO `sys_log` VALUES (26, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=60', '192.168.56.1', '2020-05-14 17:22:49');
INSERT INTO `sys_log` VALUES (27, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=61', '192.168.56.1', '2020-05-14 17:22:54');
INSERT INTO `sys_log` VALUES (28, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=59', '192.168.56.1', '2020-05-14 17:23:12');
INSERT INTO `sys_log` VALUES (29, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=58', '192.168.56.1', '2020-05-14 17:23:16');
INSERT INTO `sys_log` VALUES (30, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 17:37:56');
INSERT INTO `sys_log` VALUES (31, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=51', '192.168.56.1', '2020-05-14 17:38:06');
INSERT INTO `sys_log` VALUES (32, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=82&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=首页', '192.168.56.1', '2020-05-14 17:39:20');
INSERT INTO `sys_log` VALUES (33, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,21,43,80,76,46,45,44,20,70,24,23,22,47,48,49,50,28,25,53,52,26,75,74,73,72,69,27,67,56,55,54,34,35,39,38,37,36,57,42,41,40,82,83,1,2,5,4,3,6,12,11,10,9,8,7,13,81,16,15,14,78,79,17,18,77', '192.168.56.1', '2020-05-14 17:40:01');
INSERT INTO `sys_log` VALUES (34, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=20&sysResource.res_note=&sysResource.res_id=21&sysResource.res_icon=&res_id=21&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=首页', '192.168.56.1', '2020-05-14 17:52:41');
INSERT INTO `sys_log` VALUES (35, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=21&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取数据', '192.168.56.1', '2020-05-14 17:53:58');
INSERT INTO `sys_log` VALUES (36, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,22,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,17,18', '192.168.56.1', '2020-05-14 17:56:22');
INSERT INTO `sys_log` VALUES (37, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=20&sysResource.res_icon=&res_id=20&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 18:02:05');
INSERT INTO `sys_log` VALUES (38, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=20&sysResource.res_icon=&res_id=20&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-05-14 18:02:34');
INSERT INTO `sys_log` VALUES (39, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/index&sysResource.res_pid=20&sysResource.res_note=&sysResource.res_id=21&sysResource.res_icon=&res_id=21&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=首页管理', '192.168.56.1', '2020-05-14 18:02:50');
INSERT INTO `sys_log` VALUES (40, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/add&sysResource.res_pid=21&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-15 10:56:25');
INSERT INTO `sys_log` VALUES (41, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsHome/edit&sysResource.res_pid=21&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-15 10:56:44');
INSERT INTO `sys_log` VALUES (42, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsHome/index&sysResource.res_pid=21&sysResource.res_note=&sysResource.res_id=22&sysResource.res_icon=pic_381&res_id=22&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取数据', '192.168.56.1', '2020-05-15 10:56:53');
INSERT INTO `sys_log` VALUES (43, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,22,24,23,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,17,18', '192.168.56.1', '2020-05-15 10:57:15');
INSERT INTO `sys_log` VALUES (44, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsHome/del&sysResource.res_pid=21&sysResource.res_note=删除&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-15 10:57:41');
INSERT INTO `sys_log` VALUES (45, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsHome/del&sysResource.res_pid=21&sysResource.res_note=资源删除&sysResource.res_id=25&sysResource.res_icon=pic_439&res_id=25&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-15 10:57:53');
INSERT INTO `sys_log` VALUES (46, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsHome/index&sysResource.res_pid=21&sysResource.res_note=获取数据&sysResource.res_id=22&sysResource.res_icon=pic_381&res_id=22&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取数据', '192.168.56.1', '2020-05-15 10:58:08');
INSERT INTO `sys_log` VALUES (47, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsHome/edit&sysResource.res_pid=21&sysResource.res_note=资源编辑&sysResource.res_id=24&sysResource.res_icon=pic_439&res_id=24&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-15 10:58:17');
INSERT INTO `sys_log` VALUES (48, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsHome/add&sysResource.res_pid=21&sysResource.res_note=新增资源&sysResource.res_id=23&sysResource.res_icon=pic_439&res_id=23&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-15 10:58:23');
INSERT INTO `sys_log` VALUES (49, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,17,18', '192.168.56.1', '2020-05-15 10:58:39');
INSERT INTO `sys_log` VALUES (50, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=测试&pointsHome.points_home_sort=1&pointsHome.points_home_online=0', '192.168.56.1', '2020-05-15 16:02:19');
INSERT INTO `sys_log` VALUES (51, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=123123&pointsHome.points_home_sort=1&pointsHome.points_home_online=2', '192.168.56.1', '2020-05-15 16:05:28');
INSERT INTO `sys_log` VALUES (52, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=12312&pointsHome.points_home_sort=123&pointsHome.points_home_online=0', '192.168.56.1', '2020-05-15 16:06:14');
INSERT INTO `sys_log` VALUES (53, '管家', '[用户ID]:1,[控制器]:/sysSetting,[方法]:edit,[参数]:sysSetting.set_title=积分系统后台管理系统&initRSA=0&sysSetting.set_tm_upload=E:/application/nginx-1.17.5/html/points_system/&set_id=1&sysSetting.set_publickey=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB&sysSetting.set_url=http://192.168.0.182:8082/points_system/&sysSetting.set_upload=E:/application/nginx-1.17.5/html/points_system/&sysSetting.set_id=1', '192.168.56.1', '2020-05-15 16:14:37');
INSERT INTO `sys_log` VALUES (54, '管家', '[用户ID]:1,[控制器]:/sysSetting,[方法]:edit,[参数]:sysSetting.set_title=积分系统后台管理系统&initRSA=0&sysSetting.set_tm_upload=E:/application/nginx-1.17.5/html/points_system/&set_id=1&sysSetting.set_publickey=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB&sysSetting.set_url=http://192.168.0.182:8082/points_system/&sysSetting.set_upload=E:/application/nginx-1.17.5/html/points_system/&sysSetting.set_id=1', '192.168.56.1', '2020-05-15 16:14:42');
INSERT INTO `sys_log` VALUES (55, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=00&pointsHome.points_home_sort=000&pointsHome.points_home_online=0', '192.168.56.1', '2020-05-15 16:14:59');
INSERT INTO `sys_log` VALUES (56, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=123&pointsHome.points_home_sort=1&pointsHome.points_home_online=1', '192.168.56.1', '2020-05-15 16:17:00');
INSERT INTO `sys_log` VALUES (57, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=12312&pointsHome.points_home_sort=123&pointsHome.points_home_online=1', '192.168.56.1', '2020-05-15 16:21:37');
INSERT INTO `sys_log` VALUES (58, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=12312&pointsHome.points_home_sort=0&pointsHome.points_home_online=1', '192.168.56.1', '2020-05-15 16:22:11');
INSERT INTO `sys_log` VALUES (59, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=哈哈&pointsHome.points_home_sort=1&pointsHome.points_home_online=1', '192.168.56.1', '2020-05-15 16:22:36');
INSERT INTO `sys_log` VALUES (60, '管家', '[用户ID]:1,[控制器]:/sysSetting,[方法]:edit,[参数]:sysSetting.set_title=积分系统后台管理系统&initRSA=0&sysSetting.set_tm_upload=E:/application/nginx-1.17.5/html/points_system/&set_id=1&sysSetting.set_publickey=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB&sysSetting.set_url=http://192.168.0.72:8082/points_system/&sysSetting.set_upload=E:/application/nginx-1.17.5/html/points_system/&sysSetting.set_id=1', '192.168.56.1', '2020-05-15 17:50:03');
INSERT INTO `sys_log` VALUES (61, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=3', '192.168.56.1', '2020-05-18 09:21:48');
INSERT INTO `sys_log` VALUES (62, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=3', '192.168.56.1', '2020-05-18 09:22:29');
INSERT INTO `sys_log` VALUES (63, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=3', '192.168.56.1', '2020-05-18 09:22:54');
INSERT INTO `sys_log` VALUES (64, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试1&pointsHome.points_home_sort=1&pointsHome.points_home_online=0&points_home_id=3', '192.168.56.1', '2020-05-18 09:27:40');
INSERT INTO `sys_log` VALUES (65, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试1&pointsHome.points_home_sort=1&pointsHome.points_home_online=0&points_home_id=3', '192.168.56.1', '2020-05-18 09:28:02');
INSERT INTO `sys_log` VALUES (66, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=编辑测试1&pointsHome.points_home_sort=9&pointsHome.points_home_online=1&points_home_id=3', '192.168.56.1', '2020-05-18 09:28:25');
INSERT INTO `sys_log` VALUES (67, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=1&pointsHome.points_home_name=1231322&pointsHome.points_home_sort=&pointsHome.points_home_online=0&points_home_id=1', '192.168.56.1', '2020-05-18 09:30:19');
INSERT INTO `sys_log` VALUES (68, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=1&pointsHome.points_home_name=1231322&pointsHome.points_home_sort=&pointsHome.points_home_online=0&points_home_id=1', '192.168.56.1', '2020-05-18 09:30:21');
INSERT INTO `sys_log` VALUES (69, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=1&pointsHome.points_home_name=1231322&pointsHome.points_home_sort=123123&pointsHome.points_home_online=0&points_home_id=1', '192.168.56.1', '2020-05-18 09:30:25');
INSERT INTO `sys_log` VALUES (70, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:del,[参数]:id=7', '192.168.56.1', '2020-05-18 10:04:27');
INSERT INTO `sys_log` VALUES (71, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:del,[参数]:id=8', '192.168.56.1', '2020-05-18 10:04:32');
INSERT INTO `sys_log` VALUES (72, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=6&pointsHome.points_home_name=12312&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=6', '192.168.56.1', '2020-05-18 10:04:47');
INSERT INTO `sys_log` VALUES (73, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:del,[参数]:id=6', '192.168.56.1', '2020-05-18 10:04:59');
INSERT INTO `sys_log` VALUES (74, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=哈哈&pointsHome.points_home_sort=2&pointsHome.points_home_online=1', '192.168.56.1', '2020-05-18 10:08:17');
INSERT INTO `sys_log` VALUES (75, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=2&pointsHome.points_home_name=123123&pointsHome.points_home_sort=1&pointsHome.points_home_online=2&points_home_id=2', '192.168.56.1', '2020-05-18 10:34:42');
INSERT INTO `sys_log` VALUES (76, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员管理', '192.168.56.1', '2020-05-18 10:55:54');
INSERT INTO `sys_log` VALUES (77, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/memeberType&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员类型管理', '192.168.56.1', '2020-05-18 10:57:30');
INSERT INTO `sys_log` VALUES (78, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memeberType/index&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_id=31&sysResource.res_icon=&res_id=31&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员类型管理', '192.168.56.1', '2020-05-18 10:57:44');
INSERT INTO `sys_log` VALUES (79, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/index&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_id=31&sysResource.res_icon=&res_id=31&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员类型管理', '192.168.56.1', '2020-05-18 10:58:15');
INSERT INTO `sys_log` VALUES (80, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-18 11:04:13');
INSERT INTO `sys_log` VALUES (81, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/add&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=资源添加', '192.168.56.1', '2020-05-18 11:07:14');
INSERT INTO `sys_log` VALUES (82, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/memberType/edit&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源编辑', '192.168.56.1', '2020-05-18 11:07:44');
INSERT INTO `sys_log` VALUES (83, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/add&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_id=32&sysResource.res_icon=pic_439&res_id=32&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源添加', '192.168.56.1', '2020-05-18 11:07:53');
INSERT INTO `sys_log` VALUES (84, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/memberType/del&sysResource.res_pid=31&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-18 11:08:13');
INSERT INTO `sys_log` VALUES (85, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/memberType/edit&sysResource.res_pid=31&sysResource.res_note=&sysResource.res_id=33&sysResource.res_icon=pic_439&res_id=33&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源编辑', '192.168.56.1', '2020-05-18 11:08:21');
INSERT INTO `sys_log` VALUES (86, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/add&sysResource.res_pid=31&sysResource.res_note=&sysResource.res_id=32&sysResource.res_icon=pic_439&res_id=32&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源添加', '192.168.56.1', '2020-05-18 11:08:29');
INSERT INTO `sys_log` VALUES (87, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-18 11:08:39');
INSERT INTO `sys_log` VALUES (88, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:16:39');
INSERT INTO `sys_log` VALUES (89, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:16:41');
INSERT INTO `sys_log` VALUES (90, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:17:35');
INSERT INTO `sys_log` VALUES (91, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:17:39');
INSERT INTO `sys_log` VALUES (92, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:19:10');
INSERT INTO `sys_log` VALUES (93, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-18 11:22:46');
INSERT INTO `sys_log` VALUES (94, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=0&memberType.member_type_online=1&memberType.member_type_name=非会员', '192.168.56.1', '2020-05-18 11:24:42');
INSERT INTO `sys_log` VALUES (95, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=100&memberType.member_type_online=0&memberType.member_type_name=普通会员', '192.168.56.1', '2020-05-18 11:28:20');
INSERT INTO `sys_log` VALUES (96, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=200&memberType.member_type_online=1&memberType.member_type_name=白银会员', '192.168.56.1', '2020-05-18 11:28:36');
INSERT INTO `sys_log` VALUES (97, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=300&memberType.member_type_online=2&memberType.member_type_name=黄金会员', '192.168.56.1', '2020-05-18 11:28:49');
INSERT INTO `sys_log` VALUES (98, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=100&memberType.member_type_online=1&memberType.member_type_name=普通会员&memberType.member_type_id=2', '192.168.56.1', '2020-05-18 11:36:11');
INSERT INTO `sys_log` VALUES (99, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=1&memberType.member_type_integral=0&memberType.member_type_online=0&memberType.member_type_name=非会员&memberType.member_type_id=1', '192.168.56.1', '2020-05-18 11:36:17');
INSERT INTO `sys_log` VALUES (100, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=150&memberType.member_type_online=1&memberType.member_type_name=普通会员&memberType.member_type_id=2', '192.168.56.1', '2020-05-18 11:36:23');
INSERT INTO `sys_log` VALUES (101, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=150&memberType.member_type_online=1&memberType.member_type_name=普通会员2&memberType.member_type_id=2', '192.168.56.1', '2020-05-18 11:36:27');
INSERT INTO `sys_log` VALUES (102, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:del,[参数]:id=1', '192.168.56.1', '2020-05-18 11:39:25');
INSERT INTO `sys_log` VALUES (103, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=-100&memberType.member_type_online=1&memberType.member_type_name=非会员', '192.168.56.1', '2020-05-18 11:39:59');
INSERT INTO `sys_log` VALUES (104, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=150&memberType.member_type_online=1&memberType.member_type_name=普通会员&memberType.member_type_id=2', '192.168.56.1', '2020-05-18 11:46:11');
INSERT INTO `sys_log` VALUES (105, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:add,[参数]:memberType.member_type_integral=10000&memberType.member_type_online=1&memberType.member_type_name=超级会员', '192.168.56.1', '2020-05-18 11:46:29');
INSERT INTO `sys_log` VALUES (106, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberArea/index&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员专区管理', '192.168.56.1', '2020-05-18 15:03:12');
INSERT INTO `sys_log` VALUES (107, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberArea/index&sysResource.res_pid=30&sysResource.res_note=&sysResource.res_id=35&sysResource.res_icon=&res_id=35&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员专享福利特权专区', '192.168.56.1', '2020-05-18 15:03:43');
INSERT INTO `sys_log` VALUES (108, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberArea/add&sysResource.res_pid=35&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-18 15:04:21');
INSERT INTO `sys_log` VALUES (109, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/memberArea/edit&sysResource.res_pid=35&sysResource.res_note=资源编辑&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-18 15:04:46');
INSERT INTO `sys_log` VALUES (110, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/memberArea/del&sysResource.res_pid=35&sysResource.res_note=删除资源&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-18 15:05:04');
INSERT INTO `sys_log` VALUES (111, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberArea/add&sysResource.res_pid=35&sysResource.res_note=添加数据&sysResource.res_id=36&sysResource.res_icon=pic_439&res_id=36&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-18 15:05:14');
INSERT INTO `sys_log` VALUES (112, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberArea/index&sysResource.res_pid=30&sysResource.res_note=专区&sysResource.res_id=35&sysResource.res_icon=&res_id=35&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员专享福利特权专区', '192.168.56.1', '2020-05-18 15:05:23');
INSERT INTO `sys_log` VALUES (113, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/add&sysResource.res_pid=31&sysResource.res_note=资源添加&sysResource.res_id=32&sysResource.res_icon=pic_439&res_id=32&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源添加', '192.168.56.1', '2020-05-18 15:05:33');
INSERT INTO `sys_log` VALUES (114, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/memberType/edit&sysResource.res_pid=31&sysResource.res_note=资源编辑&sysResource.res_id=33&sysResource.res_icon=pic_439&res_id=33&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=资源编辑', '192.168.56.1', '2020-05-18 15:05:38');
INSERT INTO `sys_log` VALUES (115, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/memberType/del&sysResource.res_pid=31&sysResource.res_note=资源删除&sysResource.res_id=34&sysResource.res_icon=pic_439&res_id=34&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-18 15:05:46');
INSERT INTO `sys_log` VALUES (116, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/memberType/edit&sysResource.res_pid=31&sysResource.res_note=资源编辑&sysResource.res_id=33&sysResource.res_icon=pic_439&res_id=33&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-18 15:05:51');
INSERT INTO `sys_log` VALUES (117, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/memberType/add&sysResource.res_pid=31&sysResource.res_note=资源添加&sysResource.res_id=32&sysResource.res_icon=pic_439&res_id=32&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-05-18 15:05:55');
INSERT INTO `sys_log` VALUES (118, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-18 15:06:20');
INSERT INTO `sys_log` VALUES (119, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试&memberArea.member_area_sort=&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:48:02');
INSERT INTO `sys_log` VALUES (120, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试&memberArea.member_area_sort=&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:48:04');
INSERT INTO `sys_log` VALUES (121, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试&memberArea.member_area_sort=&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:48:06');
INSERT INTO `sys_log` VALUES (122, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试&memberArea.member_area_sort=&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:48:12');
INSERT INTO `sys_log` VALUES (123, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=123123&memberArea.member_area_sort=1&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:49:01');
INSERT INTO `sys_log` VALUES (124, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=123123&memberArea.member_area_sort=1&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 15:50:24');
INSERT INTO `sys_log` VALUES (125, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=1&memberArea.member_area_name=123123&memberArea.member_area_sort=2&memberArea.member_area_url=&member_area_id=1&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:04:31');
INSERT INTO `sys_log` VALUES (126, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=1&memberArea.member_area_name=123123&memberArea.member_area_sort=1&memberArea.member_area_url=&member_area_id=1&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:12:16');
INSERT INTO `sys_log` VALUES (127, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=1&memberArea.member_area_name=123123&memberArea.member_area_sort=5&memberArea.member_area_url=&member_area_id=1&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:12:23');
INSERT INTO `sys_log` VALUES (128, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=1&memberArea.member_area_name=123123&memberArea.member_area_sort=5&memberArea.member_area_url=&member_area_id=1&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:12:35');
INSERT INTO `sys_log` VALUES (129, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=1&memberArea.member_area_name=123123&memberArea.member_area_sort=5&memberArea.member_area_url=&member_area_id=1&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:13:07');
INSERT INTO `sys_log` VALUES (130, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=12230&memberArea.member_area_sort=1&memberArea.member_area_url=gfxcyfuh&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-18 16:13:43');
INSERT INTO `sys_log` VALUES (131, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=2&memberArea.member_area_name=cc&memberArea.member_area_sort=1&memberArea.member_area_url=http://www.baiducom&member_area_id=2&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-18 16:14:14');
INSERT INTO `sys_log` VALUES (132, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试2&memberArea.member_area_sort=1&memberArea.member_area_url=&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 09:50:39');
INSERT INTO `sys_log` VALUES (133, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=测试3&memberArea.member_area_sort=1&memberArea.member_area_url=&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 09:56:14');
INSERT INTO `sys_log` VALUES (134, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=4&memberArea.member_area_name=测试3&memberArea.member_area_sort=2&memberArea.member_area_url=&member_area_id=4&memberArea.member_area_online=0&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 09:58:33');
INSERT INTO `sys_log` VALUES (135, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=4&memberArea.member_area_name=测试3&memberArea.member_area_sort=2&memberArea.member_area_url=&member_area_id=4&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 09:58:40');
INSERT INTO `sys_log` VALUES (136, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=4&memberArea.member_area_name=测试3&memberArea.member_area_sort=2&memberArea.member_area_url=&member_area_id=4&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 09:58:52');
INSERT INTO `sys_log` VALUES (137, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=3&memberArea.member_area_name=测试2&memberArea.member_area_sort=1&memberArea.member_area_url=&member_area_id=3&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 10:11:47');
INSERT INTO `sys_log` VALUES (138, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=3&memberArea.member_area_name=测试2&memberArea.member_area_sort=1&memberArea.member_area_url=&member_area_id=3&memberArea.member_area_online=1&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 10:12:01');
INSERT INTO `sys_log` VALUES (139, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=5&pointsHome.points_home_name=123&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=5', '192.168.56.1', '2020-05-19 10:17:49');
INSERT INTO `sys_log` VALUES (140, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=组合测试&memberArea.member_area_sort=1&memberArea.member_area_url=md.jd.com&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:44:20');
INSERT INTO `sys_log` VALUES (141, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=哈哈&memberArea.member_area_sort=2&memberArea.member_area_url=12312312312312&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:45:08');
INSERT INTO `sys_log` VALUES (142, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=6&memberArea.member_area_name=哈哈&memberArea.member_area_sort=2&memberArea.member_area_url=12312312312312&member_area_id=6&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:45:33');
INSERT INTO `sys_log` VALUES (143, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=6&memberArea.member_area_name=哈哈&memberArea.member_area_sort=2&memberArea.member_area_url=12312312312312&member_area_id=6&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:45:44');
INSERT INTO `sys_log` VALUES (144, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:del,[参数]:id=6', '192.168.56.1', '2020-05-19 10:45:50');
INSERT INTO `sys_log` VALUES (145, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=1123123&memberArea.member_area_sort=-1&memberArea.member_area_url=&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:51:00');
INSERT INTO `sys_log` VALUES (146, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=123123&memberArea.member_area_sort=1&memberArea.member_area_url=&memberArea.member_area_online=1&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:51:47');
INSERT INTO `sys_log` VALUES (147, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:add,[参数]:memberArea.member_area_name=asfda&memberArea.member_area_sort=2&memberArea.member_area_url=123123123&memberArea.member_area_online=2&memberArea.member_area_isparam=0', '192.168.56.1', '2020-05-19 10:52:19');
INSERT INTO `sys_log` VALUES (148, '管家', '[用户ID]:1,[控制器]:/memberArea,[方法]:edit,[参数]:memberArea.member_area_id=9&memberArea.member_area_name=asfda&memberArea.member_area_sort=2&memberArea.member_area_url=123123123&member_area_id=9&memberArea.member_area_online=0&memberArea.member_area_isparam=1', '192.168.56.1', '2020-05-19 10:53:55');
INSERT INTO `sys_log` VALUES (149, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=PK管理', '192.168.56.1', '2020-05-19 14:58:03');
INSERT INTO `sys_log` VALUES (150, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/playerKilling/index&sysResource.res_pid=39&sysResource.res_note=PK结果表&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=PK管理', '192.168.56.1', '2020-05-19 14:58:42');
INSERT INTO `sys_log` VALUES (151, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/playerKilling/add&sysResource.res_pid=40&sysResource.res_note=添加资源&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-19 14:59:25');
INSERT INTO `sys_log` VALUES (152, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKilling/edit&sysResource.res_pid=40&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-19 14:59:41');
INSERT INTO `sys_log` VALUES (153, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/playerKilling/del&sysResource.res_pid=40&sysResource.res_note=资源删除&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-19 15:00:00');
INSERT INTO `sys_log` VALUES (154, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKilling/edit&sysResource.res_pid=40&sysResource.res_note=编辑资源&sysResource.res_id=42&sysResource.res_icon=pic_439&res_id=42&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-19 15:00:08');
INSERT INTO `sys_log` VALUES (155, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,39,40,43,42,41,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-19 15:01:00');
INSERT INTO `sys_log` VALUES (156, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:add,[参数]:playerKilling.player_killing_end_time=2020-05-20 23:59:59&playerKilling.player_killing_votes=0&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=1&playerKilling.player_killing_name=测试1&playerKilling.player_killing_url=&playerKilling.player_killing_sort=1', '192.168.56.1', '2020-05-19 16:08:56');
INSERT INTO `sys_log` VALUES (157, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:add,[参数]:playerKilling.player_killing_end_time=2020-05-28 23:59:59&playerKilling.player_killing_votes=0&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=1', '192.168.56.1', '2020-05-19 16:12:25');
INSERT INTO `sys_log` VALUES (158, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:add,[参数]:playerKilling.player_killing_end_time=2020-05-19 23:59:59&playerKilling.player_killing_votes=100&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=1&playerKilling.player_killing_name=123123&playerKilling.player_killing_url=&playerKilling.player_killing_sort=3', '192.168.56.1', '2020-05-19 16:27:54');
INSERT INTO `sys_log` VALUES (159, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=3&playerKilling.player_killing_votes=100&player_killing_id=3&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=1&playerKilling.player_killing_name=123123&playerKilling.player_killing_url=&playerKilling.player_killing_sort=3', '192.168.56.1', '2020-05-19 16:28:00');
INSERT INTO `sys_log` VALUES (160, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=20&player_killing_id=2&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-19 16:28:08');
INSERT INTO `sys_log` VALUES (161, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=20&player_killing_id=2&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-19 16:28:52');
INSERT INTO `sys_log` VALUES (162, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=1&playerKilling.player_killing_votes=0&player_killing_id=1&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=1&playerKilling.player_killing_name=测试1&playerKilling.player_killing_url=&playerKilling.player_killing_sort=1', '192.168.56.1', '2020-05-19 16:29:12');
INSERT INTO `sys_log` VALUES (163, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=1&playerKilling.player_killing_votes=0&player_killing_id=1&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=1&playerKilling.player_killing_name=测试1&playerKilling.player_killing_url=&playerKilling.player_killing_sort=1', '192.168.56.1', '2020-05-19 16:29:23');
INSERT INTO `sys_log` VALUES (164, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=20&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-19 16:30:13');
INSERT INTO `sys_log` VALUES (165, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=20&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-19 16:30:37');
INSERT INTO `sys_log` VALUES (166, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=3&playerKilling.player_killing_votes=100&player_killing_id=3&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=1&playerKilling.player_killing_name=123123&playerKilling.player_killing_url=&playerKilling.player_killing_sort=815', '192.168.56.1', '2020-05-19 16:32:44');
INSERT INTO `sys_log` VALUES (167, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=1&playerKilling.player_killing_votes=0&player_killing_id=1&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=1&playerKilling.player_killing_name=测试1&playerKilling.player_killing_url=http://127.0.0.1:8080/mycms/playerKilling/edit?player_killing_id=3&playerKilling.player_killing_sort=1', '192.168.56.1', '2020-05-19 16:33:55');
INSERT INTO `sys_log` VALUES (168, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-05-19 16:34:29');
INSERT INTO `sys_log` VALUES (169, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-05-19 16:34:42');
INSERT INTO `sys_log` VALUES (170, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=1&playerKilling.player_killing_votes=0&player_killing_id=1&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_online=1&playerKilling.player_killing_name=测试1&playerKilling.player_killing_url=http://127.0.0.1:8080/mycms/playerKilling/edit?player_killing_id=3&playerKilling.player_killing_sort=15916261', '192.168.56.1', '2020-05-20 11:14:08');
INSERT INTO `sys_log` VALUES (171, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=99&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-20 11:21:32');
INSERT INTO `sys_log` VALUES (172, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=9&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-20 11:23:41');
INSERT INTO `sys_log` VALUES (173, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=9333333&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-20 11:23:51');
INSERT INTO `sys_log` VALUES (174, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=933333333&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-20 11:23:58');
INSERT INTO `sys_log` VALUES (175, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_id=2&playerKilling.player_killing_votes=999999999&player_killing_id=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_online=2&playerKilling.player_killing_name=奥德福建傲的福建傲的叫法偶觉得佛安静的佛教偶奇偶奇偶及&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_sort=12', '192.168.56.1', '2020-05-20 11:24:44');
INSERT INTO `sys_log` VALUES (176, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=6&memberType.member_type_integral=120&memberType.member_type_online=1&memberType.member_type_name=超级会员&memberType.member_type_id=6', '192.168.56.1', '2020-05-20 11:29:54');
INSERT INTO `sys_log` VALUES (177, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=123123&pointsHome.points_home_sort=&pointsHome.points_home_online=0', '192.168.56.1', '2020-05-20 11:32:08');
INSERT INTO `sys_log` VALUES (178, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=5&pointsHome.points_home_name=123&pointsHome.points_home_sort=12&pointsHome.points_home_online=1&points_home_id=5', '192.168.56.1', '2020-05-20 11:32:20');
INSERT INTO `sys_log` VALUES (179, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKillingUser/&sysResource.res_pid=39&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=用户PK投票管理', '192.168.56.1', '2020-05-20 14:11:15');
INSERT INTO `sys_log` VALUES (180, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/playerKillingUser/del&sysResource.res_pid=44&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-20 14:11:38');
INSERT INTO `sys_log` VALUES (181, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKillingUser/edit&sysResource.res_pid=44&sysResource.res_note=编辑资源&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-20 14:12:14');
INSERT INTO `sys_log` VALUES (182, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/playerKillingUser/del&sysResource.res_pid=44&sysResource.res_note=删除资源&sysResource.res_id=45&sysResource.res_icon=pic_439&res_id=45&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-20 14:12:21');
INSERT INTO `sys_log` VALUES (183, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/playerKillingUser/add&sysResource.res_pid=44&sysResource.res_note=资源添加&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-05-20 14:12:54');
INSERT INTO `sys_log` VALUES (184, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKillingUser/index&sysResource.res_pid=39&sysResource.res_note=&sysResource.res_id=44&sysResource.res_icon=&res_id=44&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=用户PK投票管理', '192.168.56.1', '2020-05-20 14:13:19');
INSERT INTO `sys_log` VALUES (185, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,39,44,47,46,45,40,43,42,41,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-20 14:49:24');
INSERT INTO `sys_log` VALUES (186, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=4&sysResource.res_url=/playerKilling/getPlayerKillingList&sysResource.res_pid=44&sysResource.res_note=获取PK类型&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取PK类型', '192.168.56.1', '2020-05-20 15:14:19');
INSERT INTO `sys_log` VALUES (187, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,39,44,48,47,46,45,40,43,42,41,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-20 15:14:48');
INSERT INTO `sys_log` VALUES (188, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-20 15:21:16');
INSERT INTO `sys_log` VALUES (189, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-20 15:21:19');
INSERT INTO `sys_log` VALUES (190, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-20 15:21:20');
INSERT INTO `sys_log` VALUES (191, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:null', '192.168.56.1', '2020-05-20 15:21:22');
INSERT INTO `sys_log` VALUES (192, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:playerKillingUser.player_killing_id=1&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 15:23:16');
INSERT INTO `sys_log` VALUES (193, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=2&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 15:55:36');
INSERT INTO `sys_log` VALUES (194, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 15:55:41');
INSERT INTO `sys_log` VALUES (195, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=testerwer', '192.168.56.1', '2020-05-20 15:56:34');
INSERT INTO `sys_log` VALUES (196, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=testerwer', '192.168.56.1', '2020-05-20 15:56:37');
INSERT INTO `sys_log` VALUES (197, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=testerwer', '192.168.56.1', '2020-05-20 15:56:42');
INSERT INTO `sys_log` VALUES (198, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=testerwer', '192.168.56.1', '2020-05-20 15:58:33');
INSERT INTO `sys_log` VALUES (199, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 16:01:15');
INSERT INTO `sys_log` VALUES (200, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 16:01:21');
INSERT INTO `sys_log` VALUES (201, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=test123123', '192.168.56.1', '2020-05-20 16:04:46');
INSERT INTO `sys_log` VALUES (202, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=2&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 16:06:09');
INSERT INTO `sys_log` VALUES (203, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=1&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 16:07:27');
INSERT INTO `sys_log` VALUES (204, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:player_killing_account=test&playerKillingUser.player_killing_id=3&playerKillingUser.player_killing_account=test', '192.168.56.1', '2020-05-20 16:07:32');
INSERT INTO `sys_log` VALUES (205, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=1500&memberType.member_type_online=1&memberType.member_type_name=普通会员&memberType.member_type_id=2', '192.168.56.1', '2020-05-21 10:19:02');
INSERT INTO `sys_log` VALUES (206, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=2&memberType.member_type_integral=0&memberType.member_type_online=1&memberType.member_type_name=普通会员&memberType.member_type_id=2', '192.168.56.1', '2020-05-21 10:19:09');
INSERT INTO `sys_log` VALUES (207, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_end_time=2020-05-19 23:59:59&playerKilling.player_killing_sort=815&playerKilling.player_killing_votes=100&player_killing_id=3&playerKilling.player_killing_url=&playerKilling.player_killing_online=1&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_name=休闲游戏&playerKilling.player_killing_id=3', '192.168.56.1', '2020-05-21 10:19:27');
INSERT INTO `sys_log` VALUES (208, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_end_time=2020-05-28 23:59:59&playerKilling.player_killing_sort=12&playerKilling.player_killing_votes=999999999&player_killing_id=2&playerKilling.player_killing_url=www.baidu.com&playerKilling.player_killing_online=2&playerKilling.palyer_killing_isparam=0&playerKilling.player_killing_name=动作游戏&playerKilling.player_killing_id=2', '192.168.56.1', '2020-05-21 10:19:38');
INSERT INTO `sys_log` VALUES (209, '管家', '[用户ID]:1,[控制器]:/playerKilling,[方法]:edit,[参数]:playerKilling.player_killing_end_time=2020-05-20 23:59:59&playerKilling.player_killing_sort=15916261&playerKilling.player_killing_votes=0&player_killing_id=1&playerKilling.player_killing_url=http://127.0.0.1:8080/mycms/playerKilling/edit?player_killing_id=3&playerKilling.player_killing_online=1&playerKilling.palyer_killing_isparam=1&playerKilling.player_killing_name=棋牌游戏&playerKilling.player_killing_id=1', '192.168.56.1', '2020-05-21 10:19:48');
INSERT INTO `sys_log` VALUES (210, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:playerKillingUser.player_killing_user_id=1&playerKillingUser.player_killing_user_account=test&player_killing_user_id=1&playerKillingUser.player_killing_user_type_id=2', '192.168.56.1', '2020-05-21 10:20:41');
INSERT INTO `sys_log` VALUES (211, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:playerKillingUser.player_killing_user_account=123Test&playerKillingUser.player_killing_user_type_id=2', '192.168.56.1', '2020-05-21 10:21:02');
INSERT INTO `sys_log` VALUES (212, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:playerKillingUser.player_killing_user_id=2&playerKillingUser.player_killing_user_account=123Test&player_killing_user_id=2&playerKillingUser.player_killing_user_type_id=1', '192.168.56.1', '2020-05-21 10:21:07');
INSERT INTO `sys_log` VALUES (213, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:add,[参数]:playerKillingUser.player_killing_user_account=123Test&playerKillingUser.player_killing_user_type_id=1', '192.168.56.1', '2020-05-21 10:21:16');
INSERT INTO `sys_log` VALUES (214, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:del,[参数]:id=3', '192.168.56.1', '2020-05-21 10:22:40');
INSERT INTO `sys_log` VALUES (215, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/playerKillingUser/index&sysResource.res_pid=39&sysResource.res_note=&sysResource.res_id=44&sysResource.res_icon=&res_id=44&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=PK投票用户管理', '192.168.56.1', '2020-05-21 10:25:35');
INSERT INTO `sys_log` VALUES (216, '管家', '[用户ID]:1,[控制器]:/playerKillingUser,[方法]:edit,[参数]:playerKillingUser.player_killing_user_id=2&playerKillingUser.player_killing_user_account=123Test&player_killing_user_id=2&playerKillingUser.player_killing_user_type_id=1', '192.168.56.1', '2020-05-21 10:34:00');
INSERT INTO `sys_log` VALUES (217, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=签到栏目&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=签到管理', '192.168.56.1', '2020-05-21 13:52:39');
INSERT INTO `sys_log` VALUES (218, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/signPoints/index&sysResource.res_pid=49&sysResource.res_note=签到积分&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=/签到积分管理', '192.168.56.1', '2020-05-21 13:53:23');
INSERT INTO `sys_log` VALUES (219, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/signPoints/index&sysResource.res_pid=49&sysResource.res_note=签到积分&sysResource.res_id=50&sysResource.res_icon=&res_id=50&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=签到积分管理', '192.168.56.1', '2020-05-21 13:53:32');
INSERT INTO `sys_log` VALUES (220, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/signPoints/add&sysResource.res_pid=50&sysResource.res_note=新增&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-21 13:59:23');
INSERT INTO `sys_log` VALUES (221, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/signPoints/edit&sysResource.res_pid=50&sysResource.res_note=资源修改&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-21 14:01:37');
INSERT INTO `sys_log` VALUES (222, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/signPoints/del&sysResource.res_pid=50&sysResource.res_note=删除资源&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-21 14:01:57');
INSERT INTO `sys_log` VALUES (223, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,39,44,48,47,46,45,40,43,42,41,49,50,53,52,51,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-21 14:02:10');
INSERT INTO `sys_log` VALUES (224, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:add,[参数]:signPoints.sign_points_name=周一签到&signPoints.sign_points_sort=1&signPoints.sign_points_integral=0', '192.168.56.1', '2020-05-21 14:05:28');
INSERT INTO `sys_log` VALUES (225, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:add,[参数]:signPoints.sign_points_name=周二签到&signPoints.sign_points_sort=2&signPoints.sign_points_integral=5', '192.168.56.1', '2020-05-21 14:06:13');
INSERT INTO `sys_log` VALUES (226, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=2&signPoints.sign_points_name=周二签到&signPoints.sign_points_sort=2&signPoints.sign_points_integral=5&sign_points_id=2', '192.168.56.1', '2020-05-21 14:08:45');
INSERT INTO `sys_log` VALUES (227, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=2&signPoints.sign_points_name=周二签到&signPoints.sign_points_sort=2&signPoints.sign_points_integral=10&sign_points_id=2', '192.168.56.1', '2020-05-21 14:09:36');
INSERT INTO `sys_log` VALUES (228, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=1&signPoints.sign_points_name=周一签到&signPoints.sign_points_sort=1&signPoints.sign_points_integral=5&sign_points_id=1', '192.168.56.1', '2020-05-21 14:09:43');
INSERT INTO `sys_log` VALUES (229, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:add,[参数]:signPoints.sign_points_name=周三&signPoints.sign_points_sort=3&signPoints.sign_points_integral=15', '192.168.56.1', '2020-05-21 14:09:57');
INSERT INTO `sys_log` VALUES (230, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=3&signPoints.sign_points_name=周三签到&signPoints.sign_points_sort=3&signPoints.sign_points_integral=15&sign_points_id=3', '192.168.56.1', '2020-05-21 14:10:08');
INSERT INTO `sys_log` VALUES (231, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-05-21 14:10:40');
INSERT INTO `sys_log` VALUES (232, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=3&signPoints.sign_points_name=周三签到&signPoints.sign_points_sort=3&signPoints.sign_points_integral=15&sign_points_id=3', '192.168.56.1', '2020-05-21 14:10:55');
INSERT INTO `sys_log` VALUES (233, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=3&signPoints.sign_points_name=周三签到&signPoints.sign_points_sort=3&signPoints.sign_points_integral=15&sign_points_id=3', '192.168.56.1', '2020-05-21 14:11:03');
INSERT INTO `sys_log` VALUES (234, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:add,[参数]:signPoints.sign_points_name=周二&signPoints.sign_points_sort=2&signPoints.sign_points_integral=10', '192.168.56.1', '2020-05-21 14:13:09');
INSERT INTO `sys_log` VALUES (235, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/signPoints/index&sysResource.res_pid=49&sysResource.res_note=签到积分&sysResource.res_id=50&sysResource.res_icon=&res_id=50&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=签到管理', '192.168.56.1', '2020-05-21 14:14:22');
INSERT INTO `sys_log` VALUES (236, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=4&signPoints.sign_points_name=周二签到&signPoints.sign_points_sort=2&signPoints.sign_points_integral=10&sign_points_id=4', '192.168.56.1', '2020-05-21 14:16:36');
INSERT INTO `sys_log` VALUES (237, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=4&signPoints.sign_points_name=周二签到&signPoints.sign_points_sort=2&signPoints.sign_points_integral=10&sign_points_id=4', '192.168.56.1', '2020-05-21 14:22:40');
INSERT INTO `sys_log` VALUES (238, '管家', '[用户ID]:1,[控制器]:/signPoints,[方法]:edit,[参数]:signPoints.sign_points_id=1&signPoints.sign_points_name=周一签到&signPoints.sign_points_sort=1&signPoints.sign_points_integral=5&sign_points_id=1', '192.168.56.1', '2020-05-21 14:28:02');
INSERT INTO `sys_log` VALUES (239, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=9&pointsHome.points_home_name=哈哈&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=9', '192.168.56.1', '2020-05-21 14:55:02');
INSERT INTO `sys_log` VALUES (240, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=奖品,奖品类型管理中心&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=奖品管理', '192.168.56.1', '2020-05-22 10:08:25');
INSERT INTO `sys_log` VALUES (241, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/prizeType/index&sysResource.res_pid=54&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=奖品类型管理', '192.168.56.1', '2020-05-22 10:28:40');
INSERT INTO `sys_log` VALUES (242, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/prize/index&sysResource.res_pid=54&sysResource.res_note=奖品管理&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=奖品管理', '192.168.56.1', '2020-05-22 10:29:17');
INSERT INTO `sys_log` VALUES (243, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/prizeType/add&sysResource.res_pid=55&sysResource.res_note=添加数据&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-05-22 10:29:53');
INSERT INTO `sys_log` VALUES (244, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/prizeType/edit&sysResource.res_pid=55&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-22 10:30:11');
INSERT INTO `sys_log` VALUES (245, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/prizeType/del&sysResource.res_pid=55&sysResource.res_note=删除&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-22 10:30:33');
INSERT INTO `sys_log` VALUES (246, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/prizeType/edit&sysResource.res_pid=55&sysResource.res_note=数据修改&sysResource.res_id=58&sysResource.res_icon=pic_439&res_id=58&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-22 10:30:40');
INSERT INTO `sys_log` VALUES (247, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/prize/add&sysResource.res_pid=56&sysResource.res_note=奖品添加&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-05-22 10:30:56');
INSERT INTO `sys_log` VALUES (248, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/prize/edit&sysResource.res_pid=56&sysResource.res_note=修改数据&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-05-22 10:31:17');
INSERT INTO `sys_log` VALUES (249, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/prize/del&sysResource.res_pid=56&sysResource.res_note=数据删除&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-05-22 10:31:44');
INSERT INTO `sys_log` VALUES (250, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/prizeType/getPrizeTypeList&sysResource.res_pid=55&sysResource.res_note=获取全部奖品类型&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部奖品类型', '192.168.56.1', '2020-05-22 10:32:50');
INSERT INTO `sys_log` VALUES (251, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,39,44,48,47,46,45,40,43,42,41,49,50,53,52,51,54,56,62,61,60,55,59,58,57,63,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-05-22 10:33:06');
INSERT INTO `sys_log` VALUES (252, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:add,[参数]:prizeType.prize_type_name=测试类型1', '192.168.56.1', '2020-05-22 10:34:28');
INSERT INTO `sys_log` VALUES (253, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:36:08');
INSERT INTO `sys_log` VALUES (254, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:36:10');
INSERT INTO `sys_log` VALUES (255, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:37:27');
INSERT INTO `sys_log` VALUES (256, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:37:29');
INSERT INTO `sys_log` VALUES (257, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:37:57');
INSERT INTO `sys_log` VALUES (258, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:38:15');
INSERT INTO `sys_log` VALUES (259, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1', '192.168.56.1', '2020-05-22 10:39:09');
INSERT INTO `sys_log` VALUES (260, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1&prizeType.prize_type_name=测试类型11&prizeType.prize_type_id=1', '192.168.56.1', '2020-05-22 10:39:56');
INSERT INTO `sys_log` VALUES (261, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1&prizeType.prize_type_name=测试类型112&prizeType.prize_type_id=1', '192.168.56.1', '2020-05-22 10:39:59');
INSERT INTO `sys_log` VALUES (262, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:add,[参数]:prizeType.prize_type_name=测试2', '192.168.56.1', '2020-05-22 10:40:11');
INSERT INTO `sys_log` VALUES (263, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1&prizeType.prize_type_name=测试类型11&prizeType.prize_type_id=1', '192.168.56.1', '2020-05-22 10:40:53');
INSERT INTO `sys_log` VALUES (264, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=2&prize.prize_probability=0.0001&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_name=奖品1&prize.prize_sort=1&prize.prize_type_id=&prize.prize_points=1000', '192.168.56.1', '2020-05-22 11:36:34');
INSERT INTO `sys_log` VALUES (265, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=2&prize.prize_probability=0.0001&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_name=奖品1&prize.prize_sort=1&prize.prize_type_id=&prize.prize_points=1000', '192.168.56.1', '2020-05-22 11:37:08');
INSERT INTO `sys_log` VALUES (266, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=2&prize.prize_probability=0.0001&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_name=奖品1&prize.prize_sort=1&prize.prize_type_id=1&prize.prize_points=1000', '192.168.56.1', '2020-05-22 11:37:33');
INSERT INTO `sys_log` VALUES (267, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=10&prize.prize_probability=1&prize.prize_remarks=&prize.prize_online=0&prize.prize_name=奖品2&prize.prize_sort=2&prize.prize_type_id=&prize.prize_points=1500', '192.168.56.1', '2020-05-22 11:40:47');
INSERT INTO `sys_log` VALUES (268, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=10&prize.prize_probability=1&prize.prize_remarks=&prize.prize_online=0&prize.prize_name=奖品2&prize.prize_sort=2&prize.prize_type_id=1&prize.prize_points=1500', '192.168.56.1', '2020-05-22 11:40:57');
INSERT INTO `sys_log` VALUES (269, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=0&prize.prize_probability=&prize.prize_remarks=&prize.prize_online=0&prize.prize_name=奖品3&prize.prize_sort=0&prize.prize_type_id=&prize.prize_points=0', '192.168.56.1', '2020-05-22 14:38:46');
INSERT INTO `sys_log` VALUES (270, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=0&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=0&prize.prize_name=奖品4&prize.prize_sort=0&prize.prize_type_id=2&prize.prize_points=0', '192.168.56.1', '2020-05-22 14:40:55');
INSERT INTO `sys_log` VALUES (271, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=0.0&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=2&prize_id=3&prize.prize_name=奖品4', '192.168.56.1', '2020-05-22 14:54:36');
INSERT INTO `sys_log` VALUES (272, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=1&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=2&prize_id=3&prize.prize_name=奖品4', '192.168.56.1', '2020-05-22 15:13:21');
INSERT INTO `sys_log` VALUES (273, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1500&prize.prize_probability=10&prize.prize_sort=2&prize.prize_quantity=10&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=0&prize.prize_type_id=1&prize_id=2&prize.prize_name=奖品2', '192.168.56.1', '2020-05-22 15:35:41');
INSERT INTO `sys_log` VALUES (274, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1500&prize.prize_probability=100&prize.prize_sort=2&prize.prize_quantity=10&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=0&prize.prize_type_id=1&prize_id=2&prize.prize_name=奖品2', '192.168.56.1', '2020-05-22 15:35:47');
INSERT INTO `sys_log` VALUES (275, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=100&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=2&prize_id=3&prize.prize_name=奖品4', '192.168.56.1', '2020-05-22 16:51:08');
INSERT INTO `sys_log` VALUES (276, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1500&prize.prize_probability=99&prize.prize_sort=2&prize.prize_quantity=10&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=0&prize.prize_type_id=1&prize_id=2&prize.prize_name=奖品2', '192.168.56.1', '2020-05-22 16:58:34');
INSERT INTO `sys_log` VALUES (277, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-05-22 17:01:49');
INSERT INTO `sys_log` VALUES (278, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=20&prize.prize_probability=1&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=删除图片测试&prize.prize_sort=3&prize.prize_type_id=2&prize.prize_points=5000', '192.168.56.1', '2020-05-22 17:03:20');
INSERT INTO `sys_log` VALUES (279, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=100&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=2&prize_id=3&prize.prize_name=奖品4', '192.168.56.1', '2020-05-22 17:11:29');
INSERT INTO `sys_log` VALUES (280, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1000&prize.prize_probability=0&prize.prize_sort=1&prize.prize_quantity=2&prize.prize_id=1&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_type_id=1&prize_id=1&prize.prize_name=奖品1', '192.168.56.1', '2020-05-22 17:16:03');
INSERT INTO `sys_log` VALUES (281, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1000&prize.prize_probability=0&prize.prize_sort=1&prize.prize_quantity=2&prize.prize_id=1&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_type_id=1&prize_id=1&prize.prize_name=奖品1', '192.168.56.1', '2020-05-22 17:20:07');
INSERT INTO `sys_log` VALUES (282, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=6&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=/用户管理', '192.168.56.1', '2020-06-04 09:52:29');
INSERT INTO `sys_log` VALUES (283, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=30&sysResource.res_icon=&res_id=30&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=会员管理', '192.168.56.1', '2020-06-04 09:52:47');
INSERT INTO `sys_log` VALUES (284, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=20&sysResource.res_icon=&res_id=20&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分首页管理', '192.168.56.1', '2020-06-04 09:53:03');
INSERT INTO `sys_log` VALUES (285, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=4&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=39&sysResource.res_icon=&res_id=39&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=PK管理', '192.168.56.1', '2020-06-04 09:53:11');
INSERT INTO `sys_log` VALUES (286, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=5&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=签到栏目&sysResource.res_id=49&sysResource.res_icon=&res_id=49&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=签到管理', '192.168.56.1', '2020-06-04 09:53:19');
INSERT INTO `sys_log` VALUES (287, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=6&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_id=64&sysResource.res_icon=&res_id=64&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=用户管理', '192.168.56.1', '2020-06-04 09:53:51');
INSERT INTO `sys_log` VALUES (288, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/user/index&sysResource.res_pid=64&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=积分用户', '192.168.56.1', '2020-06-04 09:54:14');
INSERT INTO `sys_log` VALUES (289, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/user/add&sysResource.res_pid=65&sysResource.res_note=添加用户&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-06-04 09:54:45');
INSERT INTO `sys_log` VALUES (290, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/user/edit&sysResource.res_pid=65&sysResource.res_note=编辑用户&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-04 09:55:06');
INSERT INTO `sys_log` VALUES (291, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/user/del&sysResource.res_pid=65&sysResource.res_note=删除用户&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-04 09:55:26');
INSERT INTO `sys_log` VALUES (292, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,64,65,68,67,66,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-04 09:56:30');
INSERT INTO `sys_log` VALUES (293, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/prize/getPrizeList&sysResource.res_pid=65&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部上线奖品', '192.168.56.1', '2020-06-04 11:12:05');
INSERT INTO `sys_log` VALUES (294, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/prize/getPrizeList&sysResource.res_pid=65&sysResource.res_note=&sysResource.res_id=69&sysResource.res_icon=pic_381&res_id=69&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部上线奖品', '192.168.56.1', '2020-06-04 11:19:52');
INSERT INTO `sys_log` VALUES (295, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-04 11:24:55');
INSERT INTO `sys_log` VALUES (296, '管家', '[用户ID]:1,[控制器]:/user,[方法]:add,[参数]:user.user_account=ynwl_test&user.user_sign_date=1&user.user_points=0&user.user_token=没有&user.user_order_status=0&user.user_phone=110&user.user_prize_id=', '192.168.56.1', '2020-06-04 11:31:20');
INSERT INTO `sys_log` VALUES (297, '管家', '[用户ID]:1,[控制器]:/user,[方法]:add,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user.user_token=3123123&user.user_order_status=1&user.user_phone=123123&user.user_prize_id=3', '192.168.56.1', '2020-06-04 11:34:12');
INSERT INTO `sys_log` VALUES (298, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user_id=1', '192.168.56.1', '2020-06-04 14:04:44');
INSERT INTO `sys_log` VALUES (299, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user_id=1', '192.168.56.1', '2020-06-04 14:06:46');
INSERT INTO `sys_log` VALUES (300, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user_id=1', '192.168.56.1', '2020-06-04 14:06:48');
INSERT INTO `sys_log` VALUES (301, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user_id=1', '192.168.56.1', '2020-06-04 14:06:50');
INSERT INTO `sys_log` VALUES (302, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user_id=1', '192.168.56.1', '2020-06-04 14:07:39');
INSERT INTO `sys_log` VALUES (303, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=0&user.user_id=1&user.user_phone=110&user.user_prize_id=', '192.168.56.1', '2020-06-04 14:08:13');
INSERT INTO `sys_log` VALUES (304, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test2&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=0&user.user_id=1&user.user_phone=110&user.user_prize_id=', '192.168.56.1', '2020-06-04 14:08:17');
INSERT INTO `sys_log` VALUES (305, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test2&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=1&user.user_id=1&user.user_phone=110&user.user_prize_id=', '192.168.56.1', '2020-06-04 14:08:28');
INSERT INTO `sys_log` VALUES (306, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test2&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=1&user.user_id=1&user.user_phone=11000&user.user_prize_id=', '192.168.56.1', '2020-06-04 14:08:36');
INSERT INTO `sys_log` VALUES (307, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user_id=2&user.user_token=3123123&user.user_order_status=1&user.user_id=2&user.user_phone=123123&user.user_prize_id=3', '192.168.56.1', '2020-06-04 14:09:33');
INSERT INTO `sys_log` VALUES (308, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user_id=2&user.user_token=3123123&user.user_order_status=1&user.user_id=2&user.user_phone=123123&user.user_prize_id=3', '192.168.56.1', '2020-06-04 14:11:29');
INSERT INTO `sys_log` VALUES (309, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user_id=2&user.user_token=3123123&user.user_order_status=0&user.user_id=2&user.user_phone=123123&user.user_prize_id=3', '192.168.56.1', '2020-06-04 14:11:33');
INSERT INTO `sys_log` VALUES (310, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user_id=2&user.user_token=3123123&user.user_order_status=0&user.user_id=2&user.user_phone=123123&user.user_prize_id=4', '192.168.56.1', '2020-06-04 14:11:40');
INSERT INTO `sys_log` VALUES (311, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test2&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=1&user.user_id=1&user.user_phone=11000&user.user_prize_id=1', '192.168.56.1', '2020-06-04 14:11:45');
INSERT INTO `sys_log` VALUES (312, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=ynwl_test2&user.user_sign_date=1&user.user_points=0&user_id=1&user.user_token=ABc12EFF&user.user_order_status=1&user.user_id=1&user.user_phone=11000&user.user_prize_id=3', '192.168.56.1', '2020-06-04 14:19:19');
INSERT INTO `sys_log` VALUES (313, '管家', '[用户ID]:1,[控制器]:/user,[方法]:edit,[参数]:user.user_account=12312&user.user_sign_date=2&user.user_points=0&user_id=2&user.user_token=3123123&user.user_order_status=0&user.user_id=2&user.user_phone=123123&user.user_prize_id=3', '192.168.56.1', '2020-06-04 14:19:23');
INSERT INTO `sys_log` VALUES (314, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=7&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=游戏管理', '192.168.56.1', '2020-06-08 09:34:46');
INSERT INTO `sys_log` VALUES (315, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/gameType/index&sysResource.res_pid=70&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=/游戏类型管理', '192.168.56.1', '2020-06-08 09:35:23');
INSERT INTO `sys_log` VALUES (316, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/gameType/add&sysResource.res_pid=71&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-06-08 09:35:52');
INSERT INTO `sys_log` VALUES (317, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/gameType/edit&sysResource.res_pid=71&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=修改', '192.168.56.1', '2020-06-08 09:36:07');
INSERT INTO `sys_log` VALUES (318, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/gameType/del&sysResource.res_pid=71&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-08 09:36:21');
INSERT INTO `sys_log` VALUES (319, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/gameType/getAllGameTypes&sysResource.res_pid=71&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取游戏类型数据', '192.168.56.1', '2020-06-08 09:36:56');
INSERT INTO `sys_log` VALUES (320, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/gameType/index&sysResource.res_pid=70&sysResource.res_note=&sysResource.res_id=71&sysResource.res_icon=&res_id=71&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=游戏类型管理', '192.168.56.1', '2020-06-08 09:37:01');
INSERT INTO `sys_log` VALUES (321, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-08 09:37:39');
INSERT INTO `sys_log` VALUES (322, '管家', '[用户ID]:1,[控制器]:/gameType,[方法]:add,[参数]:gameType.game_type_name=动作', '192.168.56.1', '2020-06-08 09:43:18');
INSERT INTO `sys_log` VALUES (323, '管家', '[用户ID]:1,[控制器]:/gameType,[方法]:edit,[参数]:gameType.game_type_name=动作1&gameType.game_type_id=1&game_type_id=1', '192.168.56.1', '2020-06-08 09:46:21');
INSERT INTO `sys_log` VALUES (324, '管家', '[用户ID]:1,[控制器]:/gameType,[方法]:add,[参数]:gameType.game_type_name=休闲', '192.168.56.1', '2020-06-08 09:46:32');
INSERT INTO `sys_log` VALUES (325, '管家', '[用户ID]:1,[控制器]:/gameType,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-06-08 09:46:35');
INSERT INTO `sys_log` VALUES (326, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/game/index&sysResource.res_pid=70&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=游戏管理', '192.168.56.1', '2020-06-08 09:47:57');
INSERT INTO `sys_log` VALUES (327, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/game/add&sysResource.res_pid=76&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-06-08 09:48:18');
INSERT INTO `sys_log` VALUES (328, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/game/edit&sysResource.res_pid=76&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-08 09:48:33');
INSERT INTO `sys_log` VALUES (329, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/game/edit&sysResource.res_pid=76&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-08 09:48:48');
INSERT INTO `sys_log` VALUES (330, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=4&sysResource.res_url=/gameType/getAllGameTypes&sysResource.res_pid=76&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取游戏类型资源', '192.168.56.1', '2020-06-08 09:49:18');
INSERT INTO `sys_log` VALUES (331, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-08 09:49:35');
INSERT INTO `sys_log` VALUES (332, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:51:16');
INSERT INTO `sys_log` VALUES (333, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:51:18');
INSERT INTO `sys_log` VALUES (334, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:51:34');
INSERT INTO `sys_log` VALUES (335, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:51:35');
INSERT INTO `sys_log` VALUES (336, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:52:29');
INSERT INTO `sys_log` VALUES (337, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:52:31');
INSERT INTO `sys_log` VALUES (338, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:53:09');
INSERT INTO `sys_log` VALUES (339, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:53:50');
INSERT INTO `sys_log` VALUES (340, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:53:53');
INSERT INTO `sys_log` VALUES (341, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 10:54:17');
INSERT INTO `sys_log` VALUES (342, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_sort=1&game.game_selected_img=&game.game_name=123123&game.game_online=0&game.game_unselected_img=&game.game_type_id=1', '192.168.56.1', '2020-06-08 10:57:50');
INSERT INTO `sys_log` VALUES (343, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_sort=&game.game_selected_img=&game.game_name=&game.game_online=0&game.game_unselected_img=&game.game_type_id=1', '192.168.56.1', '2020-06-08 11:02:08');
INSERT INTO `sys_log` VALUES (344, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:23');
INSERT INTO `sys_log` VALUES (345, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:27');
INSERT INTO `sys_log` VALUES (346, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:29');
INSERT INTO `sys_log` VALUES (347, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:31');
INSERT INTO `sys_log` VALUES (348, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:32');
INSERT INTO `sys_log` VALUES (349, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:37');
INSERT INTO `sys_log` VALUES (350, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:51');
INSERT INTO `sys_log` VALUES (351, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:53');
INSERT INTO `sys_log` VALUES (352, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:null', '192.168.56.1', '2020-06-08 11:02:54');
INSERT INTO `sys_log` VALUES (353, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_name=打法的&game.game_sort=1&game.game_type_id=1&game.game_online=1', '192.168.56.1', '2020-06-08 11:04:00');
INSERT INTO `sys_log` VALUES (354, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_name=&game.game_sort=&game.game_type_id=1&game.game_online=1', '192.168.56.1', '2020-06-08 11:04:23');
INSERT INTO `sys_log` VALUES (355, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_name=123&game.game_sort=&game.game_type_id=1&game.game_online=1', '192.168.56.1', '2020-06-08 11:04:26');
INSERT INTO `sys_log` VALUES (356, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=http://120123123123&game.game_name=测试游戏1&game.game_sort=3&game.game_type_id=1&game.game_online=0', '192.168.56.1', '2020-06-08 11:11:05');
INSERT INTO `sys_log` VALUES (357, '管家', '[用户ID]:1,[控制器]:/game,[方法]:edit,[参数]:game.game_name=测试游戏1&game_id=4&game.game_sort=3&game.game_is_param=0&game_url=http://120123123123&game.game_id=4&game_type_id=&game.game_online=0', '192.168.56.1', '2020-06-08 11:52:05');
INSERT INTO `sys_log` VALUES (358, '管家', '[用户ID]:1,[控制器]:/game,[方法]:edit,[参数]:game.game_name=测试游戏&game_id=4&game.game_sort=3&game.game_is_param=0&game_url=http://120123123123&game.game_id=4&game.game_type_id=1&game.game_online=1', '192.168.56.1', '2020-06-08 14:09:02');
INSERT INTO `sys_log` VALUES (359, '管家', '[用户ID]:1,[控制器]:/gameType,[方法]:add,[参数]:gameType.game_type_name=休闲', '192.168.56.1', '2020-06-08 14:09:16');
INSERT INTO `sys_log` VALUES (360, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_name=休闲&game.game_sort=3&game.game_type_id=3&game.game_online=2', '192.168.56.1', '2020-06-08 14:09:43');
INSERT INTO `sys_log` VALUES (361, '管家', '[用户ID]:1,[控制器]:/game,[方法]:edit,[参数]:game.game_name=休闲&game_id=5&game.game_sort=3&game.game_is_param=0&game_url=&game.game_id=5&game.game_type_id=1&game.game_online=1', '192.168.56.1', '2020-06-08 14:09:56');
INSERT INTO `sys_log` VALUES (362, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=3&sysResource.res_url=/game/del&sysResource.res_pid=76&sysResource.res_note=&sysResource.res_id=79&sysResource.res_icon=pic_439&res_id=79&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-08 14:10:42');
INSERT INTO `sys_log` VALUES (363, '管家', '[用户ID]:1,[控制器]:/game,[方法]:del,[参数]:id=1', '192.168.56.1', '2020-06-08 14:10:52');
INSERT INTO `sys_log` VALUES (364, '管家', '[用户ID]:1,[控制器]:/game,[方法]:del,[参数]:id=5', '192.168.56.1', '2020-06-08 14:11:41');
INSERT INTO `sys_log` VALUES (365, '管家', '[用户ID]:1,[控制器]:/game,[方法]:del,[参数]:id=4', '192.168.56.1', '2020-06-08 14:14:24');
INSERT INTO `sys_log` VALUES (366, '管家', '[用户ID]:1,[控制器]:/game,[方法]:add,[参数]:game.game_url=&game.game_name=图片删除测试&game.game_sort=1&game.game_type_id=3&game.game_online=1', '192.168.56.1', '2020-06-08 14:14:56');
INSERT INTO `sys_log` VALUES (367, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截管理', '192.168.56.1', '2020-06-08 14:33:14');
INSERT INTO `sys_log` VALUES (368, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/intercept/index&sysResource.res_pid=81&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截管理', '192.168.56.1', '2020-06-08 14:33:36');
INSERT INTO `sys_log` VALUES (369, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/interceptType/index&sysResource.res_pid=81&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截类型管理', '192.168.56.1', '2020-06-08 14:34:18');
INSERT INTO `sys_log` VALUES (370, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/interceptType/add&sysResource.res_pid=83&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-06-08 14:34:48');
INSERT INTO `sys_log` VALUES (371, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/interceptType/edit&sysResource.res_pid=83&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-08 14:35:07');
INSERT INTO `sys_log` VALUES (372, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/interceptType/del&sysResource.res_pid=83&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-08 14:35:26');
INSERT INTO `sys_log` VALUES (373, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/interceptType/getInterceptTypeList&sysResource.res_pid=83&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部拦截类型', '192.168.56.1', '2020-06-08 14:36:05');
INSERT INTO `sys_log` VALUES (374, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/intercept&sysResource.res_pid=82&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-06-08 14:36:34');
INSERT INTO `sys_log` VALUES (375, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/intercept/edit&sysResource.res_pid=82&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-08 14:36:54');
INSERT INTO `sys_log` VALUES (376, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/intercept/del&sysResource.res_pid=82&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-08 14:37:11');
INSERT INTO `sys_log` VALUES (377, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/intercept/index&sysResource.res_pid=81&sysResource.res_note=大厅拦截功能&sysResource.res_id=82&sysResource.res_icon=&res_id=82&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截管理', '192.168.56.1', '2020-06-08 14:37:33');
INSERT INTO `sys_log` VALUES (378, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/interceptType/index&sysResource.res_pid=81&sysResource.res_note=专区拦截类型：首页，退出&sysResource.res_id=83&sysResource.res_icon=&res_id=83&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截类型管理', '192.168.56.1', '2020-06-08 14:37:50');
INSERT INTO `sys_log` VALUES (379, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/intercept/index&sysResource.res_pid=81&sysResource.res_note=专区拦截功能&sysResource.res_id=82&sysResource.res_icon=&res_id=82&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=拦截管理', '192.168.56.1', '2020-06-08 14:37:57');
INSERT INTO `sys_log` VALUES (380, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-08 14:39:15');
INSERT INTO `sys_log` VALUES (381, '管家', '[用户ID]:1,[控制器]:/interceptType,[方法]:edit,[参数]:interceptType.intercept_type_name_en=home_index&interceptType.intercept_type_name=首页拦截1&interceptType.intercept_type_id=1&intercept_type_id=1', '192.168.56.1', '2020-06-08 14:55:39');
INSERT INTO `sys_log` VALUES (382, '管家', '[用户ID]:1,[控制器]:/interceptType,[方法]:edit,[参数]:interceptType.intercept_type_name_en=home_exit&interceptType.intercept_type_name=退出拦截21&interceptType.intercept_type_id=2&intercept_type_id=2', '192.168.56.1', '2020-06-08 14:55:42');
INSERT INTO `sys_log` VALUES (383, '管家', '[用户ID]:1,[控制器]:/interceptType,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-06-08 14:55:50');
INSERT INTO `sys_log` VALUES (384, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/intercept/add&sysResource.res_pid=82&sysResource.res_note=&sysResource.res_id=88&sysResource.res_icon=pic_439&res_id=88&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=新增', '192.168.56.1', '2020-06-08 14:56:56');
INSERT INTO `sys_log` VALUES (385, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=www.baidu.com', '192.168.56.1', '2020-06-08 15:08:06');
INSERT INTO `sys_log` VALUES (386, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=www.baidu.com', '192.168.56.1', '2020-06-08 15:08:10');
INSERT INTO `sys_log` VALUES (387, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=http:www.baidu.com', '192.168.56.1', '2020-06-08 15:09:25');
INSERT INTO `sys_log` VALUES (388, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=www.baidu', '192.168.56.1', '2020-06-08 15:10:33');
INSERT INTO `sys_log` VALUES (389, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=123123123', '192.168.56.1', '2020-06-08 15:10:44');
INSERT INTO `sys_log` VALUES (390, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:add,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=1&intercept.intercept_param=0&intercept.intercept_url=123123123', '192.168.56.1', '2020-06-08 15:11:22');
INSERT INTO `sys_log` VALUES (391, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:edit,[参数]:intercept.intercept_type_id=1&intercept.intercept_online=0&intercept_id=4&intercept.intercept_param=0&intercept.intercept_id=4&intercept.intercept_url=123123123', '192.168.56.1', '2020-06-08 15:11:59');
INSERT INTO `sys_log` VALUES (392, '管家', '[用户ID]:1,[控制器]:/interceptType,[方法]:add,[参数]:interceptType.intercept_type_name_en=adfadf&interceptType.intercept_type_name=adfadf', '192.168.56.1', '2020-06-08 15:12:08');
INSERT INTO `sys_log` VALUES (393, '管家', '[用户ID]:1,[控制器]:/interceptType,[方法]:edit,[参数]:interceptType.intercept_type_name_en=adfadf12312312&interceptType.intercept_type_name=adfadf&interceptType.intercept_type_id=3&intercept_type_id=3', '192.168.56.1', '2020-06-08 15:12:12');
INSERT INTO `sys_log` VALUES (394, '管家', '[用户ID]:1,[控制器]:/intercept,[方法]:edit,[参数]:intercept.intercept_type_id=3&intercept.intercept_online=1&intercept_id=3&intercept.intercept_param=0&intercept.intercept_id=3&intercept.intercept_url=123123123', '192.168.56.1', '2020-06-08 15:12:21');
INSERT INTO `sys_log` VALUES (395, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=系统管理', '192.168.56.1', '2020-06-15 15:13:59');
INSERT INTO `sys_log` VALUES (396, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/index&sysResource.res_pid=91&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=系统类型管理', '192.168.56.1', '2020-06-15 15:14:20');
INSERT INTO `sys_log` VALUES (397, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/add&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-06-15 15:14:37');
INSERT INTO `sys_log` VALUES (398, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsSysType/edit&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-15 15:14:55');
INSERT INTO `sys_log` VALUES (399, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsSysType/del&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-15 15:15:09');
INSERT INTO `sys_log` VALUES (400, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/&sysResource.res_pid=19&sysResource.res_note=积分系统管理，活动系统管理等&sysResource.res_id=91&sysResource.res_icon=&res_id=91&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=系统管理', '192.168.56.1', '2020-06-15 15:15:56');
INSERT INTO `sys_log` VALUES (401, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,92,95,94,93,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-15 15:16:12');
INSERT INTO `sys_log` VALUES (402, '管家', '[用户ID]:1,[控制器]:/pointsSysType,[方法]:add,[参数]:pointsSysType.points_sys_type_name=积分系统管理', '192.168.56.1', '2020-06-15 15:16:49');
INSERT INTO `sys_log` VALUES (403, '管家', '[用户ID]:1,[控制器]:/pointsSysType,[方法]:edit,[参数]:points_sys_type_id=1&pointsSysType.points_sys_type_name=积分系统管理1&pointsSysType.points_sys_type_id=1', '192.168.56.1', '2020-06-15 15:18:06');
INSERT INTO `sys_log` VALUES (404, '管家', '[用户ID]:1,[控制器]:/pointsSysType,[方法]:edit,[参数]:points_sys_type_id=1&pointsSysType.points_sys_type_name=积分系统管理&pointsSysType.points_sys_type_id=1', '192.168.56.1', '2020-06-15 15:18:11');
INSERT INTO `sys_log` VALUES (405, '管家', '[用户ID]:1,[控制器]:/pointsSysType,[方法]:add,[参数]:pointsSysType.points_sys_type_name=测速系统高压包库', '192.168.56.1', '2020-06-15 15:18:21');
INSERT INTO `sys_log` VALUES (406, '管家', '[用户ID]:1,[控制器]:/pointsSysType,[方法]:del,[参数]:id=2', '192.168.56.1', '2020-06-15 15:18:24');
INSERT INTO `sys_log` VALUES (407, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/&sysResource.res_pid=91&sysResource.res_note=&sysResource.res_icon=&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=系统图片管理', '192.168.56.1', '2020-06-15 18:14:21');
INSERT INTO `sys_log` VALUES (408, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysImg/add&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=添加', '192.168.56.1', '2020-06-15 18:14:53');
INSERT INTO `sys_log` VALUES (409, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsSysImg/edit&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=编辑', '192.168.56.1', '2020-06-15 18:15:10');
INSERT INTO `sys_log` VALUES (410, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=3&sysResource.res_url=/pointsSysImg/del&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=删除', '192.168.56.1', '2020-06-15 18:15:30');
INSERT INTO `sys_log` VALUES (411, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsSysImg/index&sysResource.res_pid=91&sysResource.res_note=&sysResource.res_id=96&sysResource.res_icon=&res_id=96&sysResource.res_resource_type=0&sysResource.res_status=1&sysResource.res_name=系统图片管理', '192.168.56.1', '2020-06-15 18:16:08');
INSERT INTO `sys_log` VALUES (412, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,99,98,97,92,95,94,93,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-15 18:16:24');
INSERT INTO `sys_log` VALUES (413, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPointsSysTypeList&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取系统类型', '192.168.56.1', '2020-06-15 18:18:29');
INSERT INTO `sys_log` VALUES (414, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,99,98,97,100,92,95,94,93,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-15 18:18:44');
INSERT INTO `sys_log` VALUES (415, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPrizeTypeList&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_id=100&sysResource.res_icon=pic_381&res_id=100&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取系统类型', '192.168.56.1', '2020-06-16 09:14:06');
INSERT INTO `sys_log` VALUES (416, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPrizeTypeList&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部类型', '192.168.56.1', '2020-06-16 09:16:47');
INSERT INTO `sys_log` VALUES (417, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,99,98,97,100,92,95,94,93,101,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-16 09:16:59');
INSERT INTO `sys_log` VALUES (418, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPointsSysTypeList&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_id=101&sysResource.res_icon=pic_381&res_id=101&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取全部类型', '192.168.56.1', '2020-06-16 09:19:28');
INSERT INTO `sys_log` VALUES (419, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPointsSysTypeList&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_id=100&sysResource.res_icon=pic_381&res_id=100&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取系统类型', '192.168.56.1', '2020-06-16 09:19:32');
INSERT INTO `sys_log` VALUES (420, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=1&sysResource.res_url=/pointsSysType/getPointsSysTypeList&sysResource.res_pid=92&sysResource.res_note=&sysResource.res_id=101&sysResource.res_icon=pic_381&res_id=101&sysResource.res_resource_type=3&sysResource.res_status=0&sysResource.res_name=获取全部类型', '192.168.56.1', '2020-06-16 09:19:59');
INSERT INTO `sys_log` VALUES (421, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsSysImg/getPointsSysPageType&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=获取字段中的json数据', '192.168.56.1', '2020-06-18 10:50:07');
INSERT INTO `sys_log` VALUES (422, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,99,98,102,97,100,92,95,94,93,101,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-18 11:26:03');
INSERT INTO `sys_log` VALUES (423, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:getPointsSysPageType,[参数]:id=1', '192.168.56.1', '2020-06-19 11:31:26');
INSERT INTO `sys_log` VALUES (424, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:getPointsSysPageType,[参数]:id=1', '192.168.56.1', '2020-06-19 11:32:56');
INSERT INTO `sys_log` VALUES (425, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsSysImg/cont&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_439&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=内容添加', '192.168.56.1', '2020-06-22 10:43:56');
INSERT INTO `sys_log` VALUES (426, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsSysImg/con&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_id=103&sysResource.res_icon=pic_439&res_id=103&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=内容添加', '192.168.56.1', '2020-06-22 10:44:03');
INSERT INTO `sys_log` VALUES (427, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,103,99,98,102,97,100,92,95,94,93,101,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-22 10:46:08');
INSERT INTO `sys_log` VALUES (428, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:edit,[参数]:sysResource.res_sort=4&sysResource.res_url=/pointsSysImg/addCon&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_id=103&sysResource.res_icon=pic_439&res_id=103&sysResource.res_resource_type=1&sysResource.res_status=1&sysResource.res_name=内容添加', '192.168.56.1', '2020-06-22 10:51:38');
INSERT INTO `sys_log` VALUES (429, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=adfad', '192.168.56.1', '2020-06-22 11:08:56');
INSERT INTO `sys_log` VALUES (430, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=adfadfadf', '192.168.56.1', '2020-06-22 11:09:10');
INSERT INTO `sys_log` VALUES (431, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=哈哈哈', '192.168.56.1', '2020-06-22 11:10:25');
INSERT INTO `sys_log` VALUES (432, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=阿凡达手动阀', '192.168.56.1', '2020-06-22 11:11:20');
INSERT INTO `sys_log` VALUES (433, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=123123123', '192.168.56.1', '2020-06-22 11:12:38');
INSERT INTO `sys_log` VALUES (434, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=打发斯蒂芬', '192.168.56.1', '2020-06-22 11:12:52');
INSERT INTO `sys_log` VALUES (435, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=123123123', '192.168.56.1', '2020-06-22 11:13:57');
INSERT INTO `sys_log` VALUES (436, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=的法师打发斯蒂芬', '192.168.56.1', '2020-06-22 11:17:02');
INSERT INTO `sys_log` VALUES (437, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=ad', '192.168.56.1', '2020-06-22 11:18:00');
INSERT INTO `sys_log` VALUES (438, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:addCon,[参数]:pointsSysImg.points_sys_type_id=1&pointsSysImg.points_sys_name=123123', '192.168.56.1', '2020-06-22 11:18:21');
INSERT INTO `sys_log` VALUES (439, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageName=&pagetype=0&pageEnName=&pointsSysImg.points_sys_name=爱的发的发&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:10:49');
INSERT INTO `sys_log` VALUES (440, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageName=&pagetype=0&pageEnName=&pointsSysImg.points_sys_name=爱的发的发&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:33:22');
INSERT INTO `sys_log` VALUES (441, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&pointsSysImg.points_sys_name=测试系统&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:34:01');
INSERT INTO `sys_log` VALUES (442, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&pointsSysImg.points_sys_name=系统&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:34:51');
INSERT INTO `sys_log` VALUES (443, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:del,[参数]:id=103', '192.168.56.1', '2020-06-22 14:35:32');
INSERT INTO `sys_log` VALUES (444, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&pointsSysImg.points_sys_name=册数&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:35:45');
INSERT INTO `sys_log` VALUES (445, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&pointsSysImg.points_sys_name=爱的发发&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 14:36:14');
INSERT INTO `sys_log` VALUES (446, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&addType=1&pointsSysImg.points_sys_name=123123&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:16:10');
INSERT INTO `sys_log` VALUES (447, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:lable=&pagetype=&pageEnName=&addType=1&pointsSysImg.points_sys_name=afadfaefwef&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:16:24');
INSERT INTO `sys_log` VALUES (448, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pagetype=&pageEnName=index&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:39:49');
INSERT INTO `sys_log` VALUES (449, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=englishName&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:40:23');
INSERT INTO `sys_log` VALUES (450, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:40:56');
INSERT INTO `sys_log` VALUES (451, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=1&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:45:11');
INSERT INTO `sys_log` VALUES (452, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=1&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:45:13');
INSERT INTO `sys_log` VALUES (453, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=1&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:45:21');
INSERT INTO `sys_log` VALUES (454, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:45:35');
INSERT INTO `sys_log` VALUES (455, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:46:55');
INSERT INTO `sys_log` VALUES (456, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:49:05');
INSERT INTO `sys_log` VALUES (457, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=guize&pagetype=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:49:51');
INSERT INTO `sys_log` VALUES (458, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 15:59:40');
INSERT INTO `sys_log` VALUES (459, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=guize&pagetype=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:00:31');
INSERT INTO `sys_log` VALUES (460, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=1&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:01:45');
INSERT INTO `sys_log` VALUES (461, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:01:48');
INSERT INTO `sys_log` VALUES (462, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=gyuziue&pagetype=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:03:08');
INSERT INTO `sys_log` VALUES (463, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:23:59');
INSERT INTO `sys_log` VALUES (464, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=qita&pagetype=&addType=2&title=其他页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:26:21');
INSERT INTO `sys_log` VALUES (465, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pagetype=&addType=1&title=积分系统&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:30:04');
INSERT INTO `sys_log` VALUES (466, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pagetype=&addType=1&title=积分系统&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:31:16');
INSERT INTO `sys_log` VALUES (467, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pagetype=&addType=1&title=积分系统&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:33:42');
INSERT INTO `sys_log` VALUES (468, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:42:02');
INSERT INTO `sys_log` VALUES (469, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:43:08');
INSERT INTO `sys_log` VALUES (470, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=adfadf&pagetype=&addType=1&title=dfaf&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:44:12');
INSERT INTO `sys_log` VALUES (471, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=adsfasdf&pagetype=&addType=2&title=fadfa&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:47:42');
INSERT INTO `sys_log` VALUES (472, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=234234&pagetype=&addType=2&title=234234&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:51:04');
INSERT INTO `sys_log` VALUES (473, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=234234&pagetype=&addType=2&title=234234&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:51:08');
INSERT INTO `sys_log` VALUES (474, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=234234&pagetype=&addType=1&title=234234&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:51:15');
INSERT INTO `sys_log` VALUES (475, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pagetype=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:55:02');
INSERT INTO `sys_log` VALUES (476, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=pay&pagetype=&addType=2&title=支付页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 16:55:32');
INSERT INTO `sys_log` VALUES (477, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pagetype=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:12:59');
INSERT INTO `sys_log` VALUES (478, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pagetype=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:13:04');
INSERT INTO `sys_log` VALUES (479, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pagetype=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:13:46');
INSERT INTO `sys_log` VALUES (480, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pagetype=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:14:20');
INSERT INTO `sys_log` VALUES (481, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:15:02');
INSERT INTO `sys_log` VALUES (482, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:45:58');
INSERT INTO `sys_log` VALUES (483, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-22 17:55:56');
INSERT INTO `sys_log` VALUES (484, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 09:43:26');
INSERT INTO `sys_log` VALUES (485, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 09:44:27');
INSERT INTO `sys_log` VALUES (486, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:15:44');
INSERT INTO `sys_log` VALUES (487, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:18:55');
INSERT INTO `sys_log` VALUES (488, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:30:57');
INSERT INTO `sys_log` VALUES (489, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=2&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:31:27');
INSERT INTO `sys_log` VALUES (490, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=btn&pageType=2&addType=1&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:31:49');
INSERT INTO `sys_log` VALUES (491, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=btn&pageType=2&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:31:53');
INSERT INTO `sys_log` VALUES (492, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:38:16');
INSERT INTO `sys_log` VALUES (493, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:39:12');
INSERT INTO `sys_log` VALUES (494, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:40:12');
INSERT INTO `sys_log` VALUES (495, '管家', '[用户ID]:1,[控制器]:/sysSetting,[方法]:edit,[参数]:sysSetting.set_title=积分系统后台管理系统&initRSA=0&sysSetting.set_tm_upload=E:/application/nginx-1.17.5/html/points_system&set_id=1&sysSetting.set_publickey=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB&sysSetting.set_url=http://192.168.0.72:8082/points_system/&sysSetting.set_upload=E:/application/nginx-1.17.5/html/points_system&sysSetting.set_id=1', '192.168.56.1', '2020-06-23 10:41:00');
INSERT INTO `sys_log` VALUES (496, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:41:40');
INSERT INTO `sys_log` VALUES (497, '管家', '[用户ID]:1,[控制器]:/sysSetting,[方法]:edit,[参数]:sysSetting.set_title=积分系统后台管理系统&initRSA=0&sysSetting.set_tm_upload=E:/application/nginx-1.17.5/html/points_system/&set_id=1&sysSetting.set_publickey=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB&sysSetting.set_url=http://192.168.0.72:8082/points_system/&sysSetting.set_upload=E:/application/nginx-1.17.5/html/points_system/&sysSetting.set_id=1', '192.168.56.1', '2020-06-23 10:43:06');
INSERT INTO `sys_log` VALUES (498, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:43:28');
INSERT INTO `sys_log` VALUES (499, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:44:55');
INSERT INTO `sys_log` VALUES (500, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:47:23');
INSERT INTO `sys_log` VALUES (501, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=index&pageType=1&addType=3&title=&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:47:41');
INSERT INTO `sys_log` VALUES (502, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pageType=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 10:53:45');
INSERT INTO `sys_log` VALUES (503, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pageType=&addType=2&title=系统页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 11:08:11');
INSERT INTO `sys_log` VALUES (504, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=首页背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:26:51');
INSERT INTO `sys_log` VALUES (505, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=&pageType=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:28:35');
INSERT INTO `sys_log` VALUES (506, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:38:39');
INSERT INTO `sys_log` VALUES (507, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:40:41');
INSERT INTO `sys_log` VALUES (508, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=首页2&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:51:03');
INSERT INTO `sys_log` VALUES (509, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=btn&pageType=1&addType=3&title=按钮&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:51:32');
INSERT INTO `sys_log` VALUES (510, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=btn&pageType=1&addType=3&title=按钮&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 15:52:14');
INSERT INTO `sys_log` VALUES (511, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=123123&pageType=1&addType=3&title=按钮&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:06:21');
INSERT INTO `sys_log` VALUES (512, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=indexbg&pageType=1&addType=3&title=首页背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:11:33');
INSERT INTO `sys_log` VALUES (513, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=indexbg&pageType=1&addType=3&title=首页背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:11:59');
INSERT INTO `sys_log` VALUES (514, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:englishName=bg&pageType=1&addType=3&title=背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:14:52');
INSERT INTO `sys_log` VALUES (515, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:18:09');
INSERT INTO `sys_log` VALUES (516, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:18:10');
INSERT INTO `sys_log` VALUES (517, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:18:15');
INSERT INTO `sys_log` VALUES (518, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:18:26');
INSERT INTO `sys_log` VALUES (519, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:18:43');
INSERT INTO `sys_log` VALUES (520, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:19:14');
INSERT INTO `sys_log` VALUES (521, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:20:25');
INSERT INTO `sys_log` VALUES (522, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:20:33');
INSERT INTO `sys_log` VALUES (523, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=3&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:22:14');
INSERT INTO `sys_log` VALUES (524, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:29:15');
INSERT INTO `sys_log` VALUES (525, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:29:33');
INSERT INTO `sys_log` VALUES (526, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:30:01');
INSERT INTO `sys_log` VALUES (527, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=支付页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:30:13');
INSERT INTO `sys_log` VALUES (528, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=首页背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:30:35');
INSERT INTO `sys_log` VALUES (529, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=返回按钮&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:31:00');
INSERT INTO `sys_log` VALUES (530, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=首页背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:31:50');
INSERT INTO `sys_log` VALUES (531, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=3&addType=3&title=支付背景&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:32:20');
INSERT INTO `sys_log` VALUES (532, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=其他页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:51:15');
INSERT INTO `sys_log` VALUES (533, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=4&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:51:35');
INSERT INTO `sys_log` VALUES (534, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=4&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:52:15');
INSERT INTO `sys_log` VALUES (535, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=4&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:52:34');
INSERT INTO `sys_log` VALUES (536, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=4&addType=3&title=哈哈图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-23 16:53:01');
INSERT INTO `sys_log` VALUES (537, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:del,[参数]:id=28', '192.168.56.1', '2020-06-24 09:31:26');
INSERT INTO `sys_log` VALUES (538, '管家', '[用户ID]:1,[控制器]:/resource,[方法]:add,[参数]:sysResource.res_sort=2&sysResource.res_url=/pointsSysImg/getPointsSysImgJson&sysResource.res_pid=96&sysResource.res_note=&sysResource.res_icon=pic_381&sysResource.res_resource_type=3&sysResource.res_status=1&sysResource.res_name=根据iD获取资源', '192.168.56.1', '2020-06-24 09:57:18');
INSERT INTO `sys_log` VALUES (539, '管家', '[用户ID]:1,[控制器]:/sysRole,[方法]:auth,[参数]:sysr_id=1&auth=19,70,76,80,79,78,77,71,74,73,72,75,64,65,68,67,66,69,49,50,53,52,51,39,44,48,47,46,45,40,43,42,41,20,21,25,22,24,23,30,31,34,33,32,35,38,37,36,54,56,62,61,60,55,59,58,57,63,81,83,86,85,84,87,82,90,89,88,91,96,99,98,102,104,97,100,92,95,94,93,101,1,2,5,4,3,6,12,11,10,9,8,7,13,16,15,14,28,29,17,18,27', '192.168.56.1', '2020-06-24 09:57:35');
INSERT INTO `sys_log` VALUES (540, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:50:13');
INSERT INTO `sys_log` VALUES (541, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:52:32');
INSERT INTO `sys_log` VALUES (542, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:52:45');
INSERT INTO `sys_log` VALUES (543, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:53:10');
INSERT INTO `sys_log` VALUES (544, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:54:27');
INSERT INTO `sys_log` VALUES (545, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:56:15');
INSERT INTO `sys_log` VALUES (546, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:57:43');
INSERT INTO `sys_log` VALUES (547, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 10:58:49');
INSERT INTO `sys_log` VALUES (548, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:01:53');
INSERT INTO `sys_log` VALUES (549, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:04:53');
INSERT INTO `sys_log` VALUES (550, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:06:03');
INSERT INTO `sys_log` VALUES (551, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:06:55');
INSERT INTO `sys_log` VALUES (552, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:08:12');
INSERT INTO `sys_log` VALUES (553, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:08:44');
INSERT INTO `sys_log` VALUES (554, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:09:17');
INSERT INTO `sys_log` VALUES (555, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:09:47');
INSERT INTO `sys_log` VALUES (556, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:12:12');
INSERT INTO `sys_log` VALUES (557, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:12:47');
INSERT INTO `sys_log` VALUES (558, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:13:19');
INSERT INTO `sys_log` VALUES (559, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:13:50');
INSERT INTO `sys_log` VALUES (560, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:14:09');
INSERT INTO `sys_log` VALUES (561, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:15:39');
INSERT INTO `sys_log` VALUES (562, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:16:59');
INSERT INTO `sys_log` VALUES (563, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:17:33');
INSERT INTO `sys_log` VALUES (564, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:20:46');
INSERT INTO `sys_log` VALUES (565, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=1&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:20:56');
INSERT INTO `sys_log` VALUES (566, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=3&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:24:28');
INSERT INTO `sys_log` VALUES (567, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=27&pageTypeIndex=3&editChildIndex=1&points_sys_id=27', '192.168.56.1', '2020-06-24 11:24:41');
INSERT INTO `sys_log` VALUES (568, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:del,[参数]:id=28', '192.168.56.1', '2020-06-24 11:37:48');
INSERT INTO `sys_log` VALUES (569, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:del,[参数]:id=28', '192.168.56.1', '2020-06-24 11:38:09');
INSERT INTO `sys_log` VALUES (570, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:del,[参数]:id=28', '192.168.56.1', '2020-06-24 11:38:45');
INSERT INTO `sys_log` VALUES (571, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:del,[参数]:id=28', '192.168.56.1', '2020-06-24 11:41:55');
INSERT INTO `sys_log` VALUES (572, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=多啦&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-24 11:43:26');
INSERT INTO `sys_log` VALUES (573, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:43:11');
INSERT INTO `sys_log` VALUES (574, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:43:15');
INSERT INTO `sys_log` VALUES (575, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:43:20');
INSERT INTO `sys_log` VALUES (576, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:43:40');
INSERT INTO `sys_log` VALUES (577, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:43:42');
INSERT INTO `sys_log` VALUES (578, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:44:42');
INSERT INTO `sys_log` VALUES (579, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=1&title=积分乐园&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:48:57');
INSERT INTO `sys_log` VALUES (580, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:49:17');
INSERT INTO `sys_log` VALUES (581, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=首页&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:55:44');
INSERT INTO `sys_log` VALUES (582, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:56:23');
INSERT INTO `sys_log` VALUES (583, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=返回按钮不选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:57:41');
INSERT INTO `sys_log` VALUES (584, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=1&addType=3&title=返回按钮选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-28 15:57:55');
INSERT INTO `sys_log` VALUES (585, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=1&points_sys_id=1', '192.168.56.1', '2020-06-28 16:59:37');
INSERT INTO `sys_log` VALUES (586, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=1&points_sys_id=1', '192.168.56.1', '2020-06-28 17:34:44');
INSERT INTO `sys_log` VALUES (587, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=4&memberType.member_type_id=4&memberType.member_type_name=钻石会员&memberType.member_type_integral=-100&memberType.member_type_online=1', '192.168.56.1', '2020-06-29 09:33:19');
INSERT INTO `sys_log` VALUES (588, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=5&memberType.member_type_id=5&memberType.member_type_name=黄金会员&memberType.member_type_integral=120&memberType.member_type_online=1', '192.168.56.1', '2020-06-29 09:33:32');
INSERT INTO `sys_log` VALUES (589, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=4&memberType.member_type_id=4&memberType.member_type_name=钻石会员&memberType.member_type_integral=400&memberType.member_type_online=1', '192.168.56.1', '2020-06-29 09:33:42');
INSERT INTO `sys_log` VALUES (590, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=5&memberType.member_type_id=5&memberType.member_type_name=黄金会员&memberType.member_type_integral=500&memberType.member_type_online=1', '192.168.56.1', '2020-06-29 09:33:47');
INSERT INTO `sys_log` VALUES (591, '管家', '[用户ID]:1,[控制器]:/memberType,[方法]:edit,[参数]:member_type_id=3&memberType.member_type_id=3&memberType.member_type_name=黄金会员&memberType.member_type_integral=300&memberType.member_type_online=1', '192.168.56.1', '2020-06-29 09:33:55');
INSERT INTO `sys_log` VALUES (592, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=9&pointsHome.points_home_name=哈哈&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=9', '192.168.56.1', '2020-06-29 10:30:09');
INSERT INTO `sys_log` VALUES (593, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=5&pointsHome.points_home_name=123&pointsHome.points_home_sort=12&pointsHome.points_home_online=1&points_home_id=5', '192.168.56.1', '2020-06-29 10:30:18');
INSERT INTO `sys_log` VALUES (594, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=5&pointsHome.points_home_name=123&pointsHome.points_home_sort=3&pointsHome.points_home_online=1&points_home_id=5', '192.168.56.1', '2020-06-29 10:30:23');
INSERT INTO `sys_log` VALUES (595, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=2&pointsHome.points_home_name=123123&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=2', '192.168.56.1', '2020-06-29 11:08:22');
INSERT INTO `sys_log` VALUES (596, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=2&pointsHome.points_home_name=123123&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=2', '192.168.56.1', '2020-06-29 11:08:30');
INSERT INTO `sys_log` VALUES (597, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:add,[参数]:pointsHome.points_home_name=每日签到抽大奖&pointsHome.points_home_sort=4&pointsHome.points_home_online=1', '192.168.56.1', '2020-06-29 11:09:31');
INSERT INTO `sys_log` VALUES (598, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=5&pointsHome.points_home_name=玩家派有奖PK&pointsHome.points_home_sort=3&pointsHome.points_home_online=1&points_home_id=5', '192.168.56.1', '2020-06-29 11:09:51');
INSERT INTO `sys_log` VALUES (599, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=9&pointsHome.points_home_name=会员专享特权福利&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=9', '192.168.56.1', '2020-06-29 11:10:08');
INSERT INTO `sys_log` VALUES (600, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=2&pointsHome.points_home_name=会员积分实物兑奖&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=2', '192.168.56.1', '2020-06-29 11:10:27');
INSERT INTO `sys_log` VALUES (601, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=1&points_sys_id=1', '192.168.56.1', '2020-06-29 14:24:28');
INSERT INTO `sys_log` VALUES (602, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=1&points_sys_id=1', '192.168.56.1', '2020-06-29 14:27:05');
INSERT INTO `sys_log` VALUES (603, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=3&points_sys_id=1', '192.168.56.1', '2020-06-29 14:27:51');
INSERT INTO `sys_log` VALUES (604, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=2&points_sys_id=1', '192.168.56.1', '2020-06-29 14:27:59');
INSERT INTO `sys_log` VALUES (605, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=4&pointsHome.points_home_name=每日签到抽大奖&pointsHome.points_home_sort=4&pointsHome.points_home_online=1&points_home_id=4', '192.168.56.1', '2020-06-29 14:32:50');
INSERT INTO `sys_log` VALUES (606, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=2&pointsHome.points_home_name=玩家派有奖PK&pointsHome.points_home_sort=3&pointsHome.points_home_online=1&points_home_id=2', '192.168.56.1', '2020-06-29 14:33:02');
INSERT INTO `sys_log` VALUES (607, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=3&pointsHome.points_home_name=会员专享特权福利&pointsHome.points_home_sort=2&pointsHome.points_home_online=1&points_home_id=3', '192.168.56.1', '2020-06-29 14:33:12');
INSERT INTO `sys_log` VALUES (608, '管家', '[用户ID]:1,[控制器]:/pointsHome,[方法]:edit,[参数]:pointsHome.points_home_id=1&pointsHome.points_home_name=会员积分实物兑奖&pointsHome.points_home_sort=1&pointsHome.points_home_online=1&points_home_id=1', '192.168.56.1', '2020-06-29 14:33:22');
INSERT INTO `sys_log` VALUES (609, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=1&editChildIndex=2&points_sys_id=1', '192.168.56.1', '2020-06-29 14:35:26');
INSERT INTO `sys_log` VALUES (610, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1&prizeType.prize_type_id=1&prizeType.prize_type_name=积分乐园', '192.168.56.1', '2020-06-29 15:23:55');
INSERT INTO `sys_log` VALUES (611, '管家', '[用户ID]:1,[控制器]:/prizeType,[方法]:edit,[参数]:prize_type_id=1&prizeType.prize_type_id=1&prizeType.prize_type_name=积分乐园奖品', '192.168.56.1', '2020-06-29 15:24:02');
INSERT INTO `sys_log` VALUES (612, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=积分兑奖实物奖品专区&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:27:33');
INSERT INTO `sys_log` VALUES (613, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=2&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:28:16');
INSERT INTO `sys_log` VALUES (614, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=2&addType=3&title=返回按钮未选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:28:56');
INSERT INTO `sys_log` VALUES (615, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=2&addType=3&title=返回按钮选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:29:22');
INSERT INTO `sys_log` VALUES (616, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=2&addType=3&title=兑奖信息按钮未选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:29:53');
INSERT INTO `sys_log` VALUES (617, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=2&addType=3&title=兑奖信息按钮选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-29 15:30:12');
INSERT INTO `sys_log` VALUES (618, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=100&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=2&prize.prize_name=奖品4', '192.168.56.1', '2020-06-29 18:06:08');
INSERT INTO `sys_log` VALUES (619, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=5000&prize.prize_probability=1&prize.prize_sort=3&prize.prize_quantity=20&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=3&prize.prize_name=删除图片测试', '192.168.56.1', '2020-06-29 18:06:19');
INSERT INTO `sys_log` VALUES (620, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=2&editChildIndex=2&points_sys_id=1', '192.168.56.1', '2020-06-30 09:22:26');
INSERT INTO `sys_log` VALUES (621, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:edit,[参数]:pointsSysImg.points_sys_id=1&pageTypeIndex=2&editChildIndex=3&points_sys_id=1', '192.168.56.1', '2020-06-30 09:22:36');
INSERT INTO `sys_log` VALUES (622, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=5000&prize.prize_probability=1&prize.prize_sort=3&prize.prize_quantity=20&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=3&prize.prize_name=删除图片测试', '192.168.56.1', '2020-06-30 09:27:48');
INSERT INTO `sys_log` VALUES (623, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=0&prize.prize_probability=100&prize.prize_sort=3&prize.prize_quantity=0&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=2&prize.prize_name=奖品4', '192.168.56.1', '2020-06-30 09:28:04');
INSERT INTO `sys_log` VALUES (624, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1000&prize.prize_probability=0&prize.prize_sort=1&prize.prize_quantity=2&prize.prize_id=1&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_type_id=1&prize_id=1&prize.prize_name=奖品1', '192.168.56.1', '2020-06-30 09:28:18');
INSERT INTO `sys_log` VALUES (625, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=5000&prize.prize_probability=0&prize.prize_sort=3&prize.prize_quantity=1&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=3&prize.prize_name=Ipai mini', '192.168.56.1', '2020-06-30 09:33:19');
INSERT INTO `sys_log` VALUES (626, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=5000&prize.prize_probability=0&prize.prize_sort=1&prize.prize_quantity=2&prize.prize_id=1&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_type_id=1&prize_id=1&prize.prize_name=IpaiMini', '192.168.56.1', '2020-06-30 09:34:49');
INSERT INTO `sys_log` VALUES (627, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=4000&prize.prize_probability=0&prize.prize_sort=3&prize.prize_quantity=2&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=2&prize.prize_name=华为手机', '192.168.56.1', '2020-06-30 09:35:41');
INSERT INTO `sys_log` VALUES (628, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=3500&prize.prize_probability=0&prize.prize_sort=3&prize.prize_quantity=1&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=3&prize.prize_name=PS4游戏机', '192.168.56.1', '2020-06-30 09:36:20');
INSERT INTO `sys_log` VALUES (629, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=4000&prize.prize_probability=0&prize.prize_sort=2&prize.prize_quantity=2&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=2&prize.prize_name=华为手机', '192.168.56.1', '2020-06-30 09:36:26');
INSERT INTO `sys_log` VALUES (630, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=3&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=漫步者耳机&prize.prize_sort=4&prize.prize_type_id=1&prize.prize_points=3000', '192.168.56.1', '2020-06-30 09:37:00');
INSERT INTO `sys_log` VALUES (631, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=5&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=蓝牙游戏手柄&prize.prize_sort=5&prize.prize_type_id=1&prize.prize_points=2500', '192.168.56.1', '2020-06-30 09:37:45');
INSERT INTO `sys_log` VALUES (632, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=5&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=游戏鼠标&prize.prize_sort=6&prize.prize_type_id=1&prize.prize_points=2000', '192.168.56.1', '2020-06-30 09:38:22');
INSERT INTO `sys_log` VALUES (633, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=6&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=小米智能音响&prize.prize_sort=7&prize.prize_type_id=1&prize.prize_points=1500', '192.168.56.1', '2020-06-30 09:39:31');
INSERT INTO `sys_log` VALUES (634, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=10&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=迪士尼彩笔&prize.prize_sort=8&prize.prize_type_id=1&prize.prize_points=1000', '192.168.56.1', '2020-06-30 09:40:42');
INSERT INTO `sys_log` VALUES (635, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=10&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=百科全书&prize.prize_sort=9&prize.prize_type_id=1&prize.prize_points=800', '192.168.56.1', '2020-06-30 09:41:28');
INSERT INTO `sys_log` VALUES (636, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=15&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=动漫卡通拼图&prize.prize_sort=10&prize.prize_type_id=1&prize.prize_points=600', '192.168.56.1', '2020-06-30 09:42:26');
INSERT INTO `sys_log` VALUES (637, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=20&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=奥特曼文具套装&prize.prize_sort=11&prize.prize_type_id=1&prize.prize_points=500', '192.168.56.1', '2020-06-30 09:43:05');
INSERT INTO `sys_log` VALUES (638, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=20&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=熊出没玩具&prize.prize_sort=12&prize.prize_type_id=1&prize.prize_points=400', '192.168.56.1', '2020-06-30 09:43:41');
INSERT INTO `sys_log` VALUES (639, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:add,[参数]:prize.prize_quantity=30&prize.prize_probability=0&prize.prize_remarks=&prize.prize_online=1&prize.prize_name=猪猪侠玩具&prize.prize_sort=13&prize.prize_type_id=1&prize.prize_points=200', '192.168.56.1', '2020-06-30 09:44:32');
INSERT INTO `sys_log` VALUES (640, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=200&prize.prize_probability=0&prize.prize_sort=13&prize.prize_quantity=30&prize.prize_id=13&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=13&prize.prize_name=猪猪侠玩具', '192.168.56.1', '2020-06-30 10:11:25');
INSERT INTO `sys_log` VALUES (641, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=5000&prize.prize_probability=0&prize.prize_sort=1&prize.prize_quantity=2&prize.prize_id=1&prize.prize_remarks=奖品描述&prize.prize_online=1&prize.prize_type_id=1&prize_id=1&prize.prize_name=IpaiMini', '192.168.56.1', '2020-06-30 16:44:39');
INSERT INTO `sys_log` VALUES (642, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=4000&prize.prize_probability=0&prize.prize_sort=2&prize.prize_quantity=2&prize.prize_id=2&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=2&prize.prize_name=华为手机', '192.168.56.1', '2020-06-30 16:45:50');
INSERT INTO `sys_log` VALUES (643, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=3500&prize.prize_probability=0&prize.prize_sort=3&prize.prize_quantity=1&prize.prize_id=3&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=3&prize.prize_name=PS4游戏机', '192.168.56.1', '2020-06-30 16:45:58');
INSERT INTO `sys_log` VALUES (644, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=3000&prize.prize_probability=0&prize.prize_sort=4&prize.prize_quantity=3&prize.prize_id=4&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=4&prize.prize_name=漫步者耳机', '192.168.56.1', '2020-06-30 16:46:04');
INSERT INTO `sys_log` VALUES (645, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=2500&prize.prize_probability=0&prize.prize_sort=5&prize.prize_quantity=5&prize.prize_id=5&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=5&prize.prize_name=蓝牙游戏手柄', '192.168.56.1', '2020-06-30 16:46:56');
INSERT INTO `sys_log` VALUES (646, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=2000&prize.prize_probability=0&prize.prize_sort=6&prize.prize_quantity=5&prize.prize_id=6&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=6&prize.prize_name=游戏鼠标', '192.168.56.1', '2020-06-30 16:47:03');
INSERT INTO `sys_log` VALUES (647, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1500&prize.prize_probability=0&prize.prize_sort=7&prize.prize_quantity=6&prize.prize_id=7&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=7&prize.prize_name=小米智能音响', '192.168.56.1', '2020-06-30 16:47:11');
INSERT INTO `sys_log` VALUES (648, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=1000&prize.prize_probability=0&prize.prize_sort=8&prize.prize_quantity=10&prize.prize_id=8&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=8&prize.prize_name=迪士尼彩笔', '192.168.56.1', '2020-06-30 16:47:19');
INSERT INTO `sys_log` VALUES (649, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=800&prize.prize_probability=0&prize.prize_sort=9&prize.prize_quantity=10&prize.prize_id=9&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=9&prize.prize_name=百科全书', '192.168.56.1', '2020-06-30 16:47:26');
INSERT INTO `sys_log` VALUES (650, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=600&prize.prize_probability=0&prize.prize_sort=10&prize.prize_quantity=15&prize.prize_id=10&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=10&prize.prize_name=动漫卡通拼图', '192.168.56.1', '2020-06-30 16:47:32');
INSERT INTO `sys_log` VALUES (651, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=500&prize.prize_probability=0&prize.prize_sort=11&prize.prize_quantity=20&prize.prize_id=11&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=11&prize.prize_name=奥特曼文具套装', '192.168.56.1', '2020-06-30 16:47:38');
INSERT INTO `sys_log` VALUES (652, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=400&prize.prize_probability=0&prize.prize_sort=12&prize.prize_quantity=20&prize.prize_id=12&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=12&prize.prize_name=熊出没玩具', '192.168.56.1', '2020-06-30 16:47:44');
INSERT INTO `sys_log` VALUES (653, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=200&prize.prize_probability=0&prize.prize_sort=13&prize.prize_quantity=30&prize.prize_id=13&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=13&prize.prize_name=猪猪侠玩具', '192.168.56.1', '2020-06-30 16:47:51');
INSERT INTO `sys_log` VALUES (654, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=200&prize.prize_probability=0&prize.prize_sort=13&prize.prize_quantity=30&prize.prize_id=13&prize.prize_remarks=&prize.prize_online=0&prize.prize_type_id=1&prize_id=13&prize.prize_name=猪猪侠玩具', '192.168.56.1', '2020-06-30 17:08:38');
INSERT INTO `sys_log` VALUES (655, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=200&prize.prize_probability=0&prize.prize_sort=13&prize.prize_quantity=30&prize.prize_id=13&prize.prize_remarks=&prize.prize_online=1&prize.prize_type_id=1&prize_id=13&prize.prize_name=猪猪侠玩具', '192.168.56.1', '2020-06-30 17:10:03');
INSERT INTO `sys_log` VALUES (656, '管家', '[用户ID]:1,[控制器]:/prize,[方法]:edit,[参数]:prize.prize_points=200&prize.prize_probability=0&prize.prize_sort=13&prize.prize_quantity=30&prize.prize_id=13&prize.prize_remarks=&prize.prize_online=0&prize.prize_type_id=1&prize_id=13&prize.prize_name=猪猪侠玩具', '192.168.56.1', '2020-06-30 17:15:53');
INSERT INTO `sys_log` VALUES (657, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=&addType=2&title=规则页面&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-30 18:08:50');
INSERT INTO `sys_log` VALUES (658, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=3&addType=3&title=背景图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-30 18:11:00');
INSERT INTO `sys_log` VALUES (659, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=3&addType=3&title=返回按钮未选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-30 18:11:21');
INSERT INTO `sys_log` VALUES (660, '管家', '[用户ID]:1,[控制器]:/pointsSysImg,[方法]:add,[参数]:pageType=3&addType=3&title=返回按钮选中图&pointsSysImg.points_sys_type_id=1', '192.168.56.1', '2020-06-30 18:11:44');

-- ----------------------------
-- Table structure for sys_resource
-- ----------------------------
DROP TABLE IF EXISTS `sys_resource`;
CREATE TABLE `sys_resource`  (
  `res_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `res_pid` int(11) NULL DEFAULT NULL COMMENT '父ID',
  `res_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源名称',
  `res_icon` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '资源图标',
  `res_url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源地址',
  `res_note` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '资源备注',
  `res_open_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '打开方式:ajax,iframe',
  `res_resource_type` tinyint(2) NOT NULL COMMENT '资源类型，0选项卡，1按钮，2栏目，3资源',
  `res_status` tinyint(2) NOT NULL DEFAULT 1 COMMENT '资源状态，0下线，1上线',
  `res_sort` int(11) NULL DEFAULT NULL COMMENT '排序',
  `res_create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`res_id`) USING BTREE,
  INDEX `res_id_index`(`res_id`) USING BTREE COMMENT '资源ID索引',
  INDEX `res_resource_type_index`(`res_resource_type`) USING BTREE COMMENT '资源类型索引'
) ENGINE = InnoDB AUTO_INCREMENT = 105 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '资源表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_resource
-- ----------------------------
INSERT INTO `sys_resource` VALUES (1, NULL, '系统设置', 'pic_25', '/', NULL, 'iframe', 2, 1, 0, '2017-06-09 14:57:51');
INSERT INTO `sys_resource` VALUES (2, 1, '资源管理', NULL, '/resource/index', NULL, 'iframe', 0, 1, 1, '2017-06-09 15:01:54');
INSERT INTO `sys_resource` VALUES (3, 2, '新增', 'pic_439', '/resource/add', '资源新增', 'ajax', 1, 1, 2, '2017-06-09 15:03:50');
INSERT INTO `sys_resource` VALUES (4, 2, '修改', 'pic_439', '/resource/edit', '资源修改', 'ajax', 1, 1, 3, '2017-06-09 15:04:24');
INSERT INTO `sys_resource` VALUES (5, 2, '删除', 'pic_439', '/resource/del', '资源删除', 'ajax', 1, 1, 4, '2017-06-09 15:06:09');
INSERT INTO `sys_resource` VALUES (6, 1, '角色管理', NULL, '/sysRole/index', NULL, 'iframe', 0, 1, 1, '2017-06-09 15:07:23');
INSERT INTO `sys_resource` VALUES (7, 6, '新增', 'pic_439', '/sysRole/add', '角色新增', 'ajax', 1, 1, 2, '2017-06-09 15:08:42');
INSERT INTO `sys_resource` VALUES (8, 6, '修改', 'pic_439', '/sysRole/edit', '角色修改', 'ajax', 1, 1, 3, '2017-06-09 15:11:52');
INSERT INTO `sys_resource` VALUES (9, 6, '删除', 'pic_439', '/sysRole/del', '角色删除', 'ajax', 1, 1, 4, '2017-06-09 15:12:28');
INSERT INTO `sys_resource` VALUES (10, 6, '授权', 'pic_439', '/sysRole/auth', '角色权限管理', 'ajax', 1, 1, 5, '2017-06-09 15:13:21');
INSERT INTO `sys_resource` VALUES (11, 6, '获取角色资源列表', 'pic_381', '/sysRole/getRoleAuth', '资源接口', 'ajax', 3, 1, 6, '2017-06-09 15:13:21');
INSERT INTO `sys_resource` VALUES (12, 6, '获取角色列表', 'pic_381', '/sysRole/getRoleList', '角色接口', 'ajax', 3, 1, 7, '2017-06-09 15:13:21');
INSERT INTO `sys_resource` VALUES (13, 1, '用户管理', NULL, '/sysUser/index', NULL, 'iframe', 0, 1, 1, '2017-06-09 15:15:42');
INSERT INTO `sys_resource` VALUES (14, 13, '新增', 'pic_439', '/sysUser/add', '用户新增', 'ajax', 1, 1, 2, '2017-06-09 15:16:18');
INSERT INTO `sys_resource` VALUES (15, 13, '修改', 'pic_439', '/sysUser/edit', '用户修改', 'ajax', 1, 1, 3, '2017-06-09 15:16:38');
INSERT INTO `sys_resource` VALUES (16, 13, '删除', 'pic_439', '/sysUser/del', '用户删除', 'ajax', 1, 1, 4, '2017-06-09 15:16:56');
INSERT INTO `sys_resource` VALUES (17, 1, '系统日志', NULL, '/sysLog/index', NULL, NULL, 0, 1, 0, '2017-07-01 16:36:58');
INSERT INTO `sys_resource` VALUES (18, 17, '查看', 'pic_439', '/sysLog/info', '查看系统日志', NULL, 1, 1, 1, '2017-07-01 17:35:00');
INSERT INTO `sys_resource` VALUES (19, NULL, '平台内容管理', 'pic_25', '/', NULL, NULL, 2, 1, 1, '2017-07-06 10:53:44');
INSERT INTO `sys_resource` VALUES (20, 19, '积分首页管理', NULL, '/', NULL, NULL, 0, 1, 3, '2020-05-14 17:37:56');
INSERT INTO `sys_resource` VALUES (21, 20, '首页管理', NULL, '/pointsHome/index', NULL, NULL, 0, 1, 1, '2020-05-14 17:39:20');
INSERT INTO `sys_resource` VALUES (22, 21, '获取数据', 'pic_381', '/pointsHome/index', '获取数据', NULL, 3, 1, 3, '2020-05-14 17:53:58');
INSERT INTO `sys_resource` VALUES (23, 21, '新增', 'pic_439', '/pointsHome/add', '新增资源', NULL, 1, 1, 1, '2020-05-15 10:56:25');
INSERT INTO `sys_resource` VALUES (24, 21, '编辑', 'pic_439', '/pointsHome/edit', '资源编辑', NULL, 1, 1, 3, '2020-05-15 10:56:44');
INSERT INTO `sys_resource` VALUES (25, 21, '删除', 'pic_439', '/pointsHome/del', '资源删除', NULL, 1, 1, 4, '2020-05-15 10:57:41');
INSERT INTO `sys_resource` VALUES (27, 1, '数据库监控', NULL, '/druid/index', NULL, NULL, 0, 1, 0, '2017-08-15 15:50:31');
INSERT INTO `sys_resource` VALUES (28, 1, '系统配置', '', '/sysSetting/index', NULL, NULL, 0, 1, 1, '2017-08-22 18:05:34');
INSERT INTO `sys_resource` VALUES (29, 28, '编辑', 'pic_439', '/sysSetting/edit', NULL, NULL, 1, 1, 1, '2017-08-22 18:39:34');
INSERT INTO `sys_resource` VALUES (30, 19, '会员管理', NULL, '/', NULL, NULL, 0, 1, 2, '2020-05-18 10:55:54');
INSERT INTO `sys_resource` VALUES (31, 30, '会员类型管理', NULL, '/memberType/index', NULL, NULL, 0, 1, 1, '2020-05-18 10:57:30');
INSERT INTO `sys_resource` VALUES (32, 31, '添加', 'pic_439', '/memberType/add', '资源添加', NULL, 1, 1, 1, '2020-05-18 11:07:14');
INSERT INTO `sys_resource` VALUES (33, 31, '编辑', 'pic_439', '/memberType/edit', '资源编辑', NULL, 1, 1, 2, '2020-05-18 11:07:44');
INSERT INTO `sys_resource` VALUES (34, 31, '删除', 'pic_439', '/memberType/del', '资源删除', NULL, 1, 1, 3, '2020-05-18 11:08:13');
INSERT INTO `sys_resource` VALUES (35, 30, '会员专享福利特权专区', NULL, '/memberArea/index', '专区', NULL, 0, 1, 1, '2020-05-18 15:03:12');
INSERT INTO `sys_resource` VALUES (36, 35, '新增', 'pic_439', '/memberArea/add', '添加数据', NULL, 1, 1, 1, '2020-05-18 15:04:21');
INSERT INTO `sys_resource` VALUES (37, 35, '编辑', 'pic_439', '/memberArea/edit', '资源编辑', NULL, 1, 1, 2, '2020-05-18 15:04:46');
INSERT INTO `sys_resource` VALUES (38, 35, '删除', 'pic_439', '/memberArea/del', '删除资源', NULL, 1, 1, 3, '2020-05-18 15:05:04');
INSERT INTO `sys_resource` VALUES (39, 19, 'PK管理', NULL, '/', NULL, NULL, 0, 1, 4, '2020-05-19 14:58:03');
INSERT INTO `sys_resource` VALUES (40, 39, 'PK管理', NULL, '/playerKilling/index', 'PK结果表', NULL, 0, 1, 1, '2020-05-19 14:58:42');
INSERT INTO `sys_resource` VALUES (41, 40, '新增', 'pic_439', '/playerKilling/add', '添加资源', NULL, 1, 1, 1, '2020-05-19 14:59:25');
INSERT INTO `sys_resource` VALUES (42, 40, '编辑', 'pic_439', '/playerKilling/edit', '编辑资源', NULL, 1, 1, 2, '2020-05-19 14:59:41');
INSERT INTO `sys_resource` VALUES (43, 40, '删除', 'pic_439', '/playerKilling/del', '资源删除', NULL, 1, 1, 3, '2020-05-19 15:00:00');
INSERT INTO `sys_resource` VALUES (44, 39, 'PK投票用户管理', NULL, '/playerKillingUser/index', NULL, NULL, 0, 1, 2, '2020-05-20 14:11:15');
INSERT INTO `sys_resource` VALUES (45, 44, '删除', 'pic_439', '/playerKillingUser/del', '删除资源', NULL, 1, 1, 1, '2020-05-20 14:11:38');
INSERT INTO `sys_resource` VALUES (46, 44, '编辑', 'pic_439', '/playerKillingUser/edit', '编辑资源', NULL, 1, 1, 2, '2020-05-20 14:12:14');
INSERT INTO `sys_resource` VALUES (47, 44, '添加', 'pic_439', '/playerKillingUser/add', '资源添加', NULL, 1, 1, 3, '2020-05-20 14:12:54');
INSERT INTO `sys_resource` VALUES (48, 44, '获取PK类型', 'pic_381', '/playerKilling/getPlayerKillingList', '获取PK类型', NULL, 3, 1, 4, '2020-05-20 15:14:19');
INSERT INTO `sys_resource` VALUES (49, 19, '签到管理', NULL, '/', '签到栏目', NULL, 0, 1, 5, '2020-05-21 13:52:39');
INSERT INTO `sys_resource` VALUES (50, 49, '签到管理', NULL, '/signPoints/index', '签到积分', NULL, 0, 1, 1, '2020-05-21 13:53:23');
INSERT INTO `sys_resource` VALUES (51, 50, '新增', 'pic_439', '/signPoints/add', '新增', NULL, 1, 1, 1, '2020-05-21 13:59:23');
INSERT INTO `sys_resource` VALUES (52, 50, '编辑', 'pic_439', '/signPoints/edit', '资源修改', NULL, 1, 1, 2, '2020-05-21 14:01:37');
INSERT INTO `sys_resource` VALUES (53, 50, '删除', 'pic_439', '/signPoints/del', '删除资源', NULL, 1, 1, 3, '2020-05-21 14:01:57');
INSERT INTO `sys_resource` VALUES (54, 19, '奖品管理', NULL, '/', '奖品,奖品类型管理中心', NULL, 0, 1, 1, '2020-05-22 10:08:25');
INSERT INTO `sys_resource` VALUES (55, 54, '奖品类型管理', NULL, '/prizeType/index', NULL, NULL, 0, 1, 1, '2020-05-22 10:28:40');
INSERT INTO `sys_resource` VALUES (56, 54, '奖品管理', NULL, '/prize/index', '奖品管理', NULL, 0, 1, 2, '2020-05-22 10:29:17');
INSERT INTO `sys_resource` VALUES (57, 55, '新增', 'pic_439', '/prizeType/add', '添加数据', NULL, 1, 1, 1, '2020-05-22 10:29:53');
INSERT INTO `sys_resource` VALUES (58, 55, '编辑', 'pic_439', '/prizeType/edit', '数据修改', NULL, 1, 1, 2, '2020-05-22 10:30:11');
INSERT INTO `sys_resource` VALUES (59, 55, '删除', 'pic_439', '/prizeType/del', '删除', NULL, 1, 1, 3, '2020-05-22 10:30:33');
INSERT INTO `sys_resource` VALUES (60, 56, '添加', 'pic_439', '/prize/add', '奖品添加', NULL, 1, 1, 1, '2020-05-22 10:30:56');
INSERT INTO `sys_resource` VALUES (61, 56, '编辑', 'pic_439', '/prize/edit', '修改数据', NULL, 1, 1, 2, '2020-05-22 10:31:17');
INSERT INTO `sys_resource` VALUES (62, 56, '删除', 'pic_439', '/prize/del', '数据删除', NULL, 1, 1, 3, '2020-05-22 10:31:44');
INSERT INTO `sys_resource` VALUES (63, 55, '获取全部奖品类型', 'pic_381', '/prizeType/getPrizeTypeList', '获取全部奖品类型', NULL, 3, 1, 1, '2020-05-22 10:32:50');
INSERT INTO `sys_resource` VALUES (64, 19, '用户管理', NULL, '/', NULL, NULL, 0, 1, 6, '2020-06-04 09:52:29');
INSERT INTO `sys_resource` VALUES (65, 64, '积分用户', NULL, '/user/index', NULL, NULL, 0, 1, 1, '2020-06-04 09:54:14');
INSERT INTO `sys_resource` VALUES (66, 65, '添加', 'pic_439', '/user/add', '添加用户', NULL, 1, 1, 1, '2020-06-04 09:54:45');
INSERT INTO `sys_resource` VALUES (67, 65, '编辑', 'pic_439', '/user/edit', '编辑用户', NULL, 1, 1, 2, '2020-06-04 09:55:06');
INSERT INTO `sys_resource` VALUES (68, 65, '删除', 'pic_439', '/user/del', '删除用户', NULL, 1, 1, 3, '2020-06-04 09:55:26');
INSERT INTO `sys_resource` VALUES (69, 65, '获取全部上线奖品', 'pic_381', '/prize/getPrizeList', NULL, NULL, 3, 1, 1, '2020-06-04 11:12:05');
INSERT INTO `sys_resource` VALUES (70, 19, '游戏管理', NULL, '/', NULL, NULL, 0, 1, 7, '2020-06-08 09:34:46');
INSERT INTO `sys_resource` VALUES (71, 70, '游戏类型管理', NULL, '/gameType/index', NULL, NULL, 0, 1, 1, '2020-06-08 09:35:23');
INSERT INTO `sys_resource` VALUES (72, 71, '新增', 'pic_439', '/gameType/add', NULL, NULL, 1, 1, 1, '2020-06-08 09:35:51');
INSERT INTO `sys_resource` VALUES (73, 71, '修改', 'pic_439', '/gameType/edit', NULL, NULL, 1, 1, 2, '2020-06-08 09:36:07');
INSERT INTO `sys_resource` VALUES (74, 71, '删除', 'pic_439', '/gameType/del', NULL, NULL, 1, 1, 3, '2020-06-08 09:36:21');
INSERT INTO `sys_resource` VALUES (75, 71, '获取游戏类型数据', 'pic_381', '/gameType/getAllGameTypes', NULL, NULL, 3, 1, 1, '2020-06-08 09:36:56');
INSERT INTO `sys_resource` VALUES (76, 70, '游戏管理', NULL, '/game/index', NULL, NULL, 0, 1, 2, '2020-06-08 09:47:57');
INSERT INTO `sys_resource` VALUES (77, 76, '新增', 'pic_439', '/game/add', NULL, NULL, 1, 1, 1, '2020-06-08 09:48:18');
INSERT INTO `sys_resource` VALUES (78, 76, '编辑', 'pic_439', '/game/edit', NULL, NULL, 1, 1, 2, '2020-06-08 09:48:33');
INSERT INTO `sys_resource` VALUES (79, 76, '删除', 'pic_439', '/game/del', NULL, NULL, 1, 1, 3, '2020-06-08 09:48:47');
INSERT INTO `sys_resource` VALUES (80, 76, '获取游戏类型资源', 'pic_381', '/gameType/getAllGameTypes', NULL, NULL, 3, 1, 4, '2020-06-08 09:49:18');
INSERT INTO `sys_resource` VALUES (81, 19, '拦截管理', NULL, '/', NULL, NULL, 0, 1, 1, '2020-06-08 14:33:14');
INSERT INTO `sys_resource` VALUES (82, 81, '拦截管理', NULL, '/intercept/index', '专区拦截功能', NULL, 0, 1, 1, '2020-06-08 14:33:36');
INSERT INTO `sys_resource` VALUES (83, 81, '拦截类型管理', NULL, '/interceptType/index', '专区拦截类型：首页，退出', NULL, 0, 1, 2, '2020-06-08 14:34:18');
INSERT INTO `sys_resource` VALUES (84, 83, '添加', 'pic_439', '/interceptType/add', NULL, NULL, 1, 1, 1, '2020-06-08 14:34:48');
INSERT INTO `sys_resource` VALUES (85, 83, '编辑', 'pic_439', '/interceptType/edit', NULL, NULL, 1, 1, 2, '2020-06-08 14:35:07');
INSERT INTO `sys_resource` VALUES (86, 83, '删除', 'pic_439', '/interceptType/del', NULL, NULL, 1, 1, 3, '2020-06-08 14:35:26');
INSERT INTO `sys_resource` VALUES (87, 83, '获取全部拦截类型', 'pic_381', '/interceptType/getInterceptTypeList', NULL, NULL, 3, 1, 1, '2020-06-08 14:36:05');
INSERT INTO `sys_resource` VALUES (88, 82, '新增', 'pic_439', '/intercept/add', NULL, NULL, 1, 1, 1, '2020-06-08 14:36:34');
INSERT INTO `sys_resource` VALUES (89, 82, '编辑', 'pic_439', '/intercept/edit', NULL, NULL, 1, 1, 2, '2020-06-08 14:36:54');
INSERT INTO `sys_resource` VALUES (90, 82, '删除', 'pic_439', '/intercept/del', NULL, NULL, 1, 1, 3, '2020-06-08 14:37:11');
INSERT INTO `sys_resource` VALUES (91, 19, '系统管理', NULL, '/', '积分系统管理，活动系统管理等', NULL, 0, 1, 1, '2020-06-15 15:13:59');
INSERT INTO `sys_resource` VALUES (92, 91, '系统类型管理', NULL, '/pointsSysType/index', NULL, NULL, 0, 1, 1, '2020-06-15 15:14:20');
INSERT INTO `sys_resource` VALUES (93, 92, '添加', 'pic_439', '/pointsSysType/add', NULL, NULL, 1, 1, 1, '2020-06-15 15:14:37');
INSERT INTO `sys_resource` VALUES (94, 92, '编辑', 'pic_439', '/pointsSysType/edit', NULL, NULL, 1, 1, 2, '2020-06-15 15:14:55');
INSERT INTO `sys_resource` VALUES (95, 92, '删除', 'pic_439', '/pointsSysType/del', NULL, NULL, 1, 1, 3, '2020-06-15 15:15:09');
INSERT INTO `sys_resource` VALUES (96, 91, '系统图片管理', NULL, '/pointsSysImg/index', NULL, NULL, 0, 1, 2, '2020-06-15 18:14:21');
INSERT INTO `sys_resource` VALUES (97, 96, '添加', 'pic_439', '/pointsSysImg/add', NULL, NULL, 1, 1, 1, '2020-06-15 18:14:53');
INSERT INTO `sys_resource` VALUES (98, 96, '编辑', 'pic_439', '/pointsSysImg/edit', NULL, NULL, 1, 1, 2, '2020-06-15 18:15:10');
INSERT INTO `sys_resource` VALUES (99, 96, '删除', 'pic_439', '/pointsSysImg/del', NULL, NULL, 1, 1, 3, '2020-06-15 18:15:30');
INSERT INTO `sys_resource` VALUES (100, 96, '获取系统类型', 'pic_381', '/pointsSysType/getPointsSysTypeList', NULL, NULL, 3, 1, 1, '2020-06-15 18:18:29');
INSERT INTO `sys_resource` VALUES (101, 92, '获取全部类型', 'pic_381', '/pointsSysType/getPointsSysTypeList', NULL, NULL, 3, 0, 1, '2020-06-16 09:16:47');
INSERT INTO `sys_resource` VALUES (102, 96, '获取字段中的json数据', 'pic_381', '/pointsSysImg/getPointsSysPageType', NULL, NULL, 3, 1, 2, '2020-06-18 10:50:07');
INSERT INTO `sys_resource` VALUES (104, 96, '根据iD获取资源', 'pic_381', '/pointsSysImg/getPointsSysImgJson', NULL, NULL, 3, 1, 2, '2020-06-24 09:57:18');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `sysr_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `sysr_name` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT ' 角色名',
  `sysr_note` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `sysr_add_time` datetime NULL DEFAULT '1970-01-01 00:00:00' COMMENT '角色添加时间',
  PRIMARY KEY (`sysr_id`) USING BTREE,
  INDEX `sysr_name_index`(`sysr_name`) USING BTREE COMMENT '角色名索引'
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', '所有权限', '2017-06-09 14:54:36');
INSERT INTO `sys_role` VALUES (2, '运营角色', '部分权限', '2018-08-03 17:25:05');

-- ----------------------------
-- Table structure for sys_role_resource
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_resource`;
CREATE TABLE `sys_role_resource`  (
  `rores_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `rores_roleid` int(11) NULL DEFAULT NULL COMMENT '角色ID',
  `rores_resid` int(11) NULL DEFAULT NULL COMMENT '资源ID',
  PRIMARY KEY (`rores_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1519 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '角色，资源中间表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_role_resource
-- ----------------------------
INSERT INTO `sys_role_resource` VALUES (1417, 1, 19);
INSERT INTO `sys_role_resource` VALUES (1418, 1, 70);
INSERT INTO `sys_role_resource` VALUES (1419, 1, 76);
INSERT INTO `sys_role_resource` VALUES (1420, 1, 80);
INSERT INTO `sys_role_resource` VALUES (1421, 1, 79);
INSERT INTO `sys_role_resource` VALUES (1422, 1, 78);
INSERT INTO `sys_role_resource` VALUES (1423, 1, 77);
INSERT INTO `sys_role_resource` VALUES (1424, 1, 71);
INSERT INTO `sys_role_resource` VALUES (1425, 1, 74);
INSERT INTO `sys_role_resource` VALUES (1426, 1, 73);
INSERT INTO `sys_role_resource` VALUES (1427, 1, 72);
INSERT INTO `sys_role_resource` VALUES (1428, 1, 75);
INSERT INTO `sys_role_resource` VALUES (1429, 1, 64);
INSERT INTO `sys_role_resource` VALUES (1430, 1, 65);
INSERT INTO `sys_role_resource` VALUES (1431, 1, 68);
INSERT INTO `sys_role_resource` VALUES (1432, 1, 67);
INSERT INTO `sys_role_resource` VALUES (1433, 1, 66);
INSERT INTO `sys_role_resource` VALUES (1434, 1, 69);
INSERT INTO `sys_role_resource` VALUES (1435, 1, 49);
INSERT INTO `sys_role_resource` VALUES (1436, 1, 50);
INSERT INTO `sys_role_resource` VALUES (1437, 1, 53);
INSERT INTO `sys_role_resource` VALUES (1438, 1, 52);
INSERT INTO `sys_role_resource` VALUES (1439, 1, 51);
INSERT INTO `sys_role_resource` VALUES (1440, 1, 39);
INSERT INTO `sys_role_resource` VALUES (1441, 1, 44);
INSERT INTO `sys_role_resource` VALUES (1442, 1, 48);
INSERT INTO `sys_role_resource` VALUES (1443, 1, 47);
INSERT INTO `sys_role_resource` VALUES (1444, 1, 46);
INSERT INTO `sys_role_resource` VALUES (1445, 1, 45);
INSERT INTO `sys_role_resource` VALUES (1446, 1, 40);
INSERT INTO `sys_role_resource` VALUES (1447, 1, 43);
INSERT INTO `sys_role_resource` VALUES (1448, 1, 42);
INSERT INTO `sys_role_resource` VALUES (1449, 1, 41);
INSERT INTO `sys_role_resource` VALUES (1450, 1, 20);
INSERT INTO `sys_role_resource` VALUES (1451, 1, 21);
INSERT INTO `sys_role_resource` VALUES (1452, 1, 25);
INSERT INTO `sys_role_resource` VALUES (1453, 1, 22);
INSERT INTO `sys_role_resource` VALUES (1454, 1, 24);
INSERT INTO `sys_role_resource` VALUES (1455, 1, 23);
INSERT INTO `sys_role_resource` VALUES (1456, 1, 30);
INSERT INTO `sys_role_resource` VALUES (1457, 1, 31);
INSERT INTO `sys_role_resource` VALUES (1458, 1, 34);
INSERT INTO `sys_role_resource` VALUES (1459, 1, 33);
INSERT INTO `sys_role_resource` VALUES (1460, 1, 32);
INSERT INTO `sys_role_resource` VALUES (1461, 1, 35);
INSERT INTO `sys_role_resource` VALUES (1462, 1, 38);
INSERT INTO `sys_role_resource` VALUES (1463, 1, 37);
INSERT INTO `sys_role_resource` VALUES (1464, 1, 36);
INSERT INTO `sys_role_resource` VALUES (1465, 1, 54);
INSERT INTO `sys_role_resource` VALUES (1466, 1, 56);
INSERT INTO `sys_role_resource` VALUES (1467, 1, 62);
INSERT INTO `sys_role_resource` VALUES (1468, 1, 61);
INSERT INTO `sys_role_resource` VALUES (1469, 1, 60);
INSERT INTO `sys_role_resource` VALUES (1470, 1, 55);
INSERT INTO `sys_role_resource` VALUES (1471, 1, 59);
INSERT INTO `sys_role_resource` VALUES (1472, 1, 58);
INSERT INTO `sys_role_resource` VALUES (1473, 1, 57);
INSERT INTO `sys_role_resource` VALUES (1474, 1, 63);
INSERT INTO `sys_role_resource` VALUES (1475, 1, 81);
INSERT INTO `sys_role_resource` VALUES (1476, 1, 83);
INSERT INTO `sys_role_resource` VALUES (1477, 1, 86);
INSERT INTO `sys_role_resource` VALUES (1478, 1, 85);
INSERT INTO `sys_role_resource` VALUES (1479, 1, 84);
INSERT INTO `sys_role_resource` VALUES (1480, 1, 87);
INSERT INTO `sys_role_resource` VALUES (1481, 1, 82);
INSERT INTO `sys_role_resource` VALUES (1482, 1, 90);
INSERT INTO `sys_role_resource` VALUES (1483, 1, 89);
INSERT INTO `sys_role_resource` VALUES (1484, 1, 88);
INSERT INTO `sys_role_resource` VALUES (1485, 1, 91);
INSERT INTO `sys_role_resource` VALUES (1486, 1, 96);
INSERT INTO `sys_role_resource` VALUES (1487, 1, 99);
INSERT INTO `sys_role_resource` VALUES (1488, 1, 98);
INSERT INTO `sys_role_resource` VALUES (1489, 1, 102);
INSERT INTO `sys_role_resource` VALUES (1490, 1, 104);
INSERT INTO `sys_role_resource` VALUES (1491, 1, 97);
INSERT INTO `sys_role_resource` VALUES (1492, 1, 100);
INSERT INTO `sys_role_resource` VALUES (1493, 1, 92);
INSERT INTO `sys_role_resource` VALUES (1494, 1, 95);
INSERT INTO `sys_role_resource` VALUES (1495, 1, 94);
INSERT INTO `sys_role_resource` VALUES (1496, 1, 93);
INSERT INTO `sys_role_resource` VALUES (1497, 1, 101);
INSERT INTO `sys_role_resource` VALUES (1498, 1, 1);
INSERT INTO `sys_role_resource` VALUES (1499, 1, 2);
INSERT INTO `sys_role_resource` VALUES (1500, 1, 5);
INSERT INTO `sys_role_resource` VALUES (1501, 1, 4);
INSERT INTO `sys_role_resource` VALUES (1502, 1, 3);
INSERT INTO `sys_role_resource` VALUES (1503, 1, 6);
INSERT INTO `sys_role_resource` VALUES (1504, 1, 12);
INSERT INTO `sys_role_resource` VALUES (1505, 1, 11);
INSERT INTO `sys_role_resource` VALUES (1506, 1, 10);
INSERT INTO `sys_role_resource` VALUES (1507, 1, 9);
INSERT INTO `sys_role_resource` VALUES (1508, 1, 8);
INSERT INTO `sys_role_resource` VALUES (1509, 1, 7);
INSERT INTO `sys_role_resource` VALUES (1510, 1, 13);
INSERT INTO `sys_role_resource` VALUES (1511, 1, 16);
INSERT INTO `sys_role_resource` VALUES (1512, 1, 15);
INSERT INTO `sys_role_resource` VALUES (1513, 1, 14);
INSERT INTO `sys_role_resource` VALUES (1514, 1, 28);
INSERT INTO `sys_role_resource` VALUES (1515, 1, 29);
INSERT INTO `sys_role_resource` VALUES (1516, 1, 17);
INSERT INTO `sys_role_resource` VALUES (1517, 1, 18);
INSERT INTO `sys_role_resource` VALUES (1518, 1, 27);

-- ----------------------------
-- Table structure for sys_setting
-- ----------------------------
DROP TABLE IF EXISTS `sys_setting`;
CREATE TABLE `sys_setting`  (
  `set_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `set_title` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '系统标题',
  `set_url` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '资源URL',
  `set_upload` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '上传路径',
  `set_tm_upload` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'tomcat上传路径',
  `set_publickey` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'rsa公钥',
  `set_privatekey` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'ras私钥',
  PRIMARY KEY (`set_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统设置表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_setting
-- ----------------------------
INSERT INTO `sys_setting` VALUES (1, '积分系统后台管理系统', 'http://192.168.0.72:8082/points_system/', 'E:/application/nginx-1.17.5/html/points_system/', 'E:/application/nginx-1.17.5/html/points_system/', 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCGKCld0cnbLYyCT4/QBu/BYoA/JPcaqkIPJ22/V7mziDkkCzuztxsm814stNA2LwYJkG+ivTrKTIAVYhtFDDosC5BFYWegt1FwABLJDSL8Qt5GbC4byPNVrYdCMP6HE2aDbJsZjzagVA/iSVmT722rh9nPWJt0XhrL0AmRFR3qxwIDAQAB', 'MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIYoKV3RydstjIJPj9AG78FigD8k9xqqQg8nbb9XubOIOSQLO7O3GybzXiy00DYvBgmQb6K9OspMgBViG0UMOiwLkEVhZ6C3UXAAEskNIvxC3kZsLhvI81Wth0Iw/ocTZoNsmxmPNqBUD+JJWZPvbauH2c9Ym3ReGsvQCZEVHerHAgMBAAECgYAveylg3i4eF5niSPxyOPJENHOFZbTbSCUHLgJGtWqxIuZuXldr/MNsXrgXBIuoka4GVotcQrL7BGZUqxtRrcksZFFLfyXMn+pnALgx4SyhcSxbjWuBbrG1+VFqCgTSaePM41L/69p2FTDteD9HVXM5XFc8o7bWiNrHZiWbXgtsCQJBAO2Hl+6HOVIDWX9ialUPZG8O49Po3oh00Lchnkdta+DPbeZF4jhRCVAZ01QGo540yZqZXgzsRHJuw4yXJKBCqo0CQQCQlsSksZaJjL68eTN+n8EhJcjjC2hhvFRYRIPErBCEYcoemUF2PL+rBqlfgyyopmoX5D2nmuYQuCMM/bQDJV+jAkAaxBHJzjEWXcxC/3sN9LsTjLD9mxsgc1FloYMtd1YVsionLa7NO8x52z8mE81yMW6aXjfr6t/XqUWd3RZCfOCtAkBcNXp02bh6QiMFyXm4oCMng5RIj2bjJZrYq+Eo1N63vjGLMAuaXwWRCW+MtPgPGgoA8JMNR3C/at8XkthxRS1nAkBxSk+YVsnkz1K1jOovBwTVNM/RhSkP5VEMf9lacbR/EHd5snO6j5/42opPMLBGoi7Smx4TPf5Dltb5xc+mD/Ny');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `sysu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `sysu_account` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '管理员账号',
  `sysu_password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密码',
  `sysu_name` varchar(24) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员姓名',
  `sysu_status` int(1) NOT NULL DEFAULT 1 COMMENT '状态：0-禁用,1-启用',
  `sysu_last_time` datetime NULL DEFAULT NULL COMMENT '最后登录时间',
  `sysu_last_ip` varchar(23) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '最后登录IP',
  `sysu_add_time` datetime NOT NULL DEFAULT '1970-01-01 00:00:00' COMMENT '添加时间',
  `sysu_mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '邮箱',
  `sysu_token` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户token',
  PRIMARY KEY (`sysu_id`) USING BTREE,
  UNIQUE INDEX `sysu_account_uq`(`sysu_account`) USING BTREE COMMENT '管理员账号唯一约束',
  INDEX `sysu_account_index`(`sysu_account`) USING BTREE COMMENT '管理员账号索引',
  INDEX `sysu_name_index`(`sysu_name`) USING BTREE COMMENT '姓名索引'
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '9aac5f4e9dbe7fffb2ee2f9ccd837a39', '管家', 1, '2020-06-30 18:08:35', '192.168.56.1', '2017-06-09 14:55:14', 'admin@itv.com', '73282171281a83d4f908ae797bca51c7');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `ur_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `sysu_id` int(11) NOT NULL COMMENT '用户ID',
  `sysr_id` int(11) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`ur_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户、角色中间表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (31, 10, 2);
INSERT INTO `sys_user_role` VALUES (32, 10, 1);
INSERT INTO `sys_user_role` VALUES (52, 2, 1);
INSERT INTO `sys_user_role` VALUES (53, 2, 2);
INSERT INTO `sys_user_role` VALUES (55, 1, 1);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `user_account` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户账户(机顶盒账户)',
  `user_token` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '用户token',
  `user_stb_type` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户盒子型号',
  `user_order_status` tinyint(2) NULL DEFAULT 1 COMMENT '用户订购状态：0 已订购，1 未订购',
  `user_phone` int(11) NULL DEFAULT NULL COMMENT '用户手机号码',
  `user_points` int(11) NULL DEFAULT 0 COMMENT '用户总积分数',
  `user_sign_date` int(11) NULL DEFAULT 0 COMMENT '用户签到天数',
  `user_prize_id` int(11) NULL DEFAULT NULL COMMENT '用户获得对应的奖品ID',
  `user_login_time` datetime NULL DEFAULT NULL COMMENT '用户登录时间',
  `user_winning_time` datetime NULL DEFAULT NULL COMMENT '用户获奖时间',
  `user_add_time` datetime NULL DEFAULT NULL COMMENT '用户注册时间',
  `user_update_time` datetime NULL DEFAULT NULL COMMENT '用户更新时间',
  PRIMARY KEY (`user_id`) USING BTREE,
  INDEX `user_account`(`user_account`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'ynwl_test2', 'ABc12EFF', NULL, 1, 11000, 0, 1, 3, NULL, NULL, '2020-06-04 11:31:19', '2020-06-04 14:19:19');
INSERT INTO `user` VALUES (2, '12312', '3123123', NULL, 0, 123123, 0, 2, 3, NULL, '2020-06-04 14:09:33', '2020-06-04 11:34:12', '2020-06-04 14:19:23');
INSERT INTO `user` VALUES (3, 'ynwl_test', '123', 'pc', 0, NULL, 0, 0, NULL, NULL, NULL, '2020-06-28 16:24:22', NULL);

SET FOREIGN_KEY_CHECKS = 1;
